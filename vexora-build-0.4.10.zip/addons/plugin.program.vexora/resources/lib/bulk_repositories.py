"""Owner-approved bulk repository provisioning; Kodi scans and enables staged metadata.

No Xenon code, third-party scripts, desktop binaries or foreign add-on DB is copied.
Only reviewed repository packages are staged; file presence is never success.
"""
import hashlib
import io
import re
import shutil
import tempfile
import time
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from .repository_ecosystem import approved_package,endpoints
from .safe_paths import has_link_in_path,validate_relative_path
from .dependencies import _meets_minimum


def stage_repository(row,blob,addons,on_create=None):
    root=approved_package(row,blob)
    aid=row['id']
    if not re.fullmatch(r'repository\.[A-Za-z0-9_.-]+',aid):raise ValueError('Not a repository ID')
    addons=Path(addons)
    if has_link_in_path(addons):raise ValueError('Unsafe add-on directory')
    addons.mkdir(parents=True,exist_ok=True)
    target=addons/aid
    if target.exists():
        manifest=target/'addon.xml'
        if has_link_in_path(manifest):raise ValueError('Unsafe existing repository path')
        actual=ET.fromstring(manifest.read_bytes())
        if actual.get('id')!=aid or not _meets_minimum(actual.get('version'),row['version']):
            raise ValueError('Existing repository needs a native update; files retained')
        if endpoints(actual)!=endpoints(root):raise ValueError('Existing publisher endpoints differ; review required')
        return False
    with tempfile.TemporaryDirectory(prefix='.vexora-repository-',dir=str(addons)) as temp:
        staging=Path(temp)/aid;staging.mkdir()
        with ZipFile(io.BytesIO(blob)) as z:
            for entry in z.infolist():
                if entry.is_dir() or entry.filename in row.get('ignored_archive_members',[]):continue
                relative=entry.filename[len(row.get('archive_prefix',aid+'/')):];validate_relative_path(relative)
                if Path(relative).suffix.lower() in ('.py','.pyc','.pyo','.dll','.pyd','.so','.exe','.bat','.cmd','.ps1'):
                    raise ValueError('Executable content is not allowed in repository provisioning')
                destination=staging/relative;destination.parent.mkdir(parents=True,exist_ok=True)
                data=z.read(entry);destination.write_bytes(data)
                if hashlib.sha256(destination.read_bytes()).digest()!=hashlib.sha256(data).digest():
                    raise OSError('Repository staging verification failed')
        if target.exists():raise RuntimeError('Repository appeared during staging; no overwrite performed')
        if on_create:
            on_create(aid,{p.relative_to(staging).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in staging.rglob('*') if p.is_file()})
        staging.rename(target)
    return True


def provision(rows,addons,fetch,lookup,enable,scan,wait,*,progress=None,clock=time.monotonic,on_create=None):
    """One batch scan, native enablement, and bounded authoritative verification."""
    results={};pending=[];changed=False;stopped=False
    for index,row in enumerate(rows):
        aid=row['id']
        if progress:progress(index,len(rows),aid)
        if stopped or wait(.001):
            stopped=True
            results[aid]={'status':'cancelled','reason':'Setup cancelled'};continue
        if row['status']=='kodi_managed':
            current=lookup(aid)
            results[aid]={'status':'reused' if current and current.get('enabled') else 'unverified','reason':'Kodi-managed repository'};continue
        if row['status']!='package_verified':
            results[aid]={'status':'excluded','reason':row.get('reason','No approved publisher archive')};continue
        try:
            created=stage_repository(row,fetch(row),addons,on_create=on_create);changed=changed or created
            pending.append(row)
            results[aid]={'status':'staged' if created else 'reused','version':row['version'],'created':created}
        except Exception as exc:results[aid]={'status':'failed','reason':type(exc).__name__+': '+str(exc)[:180]}
    if stopped or wait(.001):
        for row in pending:results[row['id']].update(status='cancelled',reason='Setup cancelled; staged files retained for recovery')
        return results
    if pending:
        try:scan()
        except Exception as exc:
            for row in pending:results[row['id']].update(status='failed',reason='Native scan failed: '+type(exc).__name__)
            return results
    for row in pending:
        aid=row['id']
        try:
            if stopped or wait(.001):
                stopped=True
                results[aid].update(status='cancelled',reason='Setup cancelled before enablement')
                continue
            deadline=clock()+10
            while True:
                current=lookup(aid)
                if current:break
                if clock()>=deadline:raise RuntimeError('Kodi has not registered this staged repository; restart/recovery required')
                if wait(.25):
                    stopped=True
                    results[aid].update(status='cancelled',reason='Setup cancelled while awaiting registration')
                    break
            if stopped:continue
            if not _meets_minimum(current.get('version'),row['version']):raise RuntimeError('Kodi reports a different repository version')
            if not current.get('enabled'):enable(aid)
            current=lookup(aid)
            if not current or current.get('enabled') is not True:raise RuntimeError('Kodi did not confirm repository enabled')
            results[aid].update(status='verified',version=current['version'])
        except Exception as exc:results[aid].update(status='failed',reason=type(exc).__name__+': '+str(exc)[:180])
    return results


def make_plan(rows, original_sources):
    """Unify all seven originals and the expanded collection before any provisioning."""
    original_ids={r['id'] for r in rows if r['status']=='original_setup'}
    if len(original_ids)!=7 or set(original_sources)!=original_ids:
        raise ValueError('The unified batch must contain all seven original repositories')
    plan=[dict(row) for row in rows]
    if len({row['id'] for row in plan})!=len(plan):raise ValueError('Duplicate repository IDs in bulk plan')
    for row in plan:
        if row['id'] in original_sources:row.update(original_sources[row['id']],status='package_verified')
    return plan


def run_bulk_setup(packages,additional_packages,progress_view=None,on_create=None):
    import json
    import xbmc
    import xbmcvfs
    from urllib.request import Request
    from .kodi_status import get_addon
    from .repository_ecosystem import catalogue
    from .optional_setup import approved_repository_source,save_choices
    from .repository_download import _default_open
    supplied=dict(packages,**additional_packages)
    rows=make_plan(catalogue()['repositories'], {aid:approved_repository_source(aid) for aid in supplied})
    target=Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/repository-setup-report.json'))
    save_choices(target,{'format':1,'phase':'staging','method':'owner-approved bulk repository provisioning','results':{}})
    monitor=xbmc.Monitor()
    def fetch(row):
        if row['id'] in supplied:return supplied[row['id']]
        from .repository_bootstrap import load as bundled_repository
        data=bundled_repository(row['id'],row['sha256'])
        if data is not None:return data
        with _default_open(Request(row['zip_url'],headers={'User-Agent':'Kodi/21.3'}),timeout=12) as response:
            return response.read(20*1024*1024+1)
    def enable(aid):
        response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':aid,'enabled':True}})))
        if response.get('error'):raise RuntimeError('Kodi refused enablement for '+aid)
    results=provision(rows,xbmcvfs.translatePath('special://home/addons/'),fetch,get_addon,enable,
        lambda:xbmc.executebuiltin('UpdateLocalAddons',True),
        lambda seconds:monitor.waitForAbort(seconds) or bool(progress_view and progress_view.iscanceled()),
        progress=(lambda i,n,aid:progress_view.update(int(100*i/n),'Preparing repositories',aid)) if progress_view else None,on_create=on_create)
    save_choices(target,{'format':1,'phase':'registered','method':'owner-approved bulk repository provisioning','results':results})
    xbmc.executebuiltin('UpdateAddonRepos')
    missing=[aid for aid in supplied if results.get(aid,{}).get('status') not in ('verified','reused')]
    if missing:raise RuntimeError('Required bulk repository setup incomplete: '+', '.join(missing)+'. Open Setup verification for details.')
    return results
