"""Stage the verified Vexora-owned skin only after backup and leaving an active copy."""
import shutil,tempfile,uuid
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from .safe_paths import has_link_in_path
from .dependencies import _meets_minimum

def stage_skin(archive,addons,expected_version,active_skin,backup_folder):
 from .build_manager import verify_installed_skin
 with ZipFile(archive) as package:
  bundled=ET.fromstring(package.read('skin.vexora/addon.xml'))
  if bundled.get('id')!='skin.vexora' or bundled.get('version')!=expected_version:raise ValueError('Bundled skin version mismatch')
 addons=Path(addons);target=addons/'skin.vexora'
 if has_link_in_path(addons) or has_link_in_path(target):raise ValueError('Unsafe skin destination')
 if target.exists():
  current=ET.parse(target/'addon.xml').getroot()
  if current.get('id')!='skin.vexora':raise ValueError('Unexpected skin identity')
  if current.get('version')==expected_version:
   verify_installed_skin(archive,target);return False
  if not _meets_minimum(expected_version,current.get('version')):raise ValueError('A newer Vexora skin is installed; refusing downgrade')
 if active_skin=='skin.vexora':raise RuntimeError('Leave the active Vexora skin before replacing its files')
 addons.mkdir(parents=True,exist_ok=True)
 backup_folder=Path(backup_folder)
 if has_link_in_path(backup_folder):raise ValueError('Unsafe skin backup directory')
 backup_folder.mkdir(parents=True,exist_ok=True)
 retained=backup_folder/('superseded-skin-'+uuid.uuid4().hex)
 with tempfile.TemporaryDirectory(prefix='.vexora-skin-',dir=str(addons)) as folder:
  staging=Path(folder)/'skin.vexora';staging.mkdir()
  with ZipFile(archive) as package:
   for entry in package.infolist():
    if entry.is_dir():continue
    # Caller validated the exact bundled archive using validate_skin_payload.
    from .safe_paths import validate_relative_path
    if not entry.filename.startswith('skin.vexora/'):raise ValueError('Unexpected skin archive root')
    relative=entry.filename[len('skin.vexora/'):];validate_relative_path(relative)
    if (entry.external_attr>>16)&0o170000==0o120000:raise ValueError('Skin archive contains a link')
    destination=staging/relative;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(package.read(entry))
  verify_installed_skin(archive,staging)
  previous=target.exists()
  if previous:target.rename(retained)
  try:staging.rename(target)
  except Exception:
   if previous:retained.rename(target)
   raise
 # Retain the previous directory until the outer transaction passes final verification.
 return retained if previous else True
