"""Opt-in observer for a disposable Crew copy. Never emits upstream strings."""
import collections
import functools
import hashlib
import inspect
import json
import sys
import threading
import time
import uuid

PREFIX = 'VEXORA_CREW_DIAG '
_local = threading.local()
_ERRORS = {'UnboundLocalError', 'TimeoutError', 'Timeout', 'ReadTimeout', 'ConnectTimeout',
           'TypeError', 'ValueError', 'KeyError', 'OSError', 'ConnectionError', 'HTTPError',
           'RuntimeError', 'Exception', 'ImportError', 'AttributeError'}

def emit(event, **fields):
    try:
        record = dict(event=event, run=getattr(_local, 'run', 'none'), **fields)
        line = PREFIX + json.dumps(record, sort_keys=True)
        sink = getattr(_local, 'sink', None)
        if sink is not None:
            sink(line)
        else:
            import xbmc
            xbmc.log(line, xbmc.LOGINFO)
    except Exception:
        pass  # Diagnostic failure must not change the playback result.

def identifier(value, prefix):
    # Provider/source metadata only, never URLs, cookies, account fields or item repr().
    if not isinstance(value, str) or not value:
        return prefix + '-unknown'
    return prefix + '-' + hashlib.sha256(value.encode('utf-8')).hexdigest()[:12]

def identities(rows):
    # Ephemeral in-memory comparison only; never emitted, persisted or hashed into logs.
    return collections.Counter((r.get('url'), r.get('provider')) for r in rows if isinstance(r, dict)
                               and isinstance(r.get('url'), str) and isinstance(r.get('provider', ''), str))

def eligibility_snapshot(frame, owner):
    """Observe policy inputs only; never invoke a resolver or read account settings."""
    rows = getattr(owner, 'sources', [])
    premium = set(getattr(owner, 'hostprDict', []) or [])
    counts = collections.Counter()
    for row in rows:
        if not isinstance(row, dict):
            counts['malformed_rows'] += 1
            continue
        counts['debrid_only_rows'] += row.get('debridonly') is True
        counts['free_flag_false_rows'] += row.get('debridonly') is False
        counts['missing_free_flag_rows'] += 'debridonly' not in row
        counts['premium_host_rows'] += str(row.get('source', '')).lower() in premium
        counts['magnet_rows'] += str(row.get('url', '')).startswith('magnet:')
    local = frame.f_locals
    counts['eligible_output_rows'] = len(local.get('filter_sources', []))
    module = frame.f_globals.get('debrid')
    counts['resolver_instances'] = len(getattr(module, 'debrid_resolvers', []) or [])
    emit('eligibility_inputs', counts=dict(counts),
         policy='free_allowed' if local.get('debrid_only') == 'false' else 'debrid_only_or_unset')

def observe(fn, stage, lines=None, skips=None):
    lines, skips = lines or {}, skips or {}
    signature = inspect.signature(fn)
    @functools.wraps(fn)
    def wrapped(*args, **kwargs):
        outer = not hasattr(_local, 'run')
        if outer:
            _local.run = uuid.uuid4().hex[:12]
        previous = sys.gettrace()
        # Do not replace a debugger/profiler. No runtime hook is installed globally.
        if previous is not None and not getattr(previous, '_vexora_observer', False):
            emit('observer_skipped', stage=stage, reason='existing_tracer')
            if outer: del _local.run
            return fn(*args, **kwargs)
        previous_stats = getattr(_local, 'stats', None)
        if stage == 'queue': _local.stats = collections.Counter()
        if stage == 'resolve' and previous_stats is not None: previous_stats['attempted'] += 1
        start = time.monotonic()
        item = args[1] if stage == 'resolve' and len(args) > 1 else kwargs.get('item', {})
        item = item if isinstance(item, dict) else {}
        fields = {'provider': identifier(item.get('provider'), 'p'),
                  'host': identifier(item.get('source'), 'h')} if stage == 'resolve' else {}
        state = {'pending': None, 'before': None, 'errors': [], 'queue': False,
                 'attempts': 0, 'removed': collections.Counter()}
        bound = signature.bind_partial(*args, **kwargs).arguments
        owner = args[0] if args else None
        if stage == 'filter':
            emit('discovered', count=len(getattr(owner, 'sources', [])))
        elif stage == 'resolve':
            emit('attempt', **fields)
        else:
            emit('queue_input', count=len(bound.get('all_items') or []))
        def trace(frame, event, arg):
            if frame.f_code is not fn.__code__:
                return None
            if event in ('line', 'return', 'exception') and state['pending'] is not None:
                after = identities(getattr(owner, 'sources', []))
                before = state['before']
                removed, added = sum((before-after).values()), sum((after-before).values())
                reason = state['pending']
                state['removed'][reason] += removed
                emit('filter_step', reason=reason, before=sum(before.values()), after=sum(after.values()),
                     removed=removed, added=added)
                state['pending'] = None
            if event == 'line':
                if lines.get(frame.f_lineno) == 'debrid_host_eligibility':
                    try: eligibility_snapshot(frame, owner)
                    except Exception: pass
                if frame.f_lineno in lines:
                    state['before'] = identities(getattr(owner, 'sources', []))
                    state['pending'] = lines[frame.f_lineno]
                if frame.f_lineno in skips:
                    emit('queue_skip', reason=skips[frame.f_lineno])
                queue = frame.f_locals.get('queue')
                if stage == 'queue' and isinstance(queue, list) and not state['queue']:
                    state['queue'] = True
                    emit('passed_to_resolver_queue', count=len(queue))
            elif event == 'exception':
                exc = arg[1]
                name = type(exc).__name__
                name = name if name in _ERRORS else 'OtherError'
                code = 'unbound_local' if name == 'UnboundLocalError' else (
                    'timeout' if 'Timeout' in name else 'upstream_exception')
                state['errors'].append(code)
                emit('exception', stage=stage, exception_type=name, reason=code, line=frame.f_lineno)
            return trace
        trace._vexora_observer = True
        sys.settrace(trace)
        completed = False
        result = None
        try:
            result = fn(*args, **kwargs)
            completed = True
            return result
        finally:
            sys.settrace(previous)
            elapsed = round(time.monotonic()-start, 3)
            if stage == 'filter':
                count = len(getattr(owner, 'sources', []))
                emit('filter_summary', remaining=count, removed_by_reason=dict(state['removed']),
                     reason='all_filtered' if not count else 'sources_remaining')
            elif stage == 'resolve':
                outcome = 'cancelled' if result == 'close://' else ('returned_candidate' if result else (
                    'timeout' if 'timeout' in state['errors'] else 'failed'))
                if previous_stats is not None: previous_stats[outcome] += 1
                emit('attempt_result', outcome=outcome, elapsed_seconds=elapsed, **fields)
            else:
                empty = not bound.get('primary_item') and bound.get('start_index') is None
                reason = 'returned_candidate' if result and result != 'close://' else (
                    'cancelled' if result == 'close://' else ('empty_input' if empty else 'no_candidate_returned'))
                if reason == 'no_candidate_returned':
                    reason = 'all_candidates_skipped' if not _local.stats['attempted'] and state['queue'] else 'resolver_attempts_exhausted'
                emit('final', reason=reason, completed=completed, elapsed_seconds=elapsed, resolver_counts=dict(_local.stats))
                if previous_stats is None: del _local.stats
                else: _local.stats = previous_stats
            if outer:
                del _local.run
    return wrapped
