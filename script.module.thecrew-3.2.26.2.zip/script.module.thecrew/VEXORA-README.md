# Crew resolution diagnostic test — not a Vexora release

This is a temporary, reviewable upstream-module test. It does not change Vexora 0.4.8, publish 0.4.9, update a repository, bypass login or create sources. Dependency identity remains `script.module.thecrew`; only its local test version is `3.2.26.1` and display name identifies the diagnostic test. No first-party Vexora files or dependencies are packaged. GPLv3 source and licence are included. Do not publish this as an official Crew release.

## Findings

The installed `sources.py` and `smart_resolve.py` exactly match the publisher's original3.2.26 ZIP (SHA fingerprints in review.json and publisher-review.json). In `Sources.sourcesResolve`, `is_pack_source` is assigned within `if d:` but is read later in the hosted-media fallback when `d` is empty. For a non-direct non-debrid hoster, the read raises `UnboundLocalError`; the enclosing handler returnsNone without logging the error. The exact installed upstream method reproduces this, and ResolveURL is not reached. This is a confirmed upstream defect, not proof that all94 real sources fail for this one reason.

The only playback change inserts `is_pack_source = False` immediately after `resolved_part = None`, once per stack part, before `if d:`. Existing debrid/pack classification still overwrites the flag on its existing path. Direct sources, resolver fallback policy, authentication, cancellation and network timeout policies are unchanged. An invalid-host/failed-resolver fallback can still return its original URL: this test deliberately preserves that separate upstream behaviour. `returned_candidate` in logs means returned URL, **not verified playable media**.

Other existing filters can remove HEVC, wrong year/title/episode, undesirables, extras, over-limit quality tiers, duplicates, ineligible host/debrid combinations, excluded qualities/membership, captcha/blocked hosts and missing display labels. Queue de-duplicates sources and can skip service cooldown/backoff. The displayed scraper count is not necessarily the number actually attempted. No new failure policy or sources were invented.

Legacy `provider.dbgo`, `provider.ororo`, `provider.piratebay` are absent from the current plugin settings schema. The service's legacy schema-sync entry point is retired; discovery uses ScraperRegistry/scraper loading. Legacy explicit false values can migrate into the user-disabled map; missing keys alone do not establish disabled scrapers and do not explain an already-discovered hoster failing in sourcesResolve. Do not add invented settings or enable providers automatically. `cache.purge.version` is a version-gated startup cache-maintenance marker, not a resolver input; a missing marker may repeat maintenance, but it does not initialise the pack flag. No settings or caches were edited.

Installed ResolveURL5.1.212 exports HostedMediaFile and relevant_resolvers. Its constructor accepts url, include_disabled and include_universal, matching Crew's call. The reproduced free-hoster failure occurs before that constructor. This is an API-contract inspection, not a guarantee every host plugin/account is functional. ResolveURL does not need replacement for the confirmed unbound-local defect. Runtime host/service/authentication failures still require the diagnostic log. Review the installed version rather than substituting a different online ResolveURL mirror's version.

## Install the standalone ZIP on existing Vexora0.4.8

1. Close playback. Keep a copy of the official `script.module.thecrew-3.2.26.zip` from the publisher for rollback. Do not uninstall The Crew or erase its settings.
2. Copy `script.module.thecrew-3.2.26.1.zip` to an accessible local folder or USB drive. In Kodi, choose Settings → Add-ons → Install from zip file, then select that exact ZIP. Accept Kodi's normal prompts; do not disable its security checks.
3. Verify The Crew Module shows version3.2.26.1 (Vexora diagnostic test) in My add-ons → Add-on dependencies. Restart Kodi normally so old Python modules are unloaded. The Crew video add-on remains3.2.2 and Vexora remains0.4.8.
4. Retry the same movie once. Diagnostic records are written at Kodi INFO level with prefix `VEXORA_CREW_DIAG`; normal logging suffices. Do not enable verbose HTTP logging or paste account credentials.
5. On Windows, export only the diagnostic subset using the command below. Share that resulting JSONL file, not the complete Kodi log: upstream's existing logging can contain private URLs. The exporter drops unknown fields and unsafe values. If reproducing on Xbox, obtain kodi.log using its supported log-access/export route, then run the same exporter on a PC. No physical Xbox test is claimed.
6. To roll back, use Kodi's supported Versions/install-from-ZIP workflow to reinstall official module3.2.26, then restart. If Kodi requests confirmation to downgrade, approve it normally. Preserve userdata. The local numeric test version is higher than3.2.26 and below3.2.27; a later genuine upstream release can supersede it. Never put this test package in the public Vexora source.

```powershell
python diagnostics/crew_resolution/export.py --log "$env:APPDATA/Kodi/kodi.log" --output crew-diagnostic.jsonl
```

Run that from the diagnostic branch checkout with Python3.9+ on the PC. The output filename must not already exist. The runtime observer added to Kodi supports Python3.8 syntax and uses standard-library/Kodi APIs only. It hashes provider and host metadata identifiers (stable p-/h- IDs), emits counts/reason codes/exception types/elapsed time, and never emits URLs, item dictionaries, raw exception messages, cookies, headers, tokens or credentials. A timeout is reported only when an actual timeout exception is observed; a still-running call has a start without an end record. Instrumentation adds tracing overhead, so elapsed times are diagnostic, not a performance benchmark. Existing debugger tracing takes precedence. The observer is opt-in to this ZIP only; it is never installed by the Vexora Wizard.

## Build/review/test

No third-party implementation is committed to this repository. prepare.py creates an isolated copy only if input identity/version and both playback-file fingerprints match the reviewed publisher version. Existing output paths are refused. The core source text remains identical except for one added line and appended diagnostic bindings (line endings normalize during staging); the original licence/copyright remains.

```powershell
$env:CREW_MODULE_PATH = "$env:APPDATA/Kodi/addons/script.module.thecrew"
python -m unittest discover -s diagnostics/crew_resolution/tests -v
python diagnostics/crew_resolution/package_test.py --module PATH_TO_VERIFIED_UPSTREAM_MODULE --staging NEW_DISPOSABLE_FOLDER --artifact NEW_FOLDER/script.module.thecrew-3.2.26.1.zip
```

Tests execute the actual upstream methods extracted by AST with controlled provider/ResolveURL collaborators, without streaming requests. They cover the original defect, corrected hoster path, direct/debrid/pack paths, filtering, empty lists, failures, exceptions, timeout observation, queue counts and privacy/export safeguards. They do not claim live playback or physical Xbox validation. A small upstream fix is appropriate; upstream submission is not automatically sent without owner instruction. The Vexora PR is for review only, not merging or release publication.


Packaging note: the publisher's unmodified `lib/resources/lib/modules/helper.py` contains an IndentationError at line45 (empty except block). It is not changed by this narrowly scoped fix. The three changed/runtime diagnostic Python files pass syntax checks; do not claim every file in the upstream package compiles. This is a separate upstream issue, not the reproduced sourcesResolve failure, and no unrelated repair was silently included.

## Completed standalone artifact

Artifact: `script.module.thecrew-3.2.26.1.zip`
SHA256: `a103eee510bf37c6c22b53657965a8f64d87c49861eac1c13ef7fc961066b9b0`
The local ZIP passes integrity, top-level addon identity/version, changed-file syntax, runtime observer Python3.8-syntax, and exact one-line-plus-instrumentation verification. All43 diagnostic/regression tests passed against the original reviewed installed methods with controlled collaborators. Repeated inherited observer tests are included in that count. No live stream, actual host account or physical Xbox playback success is claimed.

The publisher ZIP hashes match both installed playback files. The remaining real-source failure attribution needs one new playback attempt and the exported diagnostic log. No claim that all94 sources will now work. The corrected hoster path can now invoke ResolveURL; existing resolver fallback and authentication policy remain unchanged. Vexora release files and the existing0.4.9 branch are unchanged.


Latest investigation: see INVESTIGATION-2026-10-24.md. The new local-only artifact is script.module.thecrew-3.2.26.2.zip, retaining the one-line fix and adding aggregate eligibility policy inputs. It does not change filtering or authorize debrid accounts. Export kodi.old.log as well if Kodi has restarted.
