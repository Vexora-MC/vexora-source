"""Offline Vexora recovery. Close Kodi before invoking this utility."""
import argparse
import json
from pathlib import Path
import re
import shutil
import sys
import uuid
import hashlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'plugin.program.vexora' / 'resources'))
from lib.safe_paths import validate_relative_path

ADDONS = {'addons/skin.vexora', 'addons/repository.angelitto', 'addons/repository.Rising.Tides'}


def checked(path, root):
    if path.resolve() == root.resolve() or root.resolve() not in path.resolve().parents:
        raise ValueError('Recovery destination escapes its profile root')
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError('Recovery paths must not contain symlinks')
    return path


def restore(backup, *, kodi_stopped=False, home=None, userdata=None):
    if not kodi_stopped:
        raise ValueError('Close Kodi and explicitly confirm it is stopped')
    backup = Path(backup).absolute()
    if any(p.is_symlink() for p in (backup, *backup.parents)):
        raise ValueError('Invalid recovery backup')
    journal = json.loads((backup / 'transaction.json').read_text(encoding='utf-8'))
    if journal.get('format') != 1 or journal.get('state') == 'backing_up':
        raise ValueError('Backup is not complete')
    roots = {key: Path(journal[key]).absolute() for key in ('home', 'userdata')}
    if (home is None or userdata is None or Path(home).resolve() != roots['home'].resolve()
            or Path(userdata).resolve() != roots['userdata'].resolve()):
        raise ValueError('Explicit recovery profile must match the recorded backup target')
    actions, seen = [], set()
    for kind in ('paths', 'created'):
        for record in journal[kind]:
            scope, relative = record['scope'], record['path']
            validate_relative_path(relative)
            if scope not in roots or (scope, relative.casefold()) in seen:
                raise ValueError('Invalid recovery record')
            seen.add((scope, relative.casefold()))
            if ((scope == 'home' and relative not in ADDONS) or
                (scope == 'userdata' and relative != 'guisettings.xml'
                 and not re.fullmatch(r'Database/Addons[0-9]+\.db', relative))):
                raise ValueError('Recovery target is outside the build scope')
            destination = checked(roots[scope] / relative, roots[scope])
            source = checked(backup / scope / relative, backup)
            if kind == 'paths':
                if not source.exists() or any(p.is_symlink() for p in source.rglob('*')):
                    raise ValueError('Missing or unsafe backup data')
                actual = ({'': hashlib.sha256(source.read_bytes()).hexdigest()} if source.is_file() else
                          {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
                           for p in source.rglob('*') if p.is_file()})
                if actual != record.get('hashes'):
                    raise ValueError('Backup integrity verification failed')
            actions.append((kind, source, destination))
    # All originals have been checked before changing a single profile file.
    for kind, source, destination in actions:
        if kind == 'created':
            if destination.is_dir():
                if any(p.is_symlink() for p in destination.rglob('*')):
                    raise ValueError('Recovery target contains a symlink')
                shutil.rmtree(destination)
            elif destination.exists():
                destination.unlink()
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name('.vexora-restore-' + uuid.uuid4().hex)
        if source.is_dir():
            shutil.copytree(source, temporary)
            if destination.exists():
                if any(p.is_symlink() for p in destination.rglob('*')):
                    raise ValueError('Recovery target contains a symlink')
                shutil.rmtree(destination)
        else:
            shutil.copy2(source, temporary)
        temporary.replace(destination)
        if destination.name.startswith('Addons') and destination.suffix == '.db':
            for suffix in ('-wal', '-shm'):
                sidecar = checked(destination.with_name(destination.name + suffix), roots['userdata'])
                sidecar.unlink(missing_ok=True)
    journal['state'] = 'restored'
    (backup / 'transaction.json').write_text(json.dumps(journal, indent=2), encoding='utf-8')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('backup')
    parser.add_argument('--kodi-stopped', action='store_true', required=True)
    parser.add_argument('--home', required=True, help='Expected Kodi home directory')
    parser.add_argument('--userdata', required=True, help='Expected Kodi userdata directory')
    args = parser.parse_args()
    restore(args.backup, kodi_stopped=args.kodi_stopped, home=args.home, userdata=args.userdata)
    print('Vexora backup restored. Start Kodi normally.')
