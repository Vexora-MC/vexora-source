"""Delayed maintenance and bounded original-repository update checks."""
import hashlib
import json
import re
import time
from pathlib import Path
from urllib.request import Request
from xml.etree import ElementTree as ET
from .repository_download import _default_open
from .dependencies import _meets_minimum, _version_parts
from .safe_paths import has_link_in_path

SOURCE = 'https://vexora-mc.github.io/vexora-source/'
IDS = ('repository.vexora', 'skin.vexora', 'plugin.program.vexora')


def parse_update_index(data, checksum):
    if len(data)>256000 or b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise ValueError('Invalid update index')
    if hashlib.md5(data).hexdigest()!=checksum.strip().decode('ascii'):
        raise ValueError('Repository index/checksum not yet synchronised')
    nodes=list(ET.fromstring(data))
    versions={n.get('id'):n.get('version') for n in nodes}
    if len(nodes)!=3 or set(versions)!=set(IDS) or len(set(versions.values()))!=1 or any(_version_parts(v) is None for v in versions.values()):
        raise ValueError('Unexpected update index identity/version')
    return versions


def pending_updates(available, installed):
    return {id:version for id,version in available.items()
            if installed.get(id) and not _meets_minimum(installed[id],version)}


def prune_old_files(packages, scratch, installed, now=None):
    """Keep installed packages and newest two per ID; never touch artwork caches."""
    now=time.time() if now is None else now
    removed=[];packages=Path(packages);scratch=Path(scratch)
    for folder in (packages,scratch):
        if has_link_in_path(folder):raise ValueError('Unsafe maintenance path')
    groups={}
    if packages.is_dir():
        for path in packages.glob('*.zip'):
            match=re.fullmatch(r'([A-Za-z0-9_.-]+)-(\d[^/\\]*)\.zip',path.name)
            if match and path.is_file() and not has_link_in_path(path):
                groups.setdefault(match[1],[]).append((path.stat().st_mtime,path,match[2]))
    for id,items in groups.items():
        for modified,path,version in sorted(items,reverse=True)[2:]:
            if now-modified>7*86400 and version!=installed.get(id):
                path.unlink();removed.append(path.name)
    if scratch.is_dir():
        for path in scratch.glob('vexora-*.tmp'):
            if path.is_file() and not has_link_in_path(path) and now-path.stat().st_mtime>86400:
                path.unlink();removed.append(path.name)
    return removed



def native_pending_addons(listdir, installed):
    """Read Kodi's own pending-updates virtual folder, not pinned catalogue versions.

    Return installed add-on IDs only. A missing or unreadable virtual folder
    is not evidence that updates are available.
    """
    from urllib.parse import unquote, urlsplit
    listing = listdir('addons://outdated/')
    if not isinstance(listing, (tuple, list)) or len(listing) != 2:
        return []
    directories, files = listing
    if not isinstance(directories, (tuple, list)) or not isinstance(files, (tuple, list)):
        return []
    pending = set()
    for item in list(directories) + list(files):
        if not isinstance(item, str):
            continue
        candidate = unquote(urlsplit(item).path).strip('/').split('/')[-1]
        if candidate in installed:
            pending.add(candidate)
    return sorted(pending)


def prompt_native_updates(xbmc, xbmcgui, xbmcvfs, installed, monitor):
    """Offer Kodi's native update browser; Kodi retains installation consent."""
    xbmc.executebuiltin('UpdateAddonRepos')
    xbmc.executebuiltin('UpdateLocalAddons')
    try:
        policy=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':2,'method':'Settings.GetSettingValue','params':{'setting':'general.addonupdates'}}))).get('result',{}).get('value')
    except (ValueError,TypeError):
        policy=None
    if policy == 0:
        return  # Kodi processes compatible updates asynchronously; never override holds/security.
    if monitor.waitForAbort(3):
        return
    try:
        pending = native_pending_addons(xbmcvfs.listdir, installed)
    except (OSError, ValueError, TypeError) as error:
        xbmc.log('Vexora native update discovery unavailable: ' + str(error), xbmc.LOGWARNING)
        return
    if not pending or monitor.abortRequested() or xbmc.Player().isPlaying():
        return
    if xbmcgui.getCurrentWindowId() != 10000 or xbmc.getCondVisibility('System.HasActiveModalDialog'):
        return
    summary = ', '.join(pending[:4])
    if len(pending) > 4:
        summary += ' and ' + str(len(pending) - 4) + ' more'
    if xbmcgui.Dialog().yesno('Add-on updates available',
            str(len(pending)) + ' installed add-on update(s): ' + summary +
            '. Open Kodi Updates to review and install?', nolabel='Not now',
            yeslabel='Review updates'):
        xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://outdated/,return)')


def run():
    import xbmc
    import xbmcgui
    import xbmcvfs
    monitor=xbmc.Monitor()
    if monitor.waitForAbort(45):return
    # Keep all I/O and prompting out of initial tab loading and playback.
    for _ in range(60):
        if (xbmcgui.getCurrentWindowId()==10000 and not xbmc.Player().isPlaying()
                and not xbmc.getCondVisibility('System.HasActiveModalDialog')
                and xbmcgui.Window(10000).getProperty('vexora.installing')!='true'):
            break
        if monitor.waitForAbort(5):return
    else:return
    profile=Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/'))
    state_path=profile/'startup-state.json'
    try:
        if has_link_in_path(state_path):return
        state=json.loads(state_path.read_text()) if state_path.exists() and state_path.stat().st_size<32000 else {}
        if not isinstance(state,dict):state={}
        response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.GetAddons',
            'params':{'enabled':'all','properties':['version']}})))
        if response.get('error'):return
        installed={a['addonid']:a['version'] for a in response['result']['addons']}
        prune_old_files(xbmcvfs.translatePath('special://home/addons/packages/'),profile/'temp',installed)
        prompt_native_updates(xbmc, xbmcgui, xbmcvfs, installed, monitor)
        def fetch(name,limit):
            with _default_open(Request(SOURCE+name),timeout=8) as stream:
                data=stream.read(limit+1)
                if len(data)>limit:raise ValueError('Oversized update response')
                return data
        available=parse_update_index(fetch('addons.xml',256000),fetch('addons.xml.md5',128))
        pending=pending_updates(available,installed)
        state['checked']=time.time()
        profile.mkdir(parents=True,exist_ok=True)
        temp=state_path.with_suffix('.tmp')
        if has_link_in_path(temp):return
        temp.write_text(json.dumps(state));temp.replace(state_path)
        if not pending or monitor.abortRequested() or xbmc.Player().isPlaying() or xbmcgui.getCurrentWindowId()!=10000 or xbmc.getCondVisibility('System.HasActiveModalDialog'):return
        target=available['plugin.program.vexora']
        if state.get('dismissed_version') == target:return
        if xbmcgui.Dialog().yesno('Vexora update available',
            'Vexora '+target+' is available. Open Kodi Updates to install the matching Wizard, skin and repository? Existing add-ons are retained.',
            nolabel='Later',yeslabel='Open updates'):
            xbmc.executebuiltin('UpdateAddonRepos')
            xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://outdated/,return)')
        else:
            state['dismissed_version']=target
            if has_link_in_path(temp):return
            temp.write_text(json.dumps(state));temp.replace(state_path)
    except (OSError, ValueError, TypeError, KeyError, ET.ParseError) as error:
        xbmc.log('Vexora background maintenance/update check: '+str(error),xbmc.LOGWARNING)
