"""Restore only fingerprint-checked Crew compatibility files, with Kodi stopped."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'plugin.program.vexora/resources'))
from lib.crew_compat import restore
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--module',required=True);p.add_argument('--backup',required=True);p.add_argument('--kodi-stopped',action='store_true');a=p.parse_args();print(restore(a.module,a.backup,kodi_stopped=a.kodi_stopped))
