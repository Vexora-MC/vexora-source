"""Whole-build wizard: validated payload, backup, native installs and activation."""
import hashlib
import json
import shutil
import sqlite3
import time
import uuid
import os
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from contextlib import closing

from .repository_download import fetch_both_required_repositories
from .runtime_setup import prepare_repository_cache, run_repository_setup, verify_repositories
from .optional_catalogue import OPTIONAL_REPOSITORIES
from .optional_setup import reviewed_repository_packages, install_build_repositories
from .safe_paths import validate_relative_path, has_link_in_path, canonical_profile_path
from .file_io import flush_file


def validate_skin_payload(folder):
    folder = Path(folder)
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    path = folder / 'skin.vexora.zip'
    if (manifest.get('id') != 'skin.vexora' or manifest.get('kodi_major') != 21
            or hashlib.sha256(path.read_bytes()).hexdigest() != manifest.get('sha256')):
        raise ValueError('Bundled Vexora skin integrity check failed')
    with ZipFile(path) as archive:
        seen = set()
        if len(archive.infolist()) > 1000 or sum(x.file_size for x in archive.infolist()) > 128 * 1024 * 1024:
            raise ValueError('Oversized skin payload')
        for info in archive.infolist():
            validate_relative_path(info.filename)
            if (not info.filename.startswith('skin.vexora/') or info.filename.casefold() in seen
                    or info.flag_bits & 1 or (info.external_attr >> 16) & 0o170000 == 0o120000):
                raise ValueError('Unsafe bundled skin archive')
            seen.add(info.filename.casefold())
        root = ET.fromstring(archive.read('skin.vexora/addon.xml'))
        if root.get('id') != 'skin.vexora' or root.get('version') != manifest.get('version'):
            raise ValueError('Bundled skin identity mismatch')
        if archive.testzip() is not None:
            raise ValueError('Corrupt bundled skin')
    return path, manifest


def verify_installed_skin(skin_zip, installed_path):
    """Require installed files to match the validated payload before activation."""
    root = Path(installed_path)
    if (not root.is_dir() or has_link_in_path(root)
            or any(p.is_symlink() for p in root.rglob('*'))):
        raise ValueError('Invalid installed Vexora skin location')
    with ZipFile(skin_zip) as archive:
        expected = {info.filename[len('skin.vexora/'):]:
                    hashlib.sha256(archive.read(info)).hexdigest()
                    for info in archive.infolist() if not info.is_dir()}
    if snapshot_hashes(root) != expected:
        raise ValueError('Installed Vexora skin differs from validated payload')


def save_journal(folder, journal):
    path = Path(folder) / 'transaction.json'
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as output:
        output.write(json.dumps(journal, indent=2, sort_keys=True))
        flush_file(output)
    temporary.replace(path)


def snapshot_hashes(path):
    if path.is_file():
        return {'': hashlib.sha256(path.read_bytes()).hexdigest()}
    return {item.relative_to(path).as_posix(): hashlib.sha256(item.read_bytes()).hexdigest()
            for item in path.rglob('*') if item.is_file()}


def backup_build(home, userdata, backup_parent, previous_skin):
    """Back up only affected files; use SQLite's backup API for the live DB."""
    home, userdata, backup_parent = map(Path, (home, userdata, backup_parent))
    for root in (home, userdata, backup_parent):
        if has_link_in_path(root):
            raise ValueError('Backup paths must not contain symlinks')
    folder = backup_parent / ('build-' + uuid.uuid4().hex)
    folder.mkdir(parents=True)
    journal = {'format': 1, 'state': 'backing_up', 'home': str(canonical_profile_path(home)),
               'userdata': str(canonical_profile_path(userdata)), 'previous_skin': previous_skin,
               'paths': [], 'created': []}
    save_journal(folder, journal)
    targets = [('home', 'addons/' + name) for name in
               ('skin.vexora', 'repository.vexora', 'repository.angelitto', 'repository.Rising.Tides', *OPTIONAL_REPOSITORIES)]
    targets += [('userdata', 'guisettings.xml')]
    for scope, relative in targets:
        source = (home if scope == 'home' else userdata) / relative
        record = {'scope': scope, 'path': relative}
        if source.exists():
            if (has_link_in_path(source)
                    or (source.is_dir() and any(p.is_symlink() for p in source.rglob('*')))):
                raise ValueError('Affected profile data contains a symlink')
            destination = folder / scope / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            if source.is_dir():
                shutil.copytree(source, destination)
            else:
                shutil.copy2(source, destination)
            record['hashes'] = snapshot_hashes(destination)
            journal['paths'].append(record)
        else:
            journal['created'].append(record)
    for database in (userdata / 'Database').glob('Addons*.db'):
        if has_link_in_path(database):
            raise ValueError('Invalid add-on database path')
        destination = folder / 'userdata' / 'Database' / database.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(str(database))) as source, closing(sqlite3.connect(str(destination))) as target:
            source.backup(target)
        journal['paths'].append({'scope': 'userdata', 'path': 'Database/' + database.name,
                                 'hashes': snapshot_hashes(destination)})
    journal['state'] = 'backed_up'
    save_journal(folder, journal)
    return folder, journal


def wait_for_skin_activation(current_skin, confirmation_visible, monitor,
                             clock=time.monotonic, timeout=35, auto_confirm=None, expected='skin.vexora'):
    """Do not report success while Kodi can still revert an unconfirmed skin."""
    deadline = clock() + timeout
    stable_since = None
    saw_confirmation = False
    while clock() < deadline:
        now = clock()
        showing_confirmation = confirmation_visible()
        if showing_confirmation:
            saw_confirmation = True
            if auto_confirm:auto_confirm()
        if current_skin() == expected and not showing_confirmation:
            if stable_since is None:
                stable_since = now
            elif now - stable_since >= (2 if saw_confirmation else 12):
                return
        else:
            stable_since = None
        if monitor.waitForAbort(.25):
            raise RuntimeError('Kodi stopped during skin confirmation')
    raise RuntimeError('Vexora skin was not confirmed or Kodi reverted the change')


def install_full_build(selected_names=None, overall_progress=None):
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    from .kodi_status import get_addon

    dialog = xbmcgui.Dialog()
    if xbmc.getInfoLabel('System.BuildVersion').split('.')[0] != '21':
        raise ValueError('Vexora requires Kodi 21 Omega')
    backup_parent = Path(xbmcvfs.translatePath('special://profile/')) / 'addon_data' / 'plugin.program.vexora' / 'backups'
    for previous in backup_parent.glob('build-*/transaction.json'):
        state = json.loads(previous.read_text(encoding='utf-8')).get('state')
        if state not in ('backing_up', 'backed_up', 'installed', 'restored', 'native_undone'):
            raise RuntimeError('An interrupted build needs recovery before reinstalling: ' + str(previous.parent))
    if not dialog.yesno('Install complete Vexora build',
                        'Back up affected settings and add-ons, install the Vexora interface and provision the compatible repositories in one bulk setup. The 74 unique repository records include the original seven: '
                        'Angelitto, Rising Tides, JewRepo, The Crew, Bugatsinho, The Loop and Magnetic repositories, then activate Vexora? '
                        'Already verified installed components are kept. Kodi may require its own approvals. ' +
                        ('Selected add-ons: ' + selected_names + '. ' if selected_names is not None else '') +
                        'Cancel stops setup.'):
        return
    payload = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))) / 'resources' / 'build'
    skin_zip, manifest = validate_skin_payload(payload)
    from .own_repository import validate as validate_own_repository,stage as stage_own_repository,verify as verify_own_repository
    own_repository_xml=validate_own_repository(payload,manifest['version'])
    from .dependencies import _meets_minimum
    existing_skin=get_addon('skin.vexora')
    if existing_skin and not _meets_minimum(manifest['version'],existing_skin.get('version')):
        raise ValueError('A newer Vexora skin is installed; update the Wizard instead of downgrading')
    progress = overall_progress.stage(0,10) if overall_progress else xbmcgui.DialogProgress()
    progress.create('Vexora full build', 'Validating the seven required publisher repositories before changing Kodi')
    try:
        packages = fetch_both_required_repositories()
        additional_packages = reviewed_repository_packages()
        if progress.iscanceled():
            return
        cache = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/repositories')
        prepare_repository_cache(packages, cache)
    finally:
        progress.close()
    home = xbmcvfs.translatePath('special://home/')
    userdata = xbmcvfs.translatePath('special://profile/')
    from .platform_support import probe_write_directory, require_install_space
    probe_write_directory(Path(home)/'addons')
    probe_write_directory(Path(userdata)/'addon_data/plugin.program.vexora')
    require_install_space(home, userdata, skin_zip.stat().st_size)
    backup_parent = Path(userdata) / 'addon_data' / 'plugin.program.vexora' / 'backups'
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
        'params': {'setting': 'lookandfeel.skin'}})))
    previous_skin = response['result']['value']
    backup, journal = backup_build(home, userdata, backup_parent, previous_skin)
    from .native_recovery import capture_states
    journal['addon_states'] = capture_states(get_addon)
    save_journal(backup, journal)
    try:
        journal['state'] = 'installing_skin'
        save_journal(backup, journal)
        monitor = xbmc.Monitor()
        from .skin_confirmation import approve_skin_choice
        from .skin_staging import stage_skin
        skin = get_addon('skin.vexora')
        if skin and skin.get('version') != manifest['version'] and xbmc.getSkinDir() == 'skin.vexora':
            if overall_progress:overall_progress.suspend()
            response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Settings.SetSettingValue','params':{'setting':'lookandfeel.skin','value':'skin.estuary'}})))
            if response.get('result') is not True:raise RuntimeError('Unable to leave active Vexora skin safely')
            wait_for_skin_activation(xbmc.getSkinDir,lambda:xbmc.getCondVisibility('Window.IsActive(yesnodialog)'),monitor,
                auto_confirm=lambda:approve_skin_choice('skin.estuary'),expected='skin.estuary')
        retained_skin=stage_skin(skin_zip,Path(home)/'addons',manifest['version'],xbmc.getSkinDir(),backup)
        if isinstance(retained_skin,Path):
            journal['retained_skin_directory']=retained_skin.name
            save_journal(backup,journal)
        journal['state'] = 'installing_repositories'
        save_journal(backup, journal)
        from .bulk_repositories import run_bulk_setup
        def record_bulk_creation(aid,hashes):
            relative='addons/'+aid
            if any(r['scope']=='home' and r['path']==relative for r in journal['paths']):
                raise RuntimeError('Refusing to treat an existing backed-up repository as newly created')
            record=next((r for r in journal['created'] if r['scope']=='home' and r['path']==relative),None)
            if record is None:
                record={'scope':'home','path':relative};journal['created'].append(record)
            record['installed_hashes']=hashes
            save_journal(backup,journal)
        def set_own_repository_enabled(aid,enabled):
            response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':aid,'enabled':enabled}})))
            if response.get('error'):raise RuntimeError('Kodi refused first-party repository state change')
        journal['own_repository']=stage_own_repository(own_repository_xml,Path(home)/'addons',backup,get_addon,set_own_repository_enabled,on_create=record_bulk_creation)
        save_journal(backup,journal)
        journal['bulk_repository_results'] = run_bulk_setup(packages, additional_packages,
            progress_view=overall_progress.stage(10,75) if overall_progress else None,on_create=record_bulk_creation)
        verify_own_repository(get_addon,set_own_repository_enabled,monitor.waitForAbort,manifest['version'])
        save_journal(backup,journal)
        if monitor.abortRequested():
            raise RuntimeError("Kodi stopped during expanded repository setup")
        skin_deadline=time.monotonic()+20
        while True:
            skin=get_addon('skin.vexora')
            if skin and skin.get('version')==manifest['version']:break
            if time.monotonic()>=skin_deadline:raise RuntimeError('Kodi has not registered the staged skin version; recovery checkpoint retained')
            if monitor.waitForAbort(.25):raise RuntimeError('Kodi stopped during skin registration')
        if not skin['enabled']:
            result=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':'skin.vexora','enabled':True}})))
            if result.get('error') or not get_addon('skin.vexora')['enabled']:raise RuntimeError('Kodi refused Vexora skin enablement')
        verify_installed_skin(skin_zip,xbmcvfs.translatePath(xbmcaddon.Addon('skin.vexora').getAddonInfo('path')))

        if overall_progress:
            overall_progress.update(76,'Activating and verifying Vexora interface')
            if overall_progress.cancelled():raise RuntimeError('Build setup cancelled; recovery checkpoint retained')
        if overall_progress:
            overall_progress.suspend()
        journal['state'] = 'activating_skin'
        save_journal(backup, journal)
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin', 'value': 'skin.vexora'}})))
        if response.get('result') is not True:
            raise RuntimeError('Skin activation declined or failed')
        from .skin_confirmation import approve_vexora_skin
        wait_for_skin_activation(xbmc.getSkinDir,
            lambda: xbmc.getCondVisibility('Window.IsActive(yesnodialog)'), monitor,auto_confirm=approve_vexora_skin)
        if xbmc.getSkinDir() != 'skin.vexora' or verify_repositories(get_addon):
            raise RuntimeError('Final build verification failed')
        verify_installed_skin(skin_zip, xbmcvfs.translatePath(xbmcaddon.Addon('skin.vexora').getAddonInfo('path')))
        journal['state'] = 'saving_skin'
        save_journal(backup, journal)
        from .skin_persistence import persist_vexora_skin
        persist_vexora_skin()
        journal['state'] = 'installed'
        save_journal(backup, journal)
        xbmc.log('Vexora build installed; verified backup: ' + str(backup), xbmc.LOGINFO)
        if overall_progress is None:
            dialog.notification('Vexora build installed',
                                'Core installation verified. Selected add-on setup continues next.', time=6000)
        return True
    except Exception as exc:
        journal['state'], journal['error'] = 'recovery_required', str(exc)
        save_journal(backup, journal)
        dialog.ok('Vexora build incomplete', str(exc) + '\nRecovery backup: ' + str(backup) +
                  '\nClose Kodi before restoring this backup. The build has not passed final verification.')
        raise
