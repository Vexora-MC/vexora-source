"""Confirm only the expected Kodi skin-change dialog inside consented build setup."""

def approve_expected_skin(expected,active_skin,visible,heading,body,localized,click):
    if active_skin()!=expected or not visible():return False
    try:
        title,text=localized(13123).strip(),localized(13111).strip()
        if not title or not text or heading().strip()!=title or body().strip()!=text:return False
    except (RuntimeError,ValueError,AttributeError):return False
    click()
    return True


def approve_skin_choice(expected):
    import xbmc
    import xbmcgui
    if xbmcgui.Window(10000).getProperty('vexora.installing')!='true':return False
    if expected not in ('skin.vexora','skin.estuary'):return False
    approved=approve_expected_skin(expected,xbmc.getSkinDir,
        lambda:xbmc.getCondVisibility('Window.IsActive(yesnodialog)'),
        lambda:xbmc.getInfoLabel('Control.GetLabel(1)'),lambda:xbmc.getInfoLabel('Control.GetLabel(9)'),
        xbmc.getLocalizedString,lambda:xbmc.executebuiltin('SendClick(10100,11)'))
    if approved:xbmc.log('Vexora confirmed scoped skin choice: '+expected,xbmc.LOGINFO)
    return approved


def approve_vexora_skin():
    return approve_skin_choice('skin.vexora')
