"""Run: python -m unittest discover -s skin.vexora/tools -p "test_*.py" """
from pathlib import Path
from tempfile import TemporaryDirectory
import shutil
import unittest

from validate_skin import validate, ROOT


class SkinValidationTests(unittest.TestCase):
    def test_repository_skin_structure(self):
        self.assertEqual([], validate(ROOT))

    def test_missing_asset_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / "skin.vexora"
            shutil.copytree(ROOT, copy)
            (copy / "media" / "vexoramchome.png").unlink()
            self.assertTrue(any("vexoramchome.png" in issue for issue in validate(copy)))

    def test_optional_addon_route_tampering_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / "skin.vexora"
            shutil.copytree(ROOT, copy)
            home = copy / "1080i" / "Home.xml"
            content = home.read_text(encoding="utf-8")
            content = content.replace("plugin://plugin.program.vexora/?section=sports", "plugin://wrong.plugin/")
            home.write_text(content, encoding="utf-8")
            self.assertTrue(any("Unsafe or incorrect Vexora routed action" in issue for issue in validate(copy)))

    def test_invalid_png_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / "skin.vexora"
            shutil.copytree(ROOT, copy)
            (copy / "media" / "focus-pixel.png").write_bytes(b"not a PNG")
            self.assertTrue(any("Invalid PNG header" in issue for issue in validate(copy)))

    def test_corrupt_pixel_data_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / 'skin.vexora'
            shutil.copytree(ROOT, copy)
            path = copy / 'media' / 'focus-pixel.png'
            data = bytearray(path.read_bytes())
            data[45] ^= 1
            path.write_bytes(data)
            self.assertTrue(any('Invalid PNG header' in issue for issue in validate(copy)))


if __name__ == "__main__":
    unittest.main()
