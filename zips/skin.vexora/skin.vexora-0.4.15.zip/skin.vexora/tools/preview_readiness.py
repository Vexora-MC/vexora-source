"""Report Windows Kodi preview readiness without changing Kodi or files."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_skin import validate

# These are conservative preflight requirements, not a complete Kodi skin contract.
REQUIRED = (
    "Home.xml",
    "Font.xml",
    "Includes.xml",
    "MyVideoNav.xml",
    "DialogOK.xml",
    "DialogConfirm.xml",
    "DialogTextViewer.xml",
    "MyVideo.xml",
    "MyMusicNav.xml",
    "MyPictures.xml",
    "Settings.xml",
    "DialogBusy.xml",
    "DialogProgress.xml",
    "DialogSelect.xml",
    "DialogKeyboard.xml",
    "VideoFullScreen.xml",
)

def main():
    errors = validate(ROOT)
    missing = [name for name in REQUIRED if not (ROOT / "1080i" / name).is_file()]
    print("Vexora Windows / Xbox readiness report")
    print("Static validation:", "PASS" if not errors else "FAIL")
    for issue in errors:
        print("  -", issue)
    print("Windows interface coverage:", len(REQUIRED) - len(missing), "/", len(REQUIRED))
    for name in missing:
        print("  MISSING:", name)
    print("Kodi 21 runtime testing: NOT PERFORMED")
    print("Critical dialog input/confirmation semantics: NOT VERIFIED")
    print("Xbox controller testing: NOT PERFORMED")
    if errors or missing:
        print("RESULT: NOT READY to activate as a skin")
        return 1
    print("RESULT: FILE COVERAGE ONLY; NOT READY to activate without runtime and dialog review")
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
