import unittest
from pathlib import Path
from xml.etree import ElementTree as ET
import struct
import zlib
ROOT=Path(__file__).resolve().parents[1]

class DirectHomeTests(unittest.TestCase):
    def setUp(self):self.root=ET.parse(ROOT/'1080i/Home.xml')

    def test_each_home_page_has_direct_correct_tiles(self):
        for section,id in [('movies','201'),('tvshows','202'),('sports','206'),('kids','208')]:
            node=self.root.find(".//control[@id='"+id+"']")
            self.assertEqual(node.get('type'),'list')
            self.assertEqual(node.findtext('content'),'plugin://plugin.program.vexora/?section='+section+'&action=tiles')

    def test_movie_and_tv_widgets_cannot_leak_into_sports(self):
        for section,id in [('movies','300'),('tvshows','400')]:
            group=self.root.find(".//control[@id='"+id+"']")
            self.assertEqual(group.findtext('visible'),'String.IsEqual(Window(Home).Property(vexora.section),'+section+')')
            rows=[n.text for n in group.iter('content') if 'action=catalogue' in (n.text or '')]
            prefix='movies_' if section=='movies' else 'tv_'
            self.assertEqual(len(rows),2)
            self.assertTrue(all('category='+prefix in r for r in rows))
        sports=next(n for n in self.root.findall('./controls/control') if n.findtext('visible')=='String.IsEqual(Window(Home).Property(vexora.section),sports)' and n.get('type')=='group')
        self.assertFalse(any('catalogue' in (n.text or '') or 'tmdb' in (n.text or '') for n in sports.iter('content')))

    def test_custom_lettering_keeps_native_controls_and_4k_asset_dimensions(self):
        keys=['home','movies','tvshows','sports','livetv','addons','settings']
        for id,key in list(enumerate(keys,101)) + [(108,'kids')]:
            node=self.root.find(".//control[@id='"+str(id)+"']")
            self.assertEqual(node.get('type'),'button')
            self.assertTrue(node.findall('onclick'))
            for tag,suffix in [('texturefocus','-focus'),('texturenofocus','')]:
                texture=node.findtext(tag)
                self.assertEqual(texture,'navigation/'+key+suffix+'.png')
                data=(ROOT/'media'/texture).read_bytes()
                self.assertEqual(struct.unpack('>II',data[16:24]),(int(node.findtext('width'))*2,140))
                if suffix:
                    offset=8;compressed=b''
                    while offset<len(data):
                        size=struct.unpack('>I',data[offset:offset+4])[0]
                        if data[offset+4:offset+8]==b'IDAT':compressed+=data[offset+8:offset+8+size]
                        offset+=12+size
                    self.assertEqual(tuple(zlib.decompress(compressed)[1:4]),(182,255,67))

    def test_posters_and_addon_tiles_use_silver_focus(self):
        for layout in self.root.findall('.//focusedlayout'):
            textures=list(layout.iter('texture'))
            self.assertTrue(any(t.get('colordiffuse') in ('FFBCC6CC','FF9AA7AF') for t in textures))
            self.assertFalse(any(t.get('colordiffuse')=='FFB6FF43' for t in textures))

    def test_kids_tab_order_and_rows_are_strictly_separate(self):
        nav=self.root.find(".//control[@id='100']")
        labels=[n.findtext('label') for n in nav.findall('control')]
        self.assertEqual(labels,['Home','Movies','TV Shows','Kids','Sports','Live TV','Add-ons','Settings'])
        group=self.root.find(".//control[@id='500']")
        self.assertEqual(group.findtext('visible'),'String.IsEqual(Window(Home).Property(vexora.section),kids)')
        contents=[n.text for n in group.iter('content')]
        self.assertEqual(len(contents),3)
        self.assertEqual([c for c in contents if 'action=kids_catalogue' in c], [
            'plugin://plugin.program.vexora/?action=kids_catalogue&category=animated',
            'plugin://plugin.program.vexora/?action=kids_catalogue&category=family'])
        self.assertTrue(all(not any(word in content for word in ('movies_latest','sports','trending')) for content in contents))

    def test_power_menu_is_reachable_and_actions_are_distinct(self):
        power=self.root.find(".//control[@id='109']")
        self.assertEqual(power.findtext('onclick'),'ActivateWindow(shutdownmenu)')
        for button in self.root.findall(".//control[@id='100']/control"):
            self.assertEqual(button.findtext('onup'),'109')
        menu=ET.parse(ROOT/'1080i/DialogButtonMenu.xml')
        self.assertEqual(menu.find(".//control[@id='901']/onclick").text,'Quit()')
        force=menu.find(".//control[@id='902']")
        self.assertIn('action=force_close',force.findall('onclick')[-1].text)
        self.assertEqual(force.findtext('visible'),'System.Platform.Windows + !System.Platform.UWP')

    def test_power_close_stays_focusable_when_uwp_force_option_is_hidden(self):
        menu=ET.parse(ROOT/'1080i/DialogButtonMenu.xml')
        close=menu.find(".//control[@id='901']")
        for tag in ('onup','ondown'):
            routes=close.findall(tag)
            self.assertEqual(routes[0].get('condition'),'System.Platform.Windows + !System.Platform.UWP')
            self.assertEqual(routes[0].text,'902')
            self.assertEqual(routes[-1].text,'901')


    def test_controller_rows_use_actions_not_overridden_by_grouplist(self):
        routes = {'201':('102','310'),'310':('201','311'),'311':('310','301'),
                  '202':('103','320'),'320':('202','321'),'321':('320','401'),
                  '208':('108','510'),'510':('208','511'),'511':('510','108')}
        for id,(up,down) in routes.items():
            row=self.root.find(".//control[@id='"+id+"']")
            self.assertEqual(row.findtext('onup'),'SetFocus('+up+')')
            self.assertEqual(row.findtext('ondown'),'SetFocus('+down+')')
        for id,tab in [('300','102'),('400','103'),('500','108')]:
            group=self.root.find(".//control[@id='"+id+"']")
            self.assertEqual(group.findtext('onup'),'SetFocus('+tab+')')


    def test_grouplist_navigation_has_no_unnamed_layout_stops(self):
        # Kodi replaces direct-child up/down actions with sibling IDs, even
        # for layout groups. ID zero strands focus before the poster group.
        all_ids=[n.get('id') for n in self.root.iter('control') if n.get('id')]
        self.assertEqual(len(all_ids),len(set(all_ids)))
        for id in ('300','400','500'):
            group=self.root.find(".//control[@id='"+id+"']")
            children=group.findall('control')
            self.assertTrue(all(n.get('id') and n.get('id')!='0' for n in children))
            first_row=children[2]
            self.assertEqual(first_row.get('type'),'group')
            self.assertIsNotNone(first_row.find(".//control[@type='list']"))
