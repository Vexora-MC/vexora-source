# Vexora skin — early Kodi 21 development

This is an **original** Vexora interface, not a modification of Xenon.

## Included assets
The eight approved images and transparent logo were copied from the project's main branch into `skin.vexora/media/` as original Git blobs. The installer and splash images remain on main for the separate installer workflow.

## Current UI
`1080i/Home.xml` displays seven distinct backgrounds with the logo as a separate element. Music is excluded. Movies and TV Shows are separate.

The navigation switches the home-section background. Additional actions invoke Kodi's native movie library, TV-show library, TV channels, add-on browser and settings windows. Sports is a placeholder until legitimate sources are configured. No third-party content is bundled.

## Not yet ready to install
The skin is **not Kodi-runtime-tested** and is missing required production skin windows, focus styling, fonts/texture fallback verification, and media browsing widgets. Do not activate this skin on your main Kodi installation. Use a disposable Kodi 21 test profile only after packaging and validation. A recovery path back to the default skin will be documented before testing.

## Planned next steps
1. Validate XML, fonts and native window actions in Kodi 21.
2. Build usable list/library windows and reliable remote focus indicators.
3. Add optional, source-based widgets with no bundled streaming content.
4. Package a Fire TV performance profile and test rollback.

## Platform testing priority
1. Windows PC (first development/test target)
2. Xbox (controller navigation and compatibility)
3. Android TV
4. Fire TV Stick

## Windows staging and static checks
From the repository root on Windows with Python installed:

```powershell
python skin.vexora/tools/validate_skin.py
python -m unittest discover -s skin.vexora/tools -p "test_*.py"
powershell -ExecutionPolicy Bypass -File skin.vexora/tools/stage_windows.ps1
```

The PowerShell command stages a **separate preview folder** on your Desktop. It refuses to overwrite an existing folder and **does not touch the Kodi profile**. This is deliberately not a production installer.

The validator checks XML syntax, all original artwork files, seven navigation labels, and duplicate Home control IDs. Passing static checks does **not** prove Kodi compatibility or controller focus behavior. Kodi runtime testing and a recovery path must precede activation.

## Focus and preview packaging
The main menu now has explicit left/right focus paths for keyboard and Xbox controller testing, with a small green focus texture. Down moves to available secondary actions. Controller behavior has **not** yet been verified in Kodi.

Build a non-destructive ZIP preview on Windows:

```powershell
python skin.vexora/tools/package_preview.py
```

This produces `vexora-skin-preview.zip` in the repository root, refuses to overwrite an existing archive, and does **not** install or activate anything. It is a development snapshot, not a certified installable skin. Do not switch away from Estuary until a safe recovery process and runtime checks are complete.

## New native-window prototypes (not ready for activation)
- `Includes.xml` shares original Vexora background/header elements.
- `MyVideoNav.xml` sketches a selectable Kodi library list.
- `DialogOK.xml` and `DialogConfirm.xml` are **visual prototypes only**. Their message bindings and confirmation result behavior are not yet verified against Kodi 21 and must not be relied on for installation or consent.

**Important:** These windows have not been runtime-tested, and other mandatory skin windows are missing. This branch is not a working or safe replacement for Estuary. No installable release has been produced.

## Readiness audit (Windows and Xbox)
Run `python skin.vexora/tools/preview_readiness.py` from the repository root to see which essential Kodi interface windows are still missing. A nonzero exit code means **do not activate** the skin. This is deliberately stricter than the packaging script, which only produces an inspection ZIP.

The PNG validator now checks image signatures, IHDR size/checksum, dimensions and an end marker. This is a lightweight integrity check, not full image decoding.

**Do not treat a passing GitHub Actions run as Kodi runtime validation.** The skin is still under construction.
