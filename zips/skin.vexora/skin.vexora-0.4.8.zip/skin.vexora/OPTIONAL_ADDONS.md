# Optional test add-ons: TMDB Movies and Rising Tides

Target: Kodi 21 Omega on Windows. These are optional third-party integrations, not dependencies of the Vexora skin.

## Desired experience
1. The user selects Movies (TMDB Movies) or Sports (Rising Tides).
2. If the relevant plugin is installed and enabled, open its entry point.
3. If missing, show a clear prompt asking permission to install it from an **already installed and trusted** repository.
4. Kodi handles installation, dependency prompts and errors. Never install silently.
5. If its repository is absent, show repository setup instructions; do not invent repository URLs or force Unknown Sources.

## Verified Kodi mechanisms
- `System.HasAddon(plugin.id)` to check for installed add-ons.
- `InstallAddon(plugin.id)` for Kodi-managed installation, only when the ID and repository are verified.
- `RunAddon(plugin.id)` or a plugin-specific `ActivateWindow(Videos,plugin://...,return)` route for installed add-ons; test the correct route in Kodi.
- `ActivateWindow(AddonBrowser)` to open Kodi's built-in manager.

Official documentation: https://kodi.wiki/view/List_of_built-in_functions

## Identity and provenance blockers
**TMDB Movies**: verified upstream source is https://github.com/angelitto2005/repository.angelitto with Kodi add-on ID `plugin.video.tmdbmovies`, declared version `1.1.320` at time of inspection, provider Angelitto. Official file: `all/plugin.video.tmdbmovies/addon.xml`. Repository source: https://angelitto2005.github.io/repository.angelitto/. Home button opens `plugin://plugin.video.tmdbmovies/` only if Kodi reports installed; otherwise opens the add-on browser. This is not yet a repository auto-installer, and Kodi runtime behaviour is untested. Redistribution permission has not been established.

**Rising Tides**: user-supplied add-on ID `plugin.video.Rising.Tides`; repository URL `http://mullafabz.xyz/Repository/K19` (preserve `/K19`); repository archive `repository.Rising.Tides.zip`. These details are **not independently verified** against a current upstream `addon.xml`. The URL uses plain HTTP and must not be fetched or installed automatically. Home Sports button conditionally opens `plugin://plugin.video.Rising.Tides/` only if installed; otherwise opens Kodi's add-on manager. No repository is bundled. Validate plugin ID, availability, compatibility, licensing and user consent before shipping an installer.

Until verified, Vexora displays their names and provides access to Kodi's add-on manager. It does **not** download, install, run, package or redistribute either add-on.

## Acceptance tests
- User confirms which specific repositories and plugin IDs they want.
- Check official upstream addon.xml and repository addon.xml; record versions, license, URLs and Kodi 21 compatibility.
- No automatic install or repository activation without informed consent.
- Installed/disabled/missing states behave distinctly; Cancel leaves Kodi unchanged.
- Controller focus returns to Vexora on exit.
- Test legal, authorised content only.

## Installer-first repository provisioning (design decision)
The installer must disclose both required repositories and offer Install Vexora or Cancel setup, with no individual repository skip option. Both repositories are required for a completed installation.

- Angelitto: `https://angelitto2005.github.io/repository.angelitto/`; independently verify the actual repository addon ID, ZIP location, hashes/signatures where provided, license, and Kodi 21 compatibility before provisioning.
- Rising Tides: user-supplied `http://mullafabz.xyz/Repository/K19`, ZIP name `repository.Rising.Tides.zip`, and plugin ID `plugin.video.Rising.Tides`. HTTP is not transport-authenticated: do not automatically fetch, trust, or install from it. Require an independently verifiable secure distribution channel and permission before enabling provisioning.
- If either repository cannot be securely verified or installed, stop setup with an error; do not bypass security checks.
- Once a trusted repository is installed and enabled, an absent plugin can be offered using Kodi's native add-on installation UI, after explicit confirmation. Never assume `System.HasAddon` alone verifies enablement or a usable plugin entry point.
- On repository failure, preserve existing Kodi repositories and settings; show an actionable error and avoid modifying unrelated add-ons.

**Current implementation status:** mandatory repository provisioning is a documented target, not a working installer capability. The current Home.xml fallback opens AddonBrowser; it does not itself prompt to install a particular plugin. Do not advertise one-click install until tested.
