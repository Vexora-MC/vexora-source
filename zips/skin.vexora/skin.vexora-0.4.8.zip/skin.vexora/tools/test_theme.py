import unittest
from pathlib import Path
from xml.etree import ElementTree as E
ROOT=Path(__file__).resolve().parents[1]

class ThemeTests(unittest.TestCase):
    def test_shared_defaults_and_every_texture_exist(self):
        includes=E.parse(ROOT/'1080i/Includes.xml')
        self.assertIsNotNone(includes.find("include[@file='Defaults.xml']"))
        defaults=E.parse(ROOT/'1080i/Defaults.xml')
        kinds={n.get('type') for n in defaults.findall('default')}
        self.assertTrue({'button','radiobutton','spincontrolex','sliderex','slider','scrollbar','progress'}.issubset(kinds))
        for filename in ('Defaults.xml','DialogAddonSettings.xml','DialogSettings.xml','DialogNumeric.xml','DialogSlider.xml'):
            for n in E.parse(ROOT/'1080i'/filename).iter():
                if 'texture' in n.tag and n.text:
                    self.assertTrue((ROOT/'media'/n.text).is_file(),filename+': '+n.text)

    def test_settings_and_input_dialogs_keep_native_control_contracts(self):
        for filename in ('DialogAddonSettings.xml','DialogSettings.xml'):
            r=E.parse(ROOT/'1080i'/filename)
            ids={n.get('id') for n in r.iter('control')}
            self.assertTrue({'2','3','5','6','7','8','9','10','11','12','13','14','28','29','30'}.issubset(ids))
        r=E.parse(ROOT/'1080i/DialogNumeric.xml')
        self.assertTrue({str(n) for n in range(10,24)}.issubset({n.get('id') for n in r.iter('control')}))
        self.assertTrue({'10','11','12','13','14'}.issubset({n.get('id') for n in E.parse(ROOT/'1080i/DialogSlider.xml').iter('control')}))

    def test_notification_and_background_progress_are_compact(self):
        for filename in ('DialogNotification.xml','DialogExtendedProgressBar.xml'):
            r=E.parse(ROOT/'1080i'/filename)
            self.assertFalse(any(n.text=='VexoraBackground' for n in r.iter('include')))
            self.assertTrue(any(n.get('colordiffuse')=='FFB6FF43' for n in r.iter('texture')))

    def test_every_declared_direction_targets_a_real_control(self):
        for filename in (ROOT/'1080i').glob('*.xml'):
            r=E.parse(filename)
            ids={n.get('id') for n in r.iter('control') if n.get('id')}
            for n in r.iter():
                if n.tag in ('onup','ondown','onleft','onright','defaultcontrol') and n.text and n.text.isdigit() and n.text!='0':
                    self.assertIn(n.text,ids,filename.name+': '+n.tag+' -> '+n.text)
