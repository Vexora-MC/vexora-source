"""Original Vexora angular navigation lettering. Artwork source, MIT licensed.

No external font or logo pixels are copied. Labels use custom geometric
strokes inspired by the existing logo's broad weight and clipped diagonals.
Textures are authored at 2x UI resolution for 4K without letter distortion.
"""
import math
from pathlib import Path
from PIL import Image, ImageDraw

GLYPHS = {
 'A': [[(8,90),(38,10),(48,10),(78,90)],[(22,62),(64,62)]],
 'D': [[(12,90),(12,10),(60,10),(76,27),(76,73),(60,90),(12,90)]],
 'E': [[(76,10),(12,10),(12,90),(76,90)],[(12,50),(65,50)]],
 'G': [[(76,22),(63,10),(27,10),(12,25),(12,75),(27,90),(76,90),(76,52),(49,52)]],
 'H': [[(12,10),(12,90)],[(76,10),(76,90)],[(12,50),(76,50)]],
 'I': [[(20,10),(68,10)],[(44,10),(44,90)],[(20,90),(68,90)]],
 'K': [[(12,10),(12,90)],[(76,10),(12,56),(76,90)]],
 'L': [[(12,10),(12,90),(76,90)]],
 'M': [[(12,90),(12,10),(44,49),(76,10),(76,90)]],
 'N': [[(12,90),(12,10),(76,90),(76,10)]],
 'O': [[(28,10),(60,10),(76,26),(76,74),(60,90),(28,90),(12,74),(12,26),(28,10)]],
 'P': [[(12,90),(12,10),(62,10),(76,24),(76,39),(62,52),(12,52)]],
 'R': [[(12,90),(12,10),(62,10),(76,24),(76,39),(62,52),(12,52)],[(48,52),(78,90)]],
 'S': [[(76,10),(27,10),(12,25),(12,39),(27,50),(61,50),(76,63),(76,76),(61,90),(12,90)]],
 'T': [[(8,10),(80,10)],[(44,10),(44,90)]],
 'V': [[(8,10),(37,90),(49,90),(80,10)]],
 'W': [[(8,10),(23,90),(44,54),(65,90),(80,10)]],
 '-': [[(20,50),(68,50)]],
}
TABS = [('home','HOME',140),('movies','MOVIES',180),('tvshows','TV SHOWS',200),
        ('kids','KIDS',120),('sports','SPORTS',180),
        ('addons','ADD-ONS',190),('settings','SETTINGS',220)]


def generate(output=None):
    output = Path(output) if output else Path(__file__).resolve().parents[1] / 'media/navigation'
    output.mkdir(parents=True, exist_ok=True)
    scale, height = 4, 70
    for key, text, width in TABS:
        mask = Image.new('L', (width*scale, height*scale))
        draw = ImageDraw.Draw(mask)
        unit = 0.285*scale
        advance = 86*unit
        total = sum(40*unit if ch==' ' else advance for ch in text)
        x, y = (width*scale-total)/2, 19*scale
        for ch in text:
            if ch==' ':x += 40*unit;continue
            for stroke in GLYPHS[ch]:
                for (ax,ay),(bx,by) in zip(stroke,stroke[1:]):
                    dx,dy=bx-ax,by-ay;length=math.hypot(dx,dy)
                    nx,ny=-dy/length*8,dx/length*8
                    draw.polygon([(x+(ax+nx)*unit,y+(ay+ny)*unit),
                                  (x+(bx+nx)*unit,y+(by+ny)*unit),
                                  (x+(bx-nx)*unit,y+(by-ny)*unit),
                                  (x+(ax-nx)*unit,y+(ay-ny)*unit)],fill=255)
            x+=advance
        for focus in (False,True):
            image=Image.new('RGBA',mask.size, (182,255,67,255) if focus else (0,0,0,0))
            ink=Image.new('RGBA',mask.size)
            pixels=ink.load()
            for row in range(height*scale):
                shade=int(248-55*row/(height*scale))
                color=(16,24,16,255) if focus else (shade,shade+min(3,255-shade),shade+min(5,255-shade),255)
                ImageDraw.Draw(ink).line((0,row,width*scale,row),fill=color)
            image.paste(ink,(0,0),mask)
            image.resize((width*2,height*2),Image.Resampling.LANCZOS).save(output/(key+('-focus' if focus else '')+'.png'))
    return output

if __name__=='__main__':print(generate())
