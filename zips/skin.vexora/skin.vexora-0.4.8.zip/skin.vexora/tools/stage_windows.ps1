# Copies a development snapshot into a standalone folder for inspection.
# Does NOT activate the skin, edit Kodi settings, or overwrite an existing add-on.
param(
  [string]$Destination = "$env:USERPROFILE\\Desktop\\Vexora-Windows-Preview"
)
$ErrorActionPreference = "Stop"
$Source = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$Dest = [System.IO.Path]::GetFullPath($Destination)
if ([System.IO.Path]::GetFullPath($Source).TrimEnd('\\') -eq $Dest.TrimEnd('\\')) {
  throw "Destination must differ from source."
}
if (Test-Path -LiteralPath $Dest) {
  throw "Destination already exists. Choose a new empty location: $Dest"
}
New-Item -ItemType Directory -Path $Dest | Out-Null
Copy-Item -LiteralPath (Join-Path $Source "addon.xml") -Destination $Dest
Copy-Item -LiteralPath (Join-Path $Source "1080i") -Destination $Dest -Recurse
Copy-Item -LiteralPath (Join-Path $Source "media") -Destination $Dest -Recurse
Write-Host "Staged Vexora preview at $Dest"
Write-Host "This is NOT a tested or installable Kodi skin. Kodi settings were not changed."
