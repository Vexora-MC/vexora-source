"""Prevent missing playback windows and cursor state regressions."""
import unittest
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

class PlaybackControlsTests(unittest.TestCase):
    def test_audio_and_video_controls_expose_native_actions(self):
        for name in ('VideoOSD.xml', 'MusicOSD.xml'):
            with self.subTest(window=name):
                root = ET.parse(ROOT / '1080i' / name)
                actions = {x.text for x in root.iter('onclick')}
                self.assertTrue({'PlayerControl(Play)', 'PlayerControl(Stop)',
                                 'PlayerControl(Forward)', 'PlayerControl(Rewind)',
                                 'Action(VolumeDown)', 'Action(VolumeUp)', 'Mute'}.issubset(actions))
                slider = root.find(".//control[@type='slider']")
                self.assertEqual(slider.findtext('action'), 'seek')
                self.assertEqual(slider.findtext('orientation'), 'horizontal')
                ids = {c.get('id') for c in root.iter('control') if c.get('id')}
                for c in root.iter('control'):
                    for direction in ('onleft', 'onright', 'onup', 'ondown'):
                        if c.findtext(direction):self.assertIn(c.findtext(direction), ids)
                self.assertFalse(root.findall('.//include'))

    def test_cursor_states_and_status_overlays_are_not_placeholders(self):
        root = ET.parse(ROOT / '1080i/Pointer.xml')
        self.assertEqual({c.get('id') for c in root.iter('control')}, {'1', '2', '3', '4'})
        for texture in root.iter('texture'):
            self.assertTrue((ROOT / 'media' / texture.text).is_file())
        for name,info in [('DialogVolumeBar.xml', 'Player.Volume'), ('DialogSeekBar.xml', 'Player.Progress')]:
            tree = ET.parse(ROOT / '1080i' / name)
            self.assertIn(info, {n.text for n in tree.iter('info')})
            self.assertFalse(tree.findall('.//include'))
