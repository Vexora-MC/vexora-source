"""Build a non-installing ZIP snapshot of the Vexora skin for Windows testing.

Run: python skin.vexora/tools/package_preview.py
Does not modify any Kodi directory or settings.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / "vexora-skin-preview.zip"
sys.path.insert(0, str(Path(__file__).resolve().parent))
from validate_skin import validate


def main():
    errors = validate(ROOT)
    if errors:
        raise SystemExit("Validation failed:\n" + "\n".join(errors))
    if OUT.exists():
        raise SystemExit(f"Refusing to overwrite existing preview: {OUT}")
    paths = [ROOT / "addon.xml", *sorted((ROOT / "1080i").rglob("*")), *sorted((ROOT / "media").rglob("*"))]
    with ZipFile(OUT, "x", compression=ZIP_DEFLATED) as archive:
        for path in paths:
            if path.is_file():
                archive.write(path, arcname=str(Path("skin.vexora") / path.relative_to(ROOT)))
    print(f"Created non-installing preview archive: {OUT}")
    print("Not yet validated in Kodi. Do not activate in your main Kodi profile.")


if __name__ == "__main__":
    main()
