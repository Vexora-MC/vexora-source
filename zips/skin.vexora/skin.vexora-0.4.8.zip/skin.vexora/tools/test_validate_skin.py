"""Run: python -m unittest discover -s skin.vexora/tools -p "test_*.py" """
from pathlib import Path
from tempfile import TemporaryDirectory
import shutil
import unittest

from validate_skin import validate, ROOT


class SkinValidationTests(unittest.TestCase):
    def test_repository_skin_structure(self):
        self.assertEqual([], validate(ROOT))

    def test_missing_remote_keyboard_key_is_rejected(self):
        import xml.etree.ElementTree as ET
        with TemporaryDirectory() as temp:
            copy = Path(temp) / 'skin.vexora'
            shutil.copytree(ROOT, copy)
            path = copy / '1080i' / 'DialogKeyboard.xml'
            tree = ET.parse(path)
            controls = tree.getroot().find('controls')
            controls.remove(controls.find("control[@id='120']"))
            tree.write(path, encoding='utf-8')
            self.assertTrue(any('DialogKeyboard.xml: missing Kodi control IDs' in issue
                                for issue in validate(copy)))

    def test_native_addon_management_actions_are_reachable(self):
        import xml.etree.ElementTree as ET
        root = ET.parse(ROOT / '1080i' / 'AddonBrowser.xml').getroot()
        controls = {item.get('id'): item for item in root.findall('.//control') if item.get('id')}
        self.assertEqual(controls['9011'].findtext('onclick'), 'UpdateAddonRepos')
        self.assertEqual(controls['9012'].findtext('onclick'), 'InstallFromZip')
        self.assertEqual(controls['50'].findtext('onright'), '9011')
        self.assertEqual(controls['9011'].findtext('onright'), '9012')
        self.assertEqual(controls['9012'].findtext('onup'), '50')

    def test_missing_asset_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / "skin.vexora"
            shutil.copytree(ROOT, copy)
            (copy / "media" / "vexoramchome.png").unlink()
            self.assertTrue(any("vexoramchome.png" in issue for issue in validate(copy)))

    def test_optional_addon_route_tampering_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / "skin.vexora"
            shutil.copytree(ROOT, copy)
            home = copy / "1080i" / "Home.xml"
            content = home.read_text(encoding="utf-8")
            content = content.replace("plugin://plugin.program.vexora/?action=tile", "plugin://wrong.plugin/")
            home.write_text(content, encoding="utf-8")
            self.assertTrue(any("Unsafe or incorrect Vexora routed action" in issue for issue in validate(copy)))

    def test_invalid_png_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / "skin.vexora"
            shutil.copytree(ROOT, copy)
            (copy / "media" / "focus-pixel.png").write_bytes(b"not a PNG")
            self.assertTrue(any("Invalid PNG header" in issue for issue in validate(copy)))

    def test_corrupt_pixel_data_is_rejected(self):
        with TemporaryDirectory() as temp:
            copy = Path(temp) / 'skin.vexora'
            shutil.copytree(ROOT, copy)
            path = copy / 'media' / 'focus-pixel.png'
            data = bytearray(path.read_bytes())
            data[45] ^= 1
            path.write_bytes(data)
            self.assertTrue(any('Invalid PNG header' in issue for issue in validate(copy)))


if __name__ == "__main__":
    unittest.main()
