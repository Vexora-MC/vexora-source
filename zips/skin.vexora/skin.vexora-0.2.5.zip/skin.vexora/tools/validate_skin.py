"""Static validation for the original Vexora Kodi skin (no Kodi runtime required)."""
from pathlib import Path
import sys
import struct
import zlib
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SECTIONS = {
    "home": "vexoramchome.png",
    "movies": "vexoramcmovies.png",
    "tvshows": "vexoramctvshows.png",
    "sports": "vexoramcsports.png",
    "livetv": "vexoramclivetv.png",
    "addons": "vexoramcaddons.png",
    "settings": "vexoramcsettings.png",
}
ASSETS = set(SECTIONS.values()) | {"vexoramc.png", "focus-pixel.png"}


def validate(root=ROOT):
    errors = []
    parsed = {}
    for path in (root / "addon.xml", *sorted((root / "1080i").glob("*.xml"))):
        try:
            parsed[path.name] = ET.parse(path)
        except (ET.ParseError, OSError) as exc:
            errors.append(f"{path.relative_to(root)}: {exc}")
    for filename in sorted(ASSETS):
        path = root / "media" / filename
        if not path.is_file() or path.stat().st_size == 0:
            errors.append(f"Missing/empty image: media/{filename}")
        else:
            try:
                data = path.read_bytes()
                if data[:8] != bytes((137, 80, 78, 71, 13, 10, 26, 10)):
                    raise ValueError("missing PNG signature")
                if len(data) < 33 or data[12:16] != b"IHDR":
                    raise ValueError("missing IHDR chunk")
                if struct.unpack(">I", data[8:12])[0] != 13:
                    raise ValueError("incorrect IHDR size")
                if zlib.crc32(data[12:29]) != struct.unpack(">I", data[29:33])[0]:
                    raise ValueError("invalid IHDR checksum")
                width, height = struct.unpack(">II", data[16:24])
                if not (0 < width <= 16384 and 0 < height <= 16384):
                    raise ValueError("invalid image dimensions")
                if b"IEND" not in data[-64:]:
                    raise ValueError("missing PNG end marker")
                offset, compressed = 8, bytearray()
                while offset < len(data):
                    size = struct.unpack('>I', data[offset:offset + 4])[0]
                    kind = data[offset + 4:offset + 8]
                    payload = data[offset + 8:offset + 8 + size]
                    crc = struct.unpack('>I', data[offset + 8 + size:offset + 12 + size])[0]
                    if zlib.crc32(kind + payload) != crc:
                        raise ValueError('invalid PNG chunk checksum')
                    if kind == b'IDAT':
                        compressed.extend(payload)
                    offset += 12 + size
                if not compressed:
                    raise ValueError('missing pixel data')
                decoder = zlib.decompressobj()
                decoder.decompress(compressed, 256 * 1024 * 1024)
                if not decoder.eof or decoder.unused_data:
                    raise ValueError('invalid compressed pixels')
            except (ValueError, struct.error, zlib.error) as exc:
                errors.append(f"Invalid PNG header: media/{filename}: {exc}")
    home = root / "1080i" / "Home.xml"
    if "Home.xml" in parsed:
        tree = parsed["Home.xml"]
        textures = {x.text for x in tree.iter("texture") if x.text}
        for name in sorted(ASSETS - {"focus-pixel.png"}):
            if name not in textures:
                errors.append(f"Home.xml does not reference {name}")
        labels = [x.text for x in tree.iter("label") if x.text]
        for expected in ("Home", "Movies", "TV Shows", "Sports", "Live TV", "Add-ons", "Settings"):
            if expected not in labels:
                errors.append(f"Missing navigation item: {expected}")
        if "Music" in labels:
            errors.append("Unexpected Music navigation item")
        ids = [x.attrib.get("id") for x in tree.iter("control") if x.attrib.get("id")]
        nav_ids = {str(i) for i in range(101, 108)}
        if not nav_ids.issubset(set(ids)):
            errors.append("Main menu navigation control missing")
        for button in tree.iter("control"):
            if button.attrib.get("id") in nav_ids:
                if button.find("texturefocus") is None:
                    errors.append("Menu control missing focus texture: " + button.attrib["id"])
                for direction in ("onleft", "onright"):
                    targets = [n.text for n in button.findall(direction)]
                    if not any(target in nav_ids for target in targets):
                        errors.append("Invalid menu focus route: " + button.attrib["id"] + " " + direction)
        if len(ids) != len(set(ids)):
            errors.append("Duplicate control ids in Home.xml")
    else:
        errors.append("Missing 1080i/Home.xml")
    for required in ("Includes.xml", "MyVideoNav.xml", "DialogOK.xml", "DialogConfirm.xml"):
        if not (root / "1080i" / required).is_file():
            errors.append(f"Missing Kodi interface file: {required}")
    for dialog in ("DialogOK.xml", "DialogConfirm.xml"):
        file = root / "1080i" / dialog
        if dialog in parsed:
            tree = parsed[dialog]
            for control in tree.iter("control"):
                if control.attrib.get("type") == "button" and control.find("onclick") is not None:
                    errors.append(f"{dialog}: dialog result must not be overridden by onclick")
    if "Home.xml" in parsed:
        home_tree = parsed["Home.xml"]
        integrations = {
            "201": "plugin.video.tmdbmovies",
            "206": "plugin.video.Rising.Tides",
        }
        for control_id, addon_id in integrations.items():
            controls = [node for node in home_tree.iter("control") if node.get("id") == control_id]
            if len(controls) != 1:
                errors.append(f"Expected one optional add-on button {control_id}")
                continue
            actions = [(node.get("condition", ""), node.text or "") for node in controls[0].findall("onclick")]
            section = "movies" if control_id == "201" else "sports"
            expected = {("", f"ActivateWindow(Videos,plugin://plugin.program.vexora/?section={section},return)")}
            if set(actions) != expected:
                errors.append(f"Unsafe or incorrect Vexora routed action: {control_id}")
            if controls[0].find("onup") is None:
                errors.append(f"Optional add-on button missing controller navigation: {control_id}")
    expected_dialog_ids = {
        "DialogConfirm.xml": {"1", "9", "10", "11"},
        "DialogOK.xml": {"1", "9", "10"},
        "DialogKeyboard.xml": {str(i) for i in range(100, 180)} | {"8", "32", "300", "301", "302", "303", "304", "305", "306", "308", "309", "310", "311", "312"},
        "FileManager.xml": {"20", "21", "101", "102"},
        "DialogMediaSource.xml": {"2", "10", "11", "12", "13", "14", "18", "19"},
        "DialogAddonInfo.xml": {"6", "7", "8", "9", "10", "12", "13", "14"},
        "FileBrowser.xml": {"411", "412", "413", "414", "415", "450"},
        "SettingsCategory.xml": {"2", "3", "5", "6", "7", "8", "9", "10", "13", "20"},
    }
    for filename, required_ids in expected_dialog_ids.items():
        if filename not in parsed:
            errors.append(f'Missing Kodi native interface: {filename}')
        if filename in parsed:
            actual = {control.get("id") for control in parsed[filename].iter("control")}
            missing_ids = required_ids - actual
            if missing_ids:
                errors.append(f"{filename}: missing Kodi control IDs: {sorted(missing_ids)}")
    return errors


if __name__ == "__main__":
    failures = validate()
    for failure in failures:
        print("FAIL:", failure)
    if failures:
        sys.exit(1)
    print("PASS: Vexora XML, original artwork references, and menu structure")
