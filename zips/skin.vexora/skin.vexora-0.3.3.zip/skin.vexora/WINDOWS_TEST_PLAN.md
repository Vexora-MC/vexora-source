# Vexora Windows-first Kodi 21 test plan

## Status
Development only. No validated installable build exists yet. Do not replace your working Kodi skin.

## Preflight (no Kodi changes)
1. Clone or download the `feature/installer-foundation` branch.
2. Run `python skin.vexora/tools/validate_skin.py`.
3. Run `python -m unittest discover -s skin.vexora/tools -p "test_*.py"`.
4. Run `python skin.vexora/tools/package_preview.py` to produce a ZIP snapshot for inspection.
5. Confirm every approved original image is included under `skin.vexora/media/`.

## Runtime testing — blocked until skin is complete
Use a separate Kodi 21 installation/profile on Windows. Do not activate Vexora in your normal profile until all mandatory windows, fonts and focus controls are confirmed.

When ready, verify:
- Home displays approved Vexora art and logo without unwanted X branding.
- Home, Movies, TV Shows, Sports, Live TV, Add-ons and Settings all show their distinct backgrounds; Music is absent.
- Keyboard arrow keys, Enter, Escape and Backspace work.
- Xbox controller D-pad/left stick, A and B buttons work.
- Focus is always visible and no menu action traps focus.
- Movies and TV Shows open their **separate** Kodi library views.
- Empty libraries, disconnected PVR and missing add-ons fail gracefully.
- Information and confirmation dialogs correctly return OK, Yes and No.
- Window navigation and settings are usable without a mouse.
- Kodi can be restored to Estuary without losing settings or media library.

## Recovery
Until a known-good recovery procedure has been verified on Windows, **do not activate this preview as a skin**. Staging scripts do not edit Kodi settings.

## Platform order
1. Windows PC
2. Xbox
3. Android TV
4. Fire TV Stick

No third-party streaming sources or Xenon assets are included.
