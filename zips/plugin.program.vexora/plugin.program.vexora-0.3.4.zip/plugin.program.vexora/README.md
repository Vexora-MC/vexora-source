# Vexora Wizard for Kodi 21

Install this add-on from Vexora Repository under Program add-ons. It is the entry point for complete Vexora build setup, including the original skin, both mandatory repositories, affected-file/database backup and skin activation.

See `docs/WINDOWS_INSTALL.md` in the development repository for the canonical source → ZIP → repository → wizard flow and recovery instructions. Full end-to-end runtime verification is still in progress; do not call this a verified release.

Both repository archives are fetched over HTTPS, structurally validated and checked against reviewed SHA-256 values before setup. Kodi performs their installation and optional video add-on dependency resolution. Neither third-party repository nor video add-on ZIPs are bundled. All seven home sections are provided; no Music menu is present.

The native ZIP picker requires user selection; Kodi does not expose an InstallFromZip(path) builtin. The wizard displays each validated ZIP location and checks installed/enabled state after Kodi returns. Cancelling or failing either repository fails whole setup. Unknown sources are controlled by Kodi and are not silently enabled by the wizard.

Backups and durable transaction journals live in the wizard's profile addon_data directory. Interrupted installs block replacement until recovery. The source checkout includes an offline restore tool; close Kodi before using it.
