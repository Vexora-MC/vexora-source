"""Close the current Kodi host only; never terminate other processes."""
import ntpath


def request_force_close(host_name, confirm, terminate):
    if ntpath.basename(host_name).lower() != 'kodi.exe':
        raise RuntimeError('Force close is restricted to the current Windows Kodi process')
    if not confirm():
        return False
    terminate(0)
    return True


def force_close_kodi():
    import os
    import ctypes
    import xbmc
    import xbmcgui
    if not xbmc.getCondVisibility('System.Platform.Windows'):
        xbmcgui.Dialog().notification('Vexora', 'Force close is available on Windows only. Use Close Kodi.')
        return
    path = ctypes.create_unicode_buffer(32768)
    length = ctypes.windll.kernel32.GetModuleFileNameW(None, path, len(path))
    if not length or length >= len(path):
        raise RuntimeError('Unable to verify the current Kodi process')
    request_force_close(path.value,
        lambda: xbmcgui.Dialog().yesno('Force close Kodi',
            'Close Kodi immediately? Unsaved settings and current operations may be lost. Try Close Kodi first.',
            nolabel='Cancel', yeslabel='Force close'), os._exit)
