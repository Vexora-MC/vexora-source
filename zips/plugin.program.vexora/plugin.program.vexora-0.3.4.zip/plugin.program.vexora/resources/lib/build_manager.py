"""Whole-build wizard: validated payload, backup, native installs and activation."""
import hashlib
import json
import shutil
import sqlite3
import time
import uuid
import os
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from contextlib import closing

from .repository_download import fetch_both_required_repositories
from .runtime_setup import prepare_repository_cache, run_repository_setup, verify_repositories
from .optional_catalogue import OPTIONAL_REPOSITORIES
from .optional_setup import reviewed_repository_packages, install_build_repositories
from .safe_paths import validate_relative_path, has_link_in_path


def validate_skin_payload(folder):
    folder = Path(folder)
    manifest = json.loads((folder / 'manifest.json').read_text(encoding='utf-8'))
    path = folder / 'skin.vexora.zip'
    if (manifest.get('id') != 'skin.vexora' or manifest.get('kodi_major') != 21
            or hashlib.sha256(path.read_bytes()).hexdigest() != manifest.get('sha256')):
        raise ValueError('Bundled Vexora skin integrity check failed')
    with ZipFile(path) as archive:
        seen = set()
        if len(archive.infolist()) > 1000 or sum(x.file_size for x in archive.infolist()) > 128 * 1024 * 1024:
            raise ValueError('Oversized skin payload')
        for info in archive.infolist():
            validate_relative_path(info.filename)
            if (not info.filename.startswith('skin.vexora/') or info.filename.casefold() in seen
                    or info.flag_bits & 1 or (info.external_attr >> 16) & 0o170000 == 0o120000):
                raise ValueError('Unsafe bundled skin archive')
            seen.add(info.filename.casefold())
        root = ET.fromstring(archive.read('skin.vexora/addon.xml'))
        if root.get('id') != 'skin.vexora' or root.get('version') != manifest.get('version'):
            raise ValueError('Bundled skin identity mismatch')
        if archive.testzip() is not None:
            raise ValueError('Corrupt bundled skin')
    return path, manifest


def verify_installed_skin(skin_zip, installed_path):
    """Require installed files to match the validated payload before activation."""
    root = Path(installed_path)
    if (not root.is_dir() or has_link_in_path(root)
            or any(p.is_symlink() for p in root.rglob('*'))):
        raise ValueError('Invalid installed Vexora skin location')
    with ZipFile(skin_zip) as archive:
        expected = {info.filename[len('skin.vexora/'):]:
                    hashlib.sha256(archive.read(info)).hexdigest()
                    for info in archive.infolist() if not info.is_dir()}
    if snapshot_hashes(root) != expected:
        raise ValueError('Installed Vexora skin differs from validated payload')


def save_journal(folder, journal):
    path = Path(folder) / 'transaction.json'
    temporary = path.with_suffix('.tmp')
    with temporary.open('w', encoding='utf-8') as output:
        output.write(json.dumps(journal, indent=2, sort_keys=True))
        output.flush()
        os.fsync(output.fileno())
    temporary.replace(path)


def snapshot_hashes(path):
    if path.is_file():
        return {'': hashlib.sha256(path.read_bytes()).hexdigest()}
    return {item.relative_to(path).as_posix(): hashlib.sha256(item.read_bytes()).hexdigest()
            for item in path.rglob('*') if item.is_file()}


def backup_build(home, userdata, backup_parent, previous_skin):
    """Back up only affected files; use SQLite's backup API for the live DB."""
    home, userdata, backup_parent = map(Path, (home, userdata, backup_parent))
    for root in (home, userdata, backup_parent):
        if has_link_in_path(root):
            raise ValueError('Backup paths must not contain symlinks')
    folder = backup_parent / ('build-' + uuid.uuid4().hex)
    folder.mkdir(parents=True)
    journal = {'format': 1, 'state': 'backing_up', 'home': str(home.resolve()),
               'userdata': str(userdata.resolve()), 'previous_skin': previous_skin,
               'paths': [], 'created': []}
    save_journal(folder, journal)
    targets = [('home', 'addons/' + name) for name in
               ('skin.vexora', 'repository.angelitto', 'repository.Rising.Tides', *OPTIONAL_REPOSITORIES)]
    targets += [('userdata', 'guisettings.xml')]
    for scope, relative in targets:
        source = (home if scope == 'home' else userdata) / relative
        record = {'scope': scope, 'path': relative}
        if source.exists():
            if (has_link_in_path(source)
                    or (source.is_dir() and any(p.is_symlink() for p in source.rglob('*')))):
                raise ValueError('Affected profile data contains a symlink')
            destination = folder / scope / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            if source.is_dir():
                shutil.copytree(source, destination)
            else:
                shutil.copy2(source, destination)
            record['hashes'] = snapshot_hashes(destination)
            journal['paths'].append(record)
        else:
            journal['created'].append(record)
    for database in (userdata / 'Database').glob('Addons*.db'):
        if has_link_in_path(database):
            raise ValueError('Invalid add-on database path')
        destination = folder / 'userdata' / 'Database' / database.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(str(database))) as source, closing(sqlite3.connect(str(destination))) as target:
            source.backup(target)
        journal['paths'].append({'scope': 'userdata', 'path': 'Database/' + database.name,
                                 'hashes': snapshot_hashes(destination)})
    journal['state'] = 'backed_up'
    save_journal(folder, journal)
    return folder, journal


def wait_for_skin_activation(current_skin, confirmation_visible, monitor,
                             clock=time.monotonic, timeout=35):
    """Do not report success while Kodi can still revert an unconfirmed skin."""
    deadline = clock() + timeout
    stable_since = None
    while clock() < deadline:
        now = clock()
        if current_skin() == 'skin.vexora' and not confirmation_visible():
            if stable_since is None:
                stable_since = now
            elif now - stable_since >= 2:
                return
        else:
            stable_since = None
        if monitor.waitForAbort(.25):
            raise RuntimeError('Kodi stopped during skin confirmation')
    raise RuntimeError('Vexora skin was not confirmed or Kodi reverted the change')


def handoff_skin_version_update(expected_version, lookup, dialog, execute):
    """Use Kodi's repository UI for an existing different-version skin.

    InstallAddon only installs missing IDs in Kodi 21. Do not start a backup
    transaction or wait for an install command that cannot perform an update.
    Kodi owns version selection, origin consent and dependency resolution.
    """
    skin = lookup('skin.vexora')
    if skin is None or skin.get('version') == expected_version:
        return False
    dialog.ok('Update Vexora skin in Kodi',
              'Installed skin version: ' + str(skin.get('version', 'unknown')) +
              '. This Wizard requires ' + expected_version +
              '. Kodi will open Vexora Repository skins. Select Vexora, then Update '
              'or Versions and choose the matching repository version. Complete Kodi\'s '
              'confirmation, then reopen the Wizard and Install Vexora build. '
              'If that version is unavailable, update the Wizard first. '
              'No build files have been changed.')
    execute('UpdateAddonRepos')
    execute('ActivateWindow(AddonBrowser,addons://repository.vexora/xbmc.gui.skin/,return)')
    return True


def install_full_build():
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    from .kodi_status import get_addon

    dialog = xbmcgui.Dialog()
    if xbmc.getInfoLabel('System.BuildVersion').split('.')[0] != '21':
        raise ValueError('Vexora requires Kodi 21 Omega')
    backup_parent = Path(xbmcvfs.translatePath('special://profile/')) / 'addon_data' / 'plugin.program.vexora' / 'backups'
    for previous in backup_parent.glob('build-*/transaction.json'):
        state = json.loads(previous.read_text(encoding='utf-8')).get('state')
        if state not in ('backing_up', 'backed_up', 'installed', 'restored'):
            raise RuntimeError('An interrupted build needs recovery before reinstalling: ' + str(previous.parent))
    if not dialog.yesno('Install complete Vexora build',
                        'Back up affected settings and add-ons, install the Vexora interface and BOTH '
                        'Angelitto, Rising Tides, JewRepo, The Crew, Bugatsinho and The Loop repositories, then activate Vexora? '
                        'Optional video add-ons install from their tiles. Cancel stops the entire setup.'):
        return
    payload = Path(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))) / 'resources' / 'build'
    skin_zip, manifest = validate_skin_payload(payload)
    if handoff_skin_version_update(manifest['version'], get_addon, dialog, xbmc.executebuiltin):
        return
    progress = xbmcgui.DialogProgress()
    progress.create('Vexora full build', 'Validating all six publisher repositories before changing Kodi')
    try:
        packages = fetch_both_required_repositories()
        additional_packages = reviewed_repository_packages()
        if progress.iscanceled():
            return
        cache = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/repositories')
        prepare_repository_cache(packages, cache)
    finally:
        progress.close()
    home = xbmcvfs.translatePath('special://home/')
    userdata = xbmcvfs.translatePath('special://profile/')
    backup_parent = Path(userdata) / 'addon_data' / 'plugin.program.vexora' / 'backups'
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettingValue',
        'params': {'setting': 'lookandfeel.skin'}})))
    previous_skin = response['result']['value']
    backup, journal = backup_build(home, userdata, backup_parent, previous_skin)
    try:
        journal['state'] = 'installing_skin'
        save_journal(backup, journal)
        skin = get_addon('skin.vexora')
        if not skin or skin.get('version') != manifest['version']:
            xbmc.executebuiltin('InstallAddon(skin.vexora)', True)
        deadline = time.monotonic() + 60
        monitor = xbmc.Monitor()
        while time.monotonic() < deadline:
            skin = get_addon('skin.vexora')
            if skin and skin.get('version') == manifest['version']:
                break
            if monitor.waitForAbort(.5):
                raise RuntimeError('Kodi stopped during build installation')
        else:
            raise RuntimeError('Vexora skin installation incomplete')
        if not skin['enabled']:
            xbmc.executebuiltin('EnableAddon(skin.vexora)', True)
        verify_installed_skin(skin_zip, xbmcvfs.translatePath(xbmcaddon.Addon('skin.vexora').getAddonInfo('path')))
        journal['state'] = 'installing_repositories'
        save_journal(backup, journal)
        if not run_repository_setup(packages=packages, consent=True):
            raise RuntimeError('Mandatory repository setup cancelled')
        if verify_repositories(get_addon):
            raise RuntimeError('Both mandatory repositories must be ready')
        install_build_repositories(additional_packages, get_addon,
            lambda command: xbmc.executebuiltin(command, True), monitor.waitForAbort,
            lambda addon_id: xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('path')))
        journal['state'] = 'activating_skin'
        save_journal(backup, journal)
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.SetSettingValue',
            'params': {'setting': 'lookandfeel.skin', 'value': 'skin.vexora'}})))
        if response.get('result') is not True:
            raise RuntimeError('Skin activation declined or failed')
        wait_for_skin_activation(xbmc.getSkinDir,
            lambda: xbmc.getCondVisibility('Window.IsActive(yesnodialog)'), monitor)
        if xbmc.getSkinDir() != 'skin.vexora' or verify_repositories(get_addon):
            raise RuntimeError('Final build verification failed')
        verify_installed_skin(skin_zip, xbmcvfs.translatePath(xbmcaddon.Addon('skin.vexora').getAddonInfo('path')))
        journal['state'] = 'installed'
        save_journal(backup, journal)
        dialog.ok('Vexora build installed', 'Vexora is active and all six build repositories are installed and verified. '
                  'Choose Movies or Sports to install their optional add-ons. Backup: ' + str(backup))
        return True
    except Exception as exc:
        journal['state'], journal['error'] = 'recovery_required', str(exc)
        save_journal(backup, journal)
        dialog.ok('Vexora build incomplete', str(exc) + '\nRecovery backup: ' + str(backup) +
                  '\nClose Kodi before restoring this backup. The build has not passed final verification.')
        raise
