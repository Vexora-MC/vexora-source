"""Portable relative paths: reject Windows aliases even on Linux CI."""
import re

_RESERVED = re.compile(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", re.I)


def validate_relative_path(name):
    """Return canonical components or raise ValueError before filesystem access."""
    if not isinstance(name, str) or not name or "\\" in name:
        raise ValueError("Invalid relative path")
    parts = name.split("/")
    for part in parts:
        if (part in ("", ".", "..") or part.endswith((" ", "."))
                or any(ord(ch) < 32 or ch in '<>:"|?*' for ch in part)
                or _RESERVED.match(part)):
            raise ValueError("Unsafe portable path")
    return tuple(parts)


def has_link_in_path(path):
    """Reject links/reparse points without requiring access above a UWP sandbox.

    The target itself must be inspectable. Windows app containers can deny
    lstat on an ancestor even though the target is accessible. Only that
    specific ancestor access-denied error is tolerated; all other errors fail.
    Descendants must still be checked separately by callers before use.
    """
    import stat
    from pathlib import Path
    target = Path(path)
    for candidate in (target, *target.parents):
        try:
            metadata = candidate.lstat()
        except FileNotFoundError:
            continue  # A not-yet-created backup/cache still has checked parents.
        except PermissionError as error:
            if candidate != target and getattr(error, 'winerror', None) == 5:
                continue
            raise
        if (stat.S_ISLNK(metadata.st_mode)
                or getattr(metadata, 'st_file_attributes', 0) & 0x400):
            return True
    return False
