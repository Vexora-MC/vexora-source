"""Original catalogue pointers for Kodi's native publisher-hosted installs.

No third-party archive, artwork or implementation is redistributed here.
Kodi Omega AddonInfoBuilder supports metadata/path relative to datadir.
"""
from xml.etree import ElementTree as ET
from urllib.parse import urlsplit
from .repository_sources import SOURCES
from .optional_catalogue import OPTIONAL_REPOSITORIES

PRIMARY_INDEXES = {
    'repository.angelitto': 'https://raw.githubusercontent.com/angelitto2005/repository.angelitto/main/repo/zips/',
    'repository.Rising.Tides': 'https://mullafabz.xyz/Plugins/K19/Plugins/',
}


def catalogue_entry(addon_id):
    source = (SOURCES if addon_id in SOURCES else OPTIONAL_REPOSITORIES)[addon_id]
    package = source['zip_url']
    base, filename = package.rsplit('/', 1)
    if urlsplit(package).scheme != 'https':
        raise ValueError('Publisher package must use HTTPS')
    addon = ET.Element('addon', id=addon_id, name=addon_id, version=source['version'],
                       **{'provider-name': 'Upstream publisher'})
    extension = ET.SubElement(addon, 'extension', point='xbmc.addon.repository')
    directory = ET.SubElement(extension, 'dir')
    upstream = PRIMARY_INDEXES.get(addon_id) or source['primary_index']
    for tag, value in [('info', upstream + 'addons.xml'),
                       ('checksum', upstream + 'addons.xml.md5'), ('datadir', upstream)]:
        ET.SubElement(directory, tag).text = value
    metadata = ET.SubElement(addon, 'extension', point='xbmc.addon.metadata')
    ET.SubElement(metadata, 'path').text = filename
    ET.SubElement(metadata, 'summary').text = 'Required Vexora repository, installed from its publisher'
    ET.SubElement(metadata, 'platform').text = 'all'
    return addon, base + '/'
