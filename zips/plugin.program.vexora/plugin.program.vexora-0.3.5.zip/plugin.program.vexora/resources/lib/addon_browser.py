"""Artwork-first installed video add-on browser for Kodi 21.

Kodi owns installed add-on metadata and artwork. This module does not install
third-party add-ons or pretend repository catalog entries are verified.
"""
import json
from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcplugin


def installed_video_addons():
    query = {"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddons",
             "params": {"type": "xbmc.addon.video", "enabled": "all",
                        "properties": ["name", "thumbnail", "fanart", "enabled", "version"]}}
    response = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
    if "error" in response:
        raise RuntimeError("Kodi could not enumerate installed video add-ons")
    addons = response.get("result", {}).get("addons", [])
    if not isinstance(addons, list):
        raise RuntimeError("Kodi returned invalid add-on catalog")
    return [a for a in addons if isinstance(a, dict) and a.get("addonid")
            and isinstance(a.get("enabled"), bool)]


SECTION_ADDONS = {"movies": ("plugin.video.tmdbmovies",),
                  "sports": ("plugin.video.Rising.Tides",)}


def show_installed_tiles(handle, base_url, section):
    """Render clickable native Kodi tiles using add-ons' own artwork."""
    if section not in SECTION_ADDONS:
        raise ValueError("Unknown Vexora section")
    xbmcplugin.setContent(handle, "addons")
    xbmcplugin.setPluginCategory(handle, "Movies" if section == "movies" else "Sports")
    supported = set(SECTION_ADDONS[section])
    installed = {addon["addonid"]: addon for addon in installed_video_addons()
                 if addon["addonid"] in supported}
    for addon_id in SECTION_ADDONS[section]:
        addon = installed.get(addon_id)
        name = (addon or {}).get("name") or {
            "plugin.video.tmdbmovies": "TMDB Movies",
            "plugin.video.Rising.Tides": "Rising Tides",
        }[addon_id]
        # Only installed add-ons have artwork confirmed by Kodi. Do not
        # misrepresent a stock icon as the original add-on's own artwork.
        art = (addon or {}).get("thumbnail") or (
            "special://home/addons/skin.vexora/media/vexoramc" + section + ".png")
        state = 'Disabled â€” select to enable' if addon and not addon['enabled'] else (
            'Installed' if addon else 'Available to install')
        item = xbmcgui.ListItem(label=name + '  [' + state + ']')
        item.setArt({"icon": art, "thumb": art,
                     "fanart": (addon or {}).get("fanart") or ""})
        item.setProperty("IsPlayable", "false")
        action = "open" if addon and addon['enabled'] else "install"
        url = base_url + "?" + urlencode({"action": action, "addon": addon_id})
        xbmcplugin.addDirectoryItem(handle, url, item, False)
    xbmcplugin.endOfDirectory(handle)


def show_wizard_menu(handle, base_url):
    """Root navigation is read-only, including when Kodi reloads the skin."""
    xbmcplugin.setContent(handle, 'addons')
    xbmcplugin.setPluginCategory(handle, 'Vexora Wizard')
    for label, action in [('Install Vexora build', 'build'), ('Kodi add-ons', 'browse'),
                          ('Recovery backups', 'recovery'), ('Add-on management', 'manage')]:
        item = xbmcgui.ListItem(label=label)
        icon = 'special://home/addons/plugin.program.vexora/resources/icon.png'
        item.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle, base_url + '?' + urlencode({'action': action}), item, False)
    xbmcplugin.endOfDirectory(handle)


def home_catalogue(section):
    from .optional_catalogue import home_entries
    return home_entries(section)


def show_home_tiles(handle, base_url, section):
    """Read-only direct home tiles, with distinct movie/sports/TV membership."""
    from .optional_setup import read_choices
    from .readiness import assess_installed_plugin
    import xbmcvfs
    from pathlib import Path
    installed = {item['addonid']: item for item in installed_video_addons()}
    try:
        state = read_choices(Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/optional-setup.json')))
    except (OSError, ValueError):
        state = {'results': {}}
    xbmcplugin.setContent(handle, 'addons')
    for addon in home_catalogue(section):
        current = installed.get(addon['id'])
        ready = current and current.get('enabled')
        result = state.get('results', {}).get(addon['id'], {})
        status = 'Installed' if ready else ('Disabled' if current else 'Available')
        if addon.get('unavailable') and not ready:status = 'Unavailable - source verification pending'
        elif result.get('status') == 'failed' and not ready:status = 'Failed - select to retry'
        item = xbmcgui.ListItem(label=addon['name'])
        item.setLabel2(status)
        item.setProperty('vexora.state', status)
        art = (current or {}).get('thumbnail') or addon.get('icon') or ''
        if not art:art = 'special://home/addons/skin.vexora/media/vexoramc' + ('movies' if section == 'tvshows' else section) + '.png'
        item.setArt({'icon': art, 'thumb': art, 'fanart': (current or {}).get('fanart') or ''})
        item.setProperty('IsPlayable', 'false')
        url = base_url + '?' + urlencode({'action': 'tile', 'key': addon['key'], 'section': section})
        # Navigate ready add-ons as native Kodi folders. This avoids attempting
        # ActivateWindow(Videos, ...) while the home widget owns a modal dialog.
        # Keep the wizard route for disabled/missing/broken dependencies.
        is_folder = False
        if ready:
            readiness = assess_installed_plugin(addon['id'])
            if readiness.get('ready'):
                url = 'plugin://' + addon['id'] + '/' + addon.get('route', '')
                is_folder = True
        xbmcplugin.addDirectoryItem(handle, url, item, is_folder)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
