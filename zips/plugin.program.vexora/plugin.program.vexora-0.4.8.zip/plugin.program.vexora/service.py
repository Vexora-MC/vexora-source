from resources.lib.startup_tasks import run
run()
