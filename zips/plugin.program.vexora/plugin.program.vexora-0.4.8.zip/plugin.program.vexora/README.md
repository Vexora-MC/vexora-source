# Vexora Wizard

One Kodi-native Wizard installs the complete Vexora interface, six publisher repository sources and optional video add-ons through Kodi. The same package and repository source serve Windows and UWP/Xbox; platform differences are handled at runtime.

Use Kodi 21. The Wizard backs up affected data before installation, verifies native completion and dependencies, and activates the matching skin. New backups support native setup-state undo through the Wizard. Full file/database restoration requires Kodi stopped and the separate offline recovery tool. Native undo does not downgrade packages or overwrite a live database.

Production-format release candidate: physical Xbox installation/controller/playback acceptance is pending. See UNIVERSAL_INSTALL.md and UNIVERSAL_VALIDATION.md in the distribution. No separate Xbox ZIP or channel exists.
