"""Persist a confirmed skin through Kodi's own settings window save action."""
import time
from pathlib import Path
from xml.etree import ElementTree as ET


def saved_skin(path):
    path = Path(path)
    if path.stat().st_size > 2 * 1024 * 1024:
        raise ValueError('Oversized Kodi settings file')
    root = ET.fromstring(path.read_bytes())
    setting = root.find(".//setting[@id='lookandfeel.skin']")
    return setting.text if setting is not None else None


def persist_skin(expected, active_skin, read_saved, open_settings, back,
                 current_window, modal, wait, clock=time.monotonic, timeout=15):
    """Never accept a command as success; verify Kodi's saved XML selection.

    No direct settings-file writes. Back is sent only to the known settings
    window with no modal dialog, after the caller completed skin confirmation.
    """
    if active_skin() != expected:
        raise RuntimeError('Skin changed before saving settings')
    if read_saved() == expected:
        return
    open_settings()
    deadline = clock() + timeout
    while clock() < deadline:
        if active_skin() != expected:
            raise RuntimeError('Skin reverted before settings could be saved')
        if current_window() == 10032 and not modal():
            break
        if wait(.1):
            raise RuntimeError('Kodi stopped before saving skin selection')
    else:
        raise RuntimeError('Kodi Interface settings did not become ready to save')
    back()
    while clock() < deadline:
        if active_skin() != expected:
            raise RuntimeError('Skin reverted while saving settings')
        if read_saved() == expected:
            return
        if wait(.1):
            raise RuntimeError('Kodi stopped while saving skin selection')
    raise RuntimeError('Kodi did not save the selected skin; installation remains incomplete')


def persist_vexora_skin():
    import xbmc
    import xbmcgui
    import xbmcvfs
    monitor = xbmc.Monitor()
    path = xbmcvfs.translatePath('special://profile/guisettings.xml')
    def read():
        try:
            return saved_skin(path)
        except (OSError, ValueError, ET.ParseError):
            return None
    persist_skin('skin.vexora', xbmc.getSkinDir, read,
        lambda: xbmc.executebuiltin('ActivateWindow(10032)', True),
        lambda: xbmc.executebuiltin('Action(Back)', True),
        xbmcgui.getCurrentWindowId,
        lambda: xbmc.getCondVisibility('System.HasModalDialog'), monitor.waitForAbort)
    xbmc.executebuiltin('ActivateWindow(Home)', True)
