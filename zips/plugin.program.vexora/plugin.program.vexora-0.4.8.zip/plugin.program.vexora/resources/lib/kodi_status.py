"""Kodi JSON-RPC adapter for dependency status.

Read-only: never enables, disables, downloads or installs add-ons.
"""
import json
import re
from pathlib import Path
from xml.etree import ElementTree as ET
import xbmc


class KodiStatusError(RuntimeError):
    pass


def _runtime_addon(addon_id):
    """Verify core API metadata from Kodi's installation, never the user profile."""
    if not isinstance(addon_id, str) or not re.fullmatch(
            r"(?:xbmc\.(?:core|python|gui)|kodi\.binary\.(?:global|instance)\.[a-z]+)", addon_id):
        return None
    import xbmcvfs
    path = Path(xbmcvfs.translatePath("special://xbmc/addons/")) / addon_id / "addon.xml"
    try:
        if path.is_symlink() or path.parent.is_symlink() or path.stat().st_size > 512000:
            return None
        root = ET.fromstring(path.read_text(encoding="utf-8"))
        if root.tag != "addon" or root.get("id") != addon_id or not root.get("version"):
            return None
        return {"enabled": True, "version": root.get("version"), "runtime": True}
    except (OSError, UnicodeError, ET.ParseError):
        return None


def get_addon(addon_id):
    """Return installed Kodi add-on version and enabled state, or None if absent.

    Kodi JSON-RPC's Addons.GetAddonDetails is the source of truth. Errors
    other than a missing add-on fail closed rather than implying success.
    """
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled", "version"]},
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (ValueError, TypeError) as exc:
        raise KodiStatusError("Invalid Kodi JSON-RPC response") from exc
    if "error" in response:
        # Kodi reports unknown add-ons as an Invalid params error (-32602).
        if response["error"].get("code") == -32602:
            return _runtime_addon(addon_id)
        raise KodiStatusError("Kodi add-on query failed")
    details = response.get("result", {}).get("addon")
    if not isinstance(details, dict) or details.get("addonid") != addon_id:
        raise KodiStatusError("Kodi returned unexpected add-on details")
    if not isinstance(details.get("enabled"), bool):
        raise KodiStatusError("Kodi did not report enabled state")
    return {"enabled": details["enabled"], "version": details.get("version")}
