"""Show caught installer tracebacks locally as well as in Kodi's log."""
import traceback


def report_setup_error(dialog, log, level, error):
    details = 'Vexora setup incomplete: ' + type(error).__name__ + ': ' + str(error)
    details += '\n\n' + ''.join(traceback.format_exception(type(error), error, error.__traceback__))
    details += '\nSetup has not passed verification. Existing backups and installed repositories are retained.'
    log(details, level)
    dialog.textviewer('Vexora setup error details', details)
