"""Read mandatory dependencies from Kodi addon.xml without downloading code.

The manifest may change upstream; inspect the installed version after Kodi resolves it.
"""
import xml.etree.ElementTree as ET
import re


class DependencyError(ValueError):
    pass


def required_dependencies(addon_xml):
    """Return required dependency IDs and minimum versions, excluding optional imports."""
    try:
        root = ET.fromstring(addon_xml)
    except (ET.ParseError, TypeError) as exc:
        raise DependencyError("Invalid addon.xml") from exc
    if root.tag != "addon" or not root.get("id"):
        raise DependencyError("Missing add-on identity")
    found = []
    for item in root.findall("./requires/import"):
        addon_id = item.get("addon")
        if not addon_id:
            raise DependencyError("Dependency has no ID")
        if item.get("optional", "").lower() in ("true", "1"):
            continue
        found.append({"id": addon_id, "minimum_version": item.get("minversion") or item.get("version")})
    return found



def _version_parts(value):
    """Parse Kodi's epoch:upstream-revision form; reject malformed inputs."""
    if not isinstance(value, str) or not re.fullmatch(
            r"(?:[0-9]+:)?[0-9][A-Za-z0-9.+_@~]*(?:-[A-Za-z0-9.+_@~]+)?", value):
        return None
    epoch, separator, tail = value.partition(":")
    epoch, value = (int(epoch), tail) if separator else (0, value)
    upstream, _, revision = value.lower().partition("-")
    return epoch, upstream, revision


def _compare_component(left, right):
    """Compare alternating text and numeric runs with Kodi's tilde ordering.

    Contract: Kodi Omega xbmc/addons/AddonVersion.cpp. Components are
    case-insensitive; numeric runs compare as integers, tilde precedes
    both ordinary text and the end of a component.
    """
    while left and right:
        a, b = left[0], right[0]
        if a.isdigit() and b.isdigit():
            la = re.match(r"[0-9]+", left).group()
            rb = re.match(r"[0-9]+", right).group()
            if int(la) != int(rb):
                return 1 if int(la) > int(rb) else -1
            left, right = left[len(la):], right[len(rb):]
        else:
            if a != b:
                if a == "~" or b == "~":
                    return -1 if a == "~" else 1
                if a.isdigit() != b.isdigit():
                    return -1 if a.isdigit() else 1
                return 1 if a > b else -1
            left, right = left[1:], right[1:]
    if left == right:
        return 0
    remaining = left or right
    order = -1 if remaining.startswith("~") else 1
    return order if left else -order


def _meets_minimum(actual, minimum):
    if not minimum:
        return True
    actual_parts, minimum_parts = _version_parts(actual), _version_parts(minimum)
    if actual_parts is None or minimum_parts is None:
        return False
    if actual_parts[0] != minimum_parts[0]:
        return actual_parts[0] > minimum_parts[0]
    upstream = _compare_component(actual_parts[1], minimum_parts[1])
    return upstream > 0 or (upstream == 0 and
        _compare_component(actual_parts[2], minimum_parts[2]) >= 0)


def dependency_status(dependencies, get_addon):
    """Report missing, disabled, or available dependencies; do not install anything."""
    result = []
    for dependency in dependencies:
        addon_id = dependency["id"]
        try:
            addon = get_addon(addon_id)
        except (RuntimeError, KeyError):
            addon = None
        if addon is None:
            status = "missing"
        elif not addon.get("enabled", False):
            status = "disabled"
        elif not _meets_minimum(addon.get("version"), dependency.get("minimum_version")):
            status = "version_mismatch"
        else:
            status = "runtime" if addon.get("runtime", False) else "available"
        result.append({"id": addon_id, "status": status})
    return result
