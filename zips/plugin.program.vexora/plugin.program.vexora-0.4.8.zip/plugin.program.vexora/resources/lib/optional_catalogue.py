"""Verified optional publisher catalogue. No third-party ZIPs or artwork bundled."""
OPTIONAL_REPOSITORIES = {'repository.jewrepo': {'version': '1.6.0',
                        'zip_url': 'https://jewbmx.github.io/repository.jewrepo-1.6.0.zip',
                        'sha256': '588660ff242702618ea26f9487cac9782d02b7137f54cc79866b0d560842fde9',
                        'directories': [{'info': 'https://raw.githubusercontent.com/jewbmx/repo/master/addons.xml',
                                         'checksum': 'https://raw.githubusercontent.com/jewbmx/repo/master/addons.xml.md5',
                                         'datadir': 'https://raw.githubusercontent.com/jewbmx/repo/master/zips/'},
                                        {'info': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml',
                                         'checksum': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml.md5',
                                         'datadir': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/zips/'}],
                        'primary_index': 'https://raw.githubusercontent.com/jewbmx/repo/master/'},
 'repository.thecrew': {'version': '0.3.8',
                        'zip_url': 'https://team-crew.github.io/repository.thecrew-0.3.8.zip',
                        'sha256': '686e616ecd7d60906fd7975fe9ccaa09360c8cf0c65ba3431e6d81700b0f6ec0',
                        'directories': [{'info': 'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/addons.xml',
                                         'checksum': 'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/addons.xml.md5',
                                         'datadir': 'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip'},
                                        {'info': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml',
                                         'checksum': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml.md5',
                                         'datadir': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/zips/'},
                                        {'info': 'https://raw.githubusercontent.com/unhingedthemes/zips/main/_zips/addons.xml',
                                         'checksum': 'https://raw.githubusercontent.com/unhingedthemes/zips/main/_zips/addons.xml.md5',
                                         'datadir': 'https://raw.githubusercontent.com/unhingedthemes/zips/main/_zips/'},
                                        {'info': 'https://github.com/OldManJax/repository.animaniac/raw/master/addons.xml',
                                         'checksum': 'https://github.com/OldManJax/repository.animaniac/raw/master/addons.xml.md5',
                                         'datadir': 'https://github.com/OldManJax/repository.animaniac/raw/master/'},
                                        {'info': 'https://raw.githubusercontent.com/dobbelina/repository.dobbelina/master/addons.xml',
                                         'checksum': 'https://raw.githubusercontent.com/dobbelina/repository.dobbelina/master/addons.xml.md5',
                                         'datadir': 'https://raw.githubusercontent.com/dobbelina/repository.dobbelina/master/'}],
                        'primary_index': 'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/'},
 'repository.bugatsinho': {'version': '2.8',
                           'zip_url': 'https://bugatsinho.github.io/repo/repository.bugatsinho-2.8.zip',
                           'sha256': '879c916ca78f708fc5328d64d13b0fca5dbe0ca86041b69ddec60ddd9e90dcd4',
                           'directories': [{'info': 'https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/addons.xml',
                                            'checksum': 'https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/addons.xml.md5',
                                            'datadir': 'https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/_zips',
                                            'hashes': 'false'},
                                           {'info': 'https://raw.githubusercontent.com/teamuniversal/scrapers/master/_modules4all/zips/addons.xml',
                                            'checksum': 'https://raw.githubusercontent.com/teamuniversal/scrapers/master/_modules4all/zips/addons.xml.md5',
                                            'datadir': 'https://raw.githubusercontent.com/teamuniversal/scrapers/master/_modules4all/zips/',
                                            'hashes': 'false'},
                                           {'info': 'https://raw.githubusercontent.com/jsergio123/zips/master/addons.xml.gz',
                                            'checksum': 'https://raw.githubusercontent.com/jsergio123/zips/master/addons.xml.gz.sha256',
                                            'datadir': 'https://raw.githubusercontent.com/jsergio123/zips/master/',
                                            'artdir': 'https://raw.githubusercontent.com/jsergio123/zips/master/',
                                            'hashes': 'sha256'},
                                           {'info': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml',
                                            'checksum': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml.md5',
                                            'datadir': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/zips/'},
                                           {'info': 'https://raw.githubusercontent.com/bugatsinho/python-koding/master/addons.xml',
                                            'checksum': 'https://raw.githubusercontent.com/bugatsinho/python-koding/master/addons.xml.md5',
                                            'datadir': 'https://raw.githubusercontent.com/bugatsinho/python-koding/master/zips/'}],
                           'primary_index': 'https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/'},
 'repository.loop': {'version': '3.0.4',
                     'zip_url': 'https://loopaddon.uk/theloop/repository.loop-3.0.4.zip',
                     'sha256': '9d0addce2bf96831b3d77b85c38f6efda40eddc648b1277b89bf3bdbf20d0431',
                     'directories': [{'info': 'https://loopaddon.uk/zips19/addons.xml',
                                      'checksum': 'https://loopaddon.uk/zips19/addons.xml.md5',
                                      'datadir': 'https://loopaddon.uk/zips19/'},
                                     {'info': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml',
                                      'checksum': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/addons.xml.md5',
                                      'datadir': 'https://raw.githubusercontent.com/Gujal00/smrzips/master/zips/'}],
                     'user_agent': 'Kodi/21.3 (Windows NT 10.0; Win64; x64)',
                     'primary_index': 'https://loopaddon.uk/zips19/'}}

OPTIONAL_ADDONS = {
 'tmdb_movies': {'id': 'plugin.video.tmdbmovies', 'name': 'TMDB Movies',
                 'repository': 'repository.angelitto', 'verified_version': '1.1.323',
                 'icon': 'https://raw.githubusercontent.com/angelitto2005/repository.angelitto/main/all/zips/plugin.video.tmdbmovies/icon.png',
                 'sections': ['movies', 'tvshows'], 'route': ''},
 'rising': {'id': 'plugin.video.Rising.Tides', 'name': 'Rising Tides',
            'repository': 'repository.Rising.Tides', 'verified_version': '3.2.10.10',
            'icon': 'https://mullafabz.xyz/Plugins/K19/Plugins/plugin.video.Rising.Tides/icon.png',
            'sections': ['sports'], 'route': ''},
 'scrubs': {'id': 'plugin.video.scrubsv2',
            'name': 'Scrubs V2',
            'repository': 'repository.jewrepo',
            'verified_version': '5.1.42',
            'icon': 'https://raw.githubusercontent.com/jewbmx/repo/master/zips/plugin.video.scrubsv2/resources/images/icon.png',
            'sections': ['movies'],
            'route': ''},
 'crew': {'id': 'plugin.video.thecrew',
          'name': 'The Crew',
          'repository': 'repository.thecrew',
          'verified_version': '3.2.2',
          'icon': 'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/plugin.video.thecrew/icon.png',
          'sections': ['movies', 'sports'],
          'route': ''},
 'sporthd': {'id': 'plugin.video.sporthdme',
             'name': 'SportHD',
             'repository': 'repository.bugatsinho',
             'verified_version': '0.1.91',
             'icon': 'https://raw.githubusercontent.com/bugatsinho/bugatsinho.github.io/master/_zips/plugin.video.sporthdme/icon.png',
             'sections': ['sports'],
             'route': ''},
 'crew_sports': {'id': 'plugin.video.thecrew',
                 'name': 'The Crew Sports',
                 'repository': 'repository.thecrew',
                 'verified_version': '3.2.2',
                 'icon': 'https://raw.githubusercontent.com/thecrewwh/zips/master/matrix/_zip/plugin.video.thecrew/icon.png',
                 'sections': ['sports'],
                 'route': '?action=bluehat'},
 'loop': {'id': 'plugin.video.the-loop',
          'name': 'The Loop',
          'repository': 'repository.loop',
          'verified_version': '8.3',
          'icon': 'https://loopaddon.uk/zips19/plugin.video.the-loop/icon.png',
          'sections': ['sports'],
          'route': ''}}

def selected_addons(keys):
    """Deduplicate Crew movies/sports while preserving user selection order."""
    seen, result = set(), []
    for key in keys:
        if key not in OPTIONAL_ADDONS:
            raise ValueError('Unknown optional add-on')
        item = OPTIONAL_ADDONS[key]
        if item.get('unavailable'):
            raise ValueError(item['unavailable'])
        if item['id'] not in seen:
            result.append(item)
            seen.add(item['id'])
    return result


def home_entries(section):
    core = {'movies': {'key': 'tmdb_movies', 'id': 'plugin.video.tmdbmovies', 'name': 'TMDB Movies', 'route': '?mode=movies_menu'},
            'tvshows': {'key': 'tmdb_tv', 'id': 'plugin.video.tmdbmovies', 'name': 'TMDB TV Shows', 'route': '?mode=tv_menu'},
            'sports': {'key': 'rising', 'id': 'plugin.video.Rising.Tides', 'name': 'Rising Tides', 'route': ''}}
    if section == 'kids':
        return [{'key': 'tmdb_kids', 'id': 'plugin.video.tmdbmovies', 'name': 'TMDB Movies Kids', 'route': '?mode=navigator_genres&menu_type=movie'}]
    if section not in core:raise ValueError('Unknown home section')
    entries = [core[section]]
    keys = ('loop', 'sporthd', 'crew_sports') if section == 'sports' else tuple(OPTIONAL_ADDONS)
    for key in keys:
        addon = OPTIONAL_ADDONS[key]
        if (section in addon['sections'] and not (section == 'sports' and key == 'crew')
                and addon['id'] not in {item['id'] for item in entries}):
            entries.append(dict(addon, key=key))
    return entries

