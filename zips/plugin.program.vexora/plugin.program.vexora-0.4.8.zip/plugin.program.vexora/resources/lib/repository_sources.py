"""Verified Vexora repository source catalogue for the Windows test build.

These are source candidates, not an assertion that ZIP bytes have been
downloaded and cryptographically verified. The existing repository preflight
must validate each package before either repository can be installed.
"""
from urllib.parse import urlsplit

SOURCES = {
    "repository.angelitto": {
        "version": "1.0.2",
        "base_url": "https://angelitto2005.github.io/repository.angelitto/",
        "zip_url": "https://angelitto2005.github.io/repository.angelitto/repository.angelitto-1.0.2.zip",
        "test_addon": "plugin.video.tmdbmovies",
    },
    "repository.Rising.Tides": {
        "version": "1.1",
        "base_url": "https://mullafabz.xyz/Repository/K19/",
        "zip_url": "https://mullafabz.xyz/Repository/K19/repository.Rising.Tides.zip",
        "test_addon": "plugin.video.Rising.Tides",
        "test_addon_version": "3.2.10.9",
    },
}


def source_for(repo_id):
    """Return a source descriptor, refusing non-HTTPS or unknown repositories."""
    source = SOURCES.get(repo_id)
    if source is None:
        raise ValueError("Unknown mandatory repository")
    for key in ("base_url", "zip_url"):
        url = source.get(key)
        if url is not None:
            parsed = urlsplit(url)
            if parsed.scheme != "https" or not parsed.hostname or parsed.username:
                raise ValueError("Repository URL must be HTTPS")
    return dict(source)
