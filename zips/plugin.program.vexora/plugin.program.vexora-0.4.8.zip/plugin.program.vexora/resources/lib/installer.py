"""Kodi-facing installer orchestration. No external downloads or filesystem deletion."""
import time
from .manifest import plan


def prepare(data, selected_groups, is_installed):
    """Split a validated plan into installed, missing repositories and actionable add-ons."""
    items = plan(data, selected_groups)
    ready, installed, missing = [], [], []
    for item in items:
        if is_installed(item["id"]):
            installed.append(item["id"])
        elif not is_installed(item["repository"]):
            missing.append(item)
        else:
            ready.append(item)
    return {"ready": ready, "installed": installed, "missing_repositories": missing}


def install_ready(prepared, install_callback, is_installed, sleep=time.sleep,
                  timeout_seconds=60, interval_seconds=1):
    """Request installs sequentially and verify completion; report failures without deleting data."""
    if timeout_seconds <= 0 or interval_seconds <= 0:
        raise ValueError("Timeout and polling interval must be positive")
    results = []
    for item in prepared["ready"]:
        addon_id = item["id"]
        try:
            install_callback(addon_id)
            deadline = time.monotonic() + timeout_seconds
            while not is_installed(addon_id) and time.monotonic() < deadline:
                sleep(min(interval_seconds, max(0, deadline - time.monotonic())))
            results.append({"id": addon_id, "status": "installed" if is_installed(addon_id) else "unconfirmed"})
        except Exception as exc:
            results.append({"id": addon_id, "status": "error", "reason": str(exc)})
    return results
