"""Fail-closed repository setup coordinator for Vexora's two test apps.

Repository ZIP bytes must come from an independently verified HTTPS source.
No fallback to HTTP, no skip-repository option, and no plugin launch here.
Kodi's native add-on manager must resolve add-on dependencies separately.
"""
from .repository_preflight import REQUIRED, inspect_repository_zip, RepositoryPackageError

TEST_APPS = {
    "movies": {"repository": "repository.angelitto", "addon": "plugin.video.tmdbmovies"},
    "sports": {"repository": "repository.Rising.Tides", "addon": "plugin.video.Rising.Tides"},
}


class RepositorySetupError(ValueError):
    pass


def preflight_required_repositories(packages):
    """Require both repository archives and validate before any installation."""
    if not isinstance(packages, dict) or set(packages) != set(REQUIRED):
        raise RepositorySetupError("Both mandatory repository ZIPs are required")
    verified = {}
    for repo_id in REQUIRED:
        try:
            verified[repo_id] = inspect_repository_zip(packages[repo_id], repo_id)
        except RepositoryPackageError as exc:
            raise RepositorySetupError("Repository verification failed: " + repo_id) from exc
    return verified


def setup_required_repositories(packages, install, verify_installed, *, consent=False):
    """Run validated installs, then confirm both are enabled.

    install(repo_id, zip_bytes) and verify_installed(repo_id) are supplied by a
    Kodi runtime adapter. Never call this from a preview or untrusted source.
    Returns success only after BOTH repositories are confirmed installed.
    """
    if not consent:
        raise RepositorySetupError("Whole-setup consent required")
    verified = preflight_required_repositories(packages)
    for repo_id in REQUIRED:
        install(repo_id, packages[repo_id])
    if not all(verify_installed(repo_id) for repo_id in REQUIRED):
        raise RepositorySetupError("Mandatory repository setup incomplete")
    return verified
