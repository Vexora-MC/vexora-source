"""Offline sandbox deployment with durable backups and explicit rollback.

Never invoke on a live Kodi profile without separate user authorization.
"""
from pathlib import Path
import json
import os
import shutil
import tempfile
import uuid

from .deployment_plan import DeploymentError
from .safe_paths import validate_relative_path

ALLOWED_ROOTS = {"addons", "userdata", "media"}


def _safe_tree(root):
    root = Path(root).absolute()
    if not root.is_dir() or any(p.is_symlink() for p in (root, *root.parents)):
        raise DeploymentError("Expected a real directory")
    return root


def _contained(path, root):
    return path == root or path.is_relative_to(root)


def _check_file(path, root):
    if not _contained(path, root):
        raise DeploymentError("Path escapes directory")
    current = path
    while current != root:
        if current.is_symlink():
            raise DeploymentError("Symlinks are forbidden")
        current = current.parent
    if not path.is_file() or path.is_symlink():
        raise DeploymentError("Invalid staged file")


def _restore(profile, backup, journal):
    for relative in reversed(journal["created"]):
        (profile / relative).unlink(missing_ok=True)
    for relative in reversed(journal["overwritten"]):
        dest = profile / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(backup / "original" / relative, dest)


def rollback_test_profile(profile, backup):
    """Restore a completed test transaction from its backup journal."""
    profile, backup = _safe_tree(profile), _safe_tree(backup)
    if _contained(backup, profile) or _contained(profile, backup):
        raise DeploymentError("Backup and profile must be separate")
    _check_file(backup / "journal.json", backup)
    journal = json.loads((backup / "journal.json").read_text(encoding="utf-8"))
    if (not isinstance(journal, dict) or journal.get("profile") != str(profile.resolve())
            or any(not isinstance(journal.get(key), list) for key in ("created", "overwritten"))):
        raise DeploymentError("Invalid backup journal or wrong target profile")
    seen = set()
    for relative in journal["created"] + journal["overwritten"]:
        try:
            validate_relative_path(relative)
        except ValueError as exc:
            raise DeploymentError("Unsafe backup journal") from exc
        if relative.casefold() in seen:
            raise DeploymentError("Duplicate backup destination")
        seen.add(relative.casefold())
        parts = Path(relative).parts
        if (not parts or parts[0] not in ALLOWED_ROOTS or
                ".." in parts or Path(relative).is_absolute()):
            raise DeploymentError("Unsafe backup journal")
        dest = profile / relative
        current = dest
        while current != profile:
            if current.is_symlink():
                raise DeploymentError("Destination symlink")
            current = current.parent
    # Preflight every saved original before deleting or restoring anything.
    for relative in journal["overwritten"]:
        _check_file(backup / "original" / relative, backup)
    _restore(profile, backup, journal)


def deploy_to_test_profile(stage, profile, backup_parent, *, consent=False):
    """Deploy into an explicitly authorized *test* profile, preserving originals."""
    if not consent:
        raise DeploymentError("Explicit deployment consent required")
    stage, profile, backup_parent = map(_safe_tree, (stage, profile, backup_parent))
    roots = (stage, profile, backup_parent)
    if any(_contained(a, b) for i, a in enumerate(roots)
           for j, b in enumerate(roots) if i != j):
        raise DeploymentError("Directories must not overlap")
    files = []
    for src in stage.rglob("*"):
        if src.is_symlink():
            raise DeploymentError("Staged symlink")
        if not src.is_file():
            continue
        _check_file(src, stage)
        relative = src.relative_to(stage)
        if relative.parts[0] not in ALLOWED_ROOTS:
            raise DeploymentError("Unexpected destination root")
        dest = profile / relative
        current = dest
        while current != profile:
            if current.is_symlink():
                raise DeploymentError("Destination symlink")
            current = current.parent
        if dest.exists() and not dest.is_file():
            raise DeploymentError("Destination is not a file")
        files.append((src, relative, dest))
    backup = Path(tempfile.mkdtemp(prefix="vexora-backup-", dir=backup_parent))
    journal = {"profile": str(profile.resolve()), "created": [], "overwritten": []}
    backup_complete = False
    try:
        # Complete the backup before making any profile modifications.
        for _, relative, dest in files:
            key = relative.as_posix()
            if dest.exists():
                saved = backup / "original" / relative
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, saved)
                journal["overwritten"].append(key)
            else:
                journal["created"].append(key)
        (backup / "journal.json").write_text(json.dumps(journal), encoding="utf-8")
        backup_complete = True
        for src, _, dest in files:
            dest.parent.mkdir(parents=True, exist_ok=True)
            temp = dest.with_name(".vexora-" + uuid.uuid4().hex + ".tmp")
            try:
                shutil.copy2(src, temp)
                os.replace(temp, dest)
            finally:
                temp.unlink(missing_ok=True)
        return backup
    except Exception:
        if backup_complete:
            _restore(profile, backup, journal)
        raise
