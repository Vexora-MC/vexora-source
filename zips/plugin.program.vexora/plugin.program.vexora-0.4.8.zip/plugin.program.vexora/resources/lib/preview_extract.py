"""Verify and safely extract a Vexora preview ZIP to an isolated workspace.

This module never writes to a live Kodi profile and does not install add-ons.
"""
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
from zipfile import ZipFile

from .deployment_plan import DeploymentError, plan_deployment

MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024


def extract_verified_preview(archive_path, workspace):
    """Return (extraction_dir, validated_manifest) or raise DeploymentError."""
    workspace = Path(workspace).absolute()
    if not workspace.is_dir() or workspace.is_symlink():
        raise DeploymentError("Invalid extraction workspace")
    extraction = Path(tempfile.mkdtemp(prefix="vexora-extract-", dir=workspace))
    try:
        with ZipFile(archive_path) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)):
                raise DeploymentError("Duplicate ZIP entries")
            if "vexora-deployment-manifest.json" not in names:
                raise DeploymentError("Missing deployment manifest")
            manifest_bytes = archive.read("vexora-deployment-manifest.json")
            if len(manifest_bytes) > 1024 * 1024:
                raise DeploymentError("Oversized deployment manifest")
            manifest = json.loads(manifest_bytes.decode("utf-8"))
            plan_deployment(manifest)
            allowed = {item["path"] for item in manifest["files"]}
            allowed.update(("vexora-deployment-manifest.json", "vexora-build-manifest.json"))
            if set(names) != allowed:
                raise DeploymentError("Unexpected or missing ZIP entries")
            total = 0
            for entry in manifest["files"]:
                name = entry["path"]
                info = archive.getinfo(name)
                if info.is_dir() or ((info.external_attr >> 16) & 0o170000) == 0o120000:
                    raise DeploymentError("Unsafe ZIP member")
                if info.file_size > MAX_FILE_BYTES:
                    raise DeploymentError("Oversized ZIP member")
                total += info.file_size
                if total > MAX_TOTAL_BYTES:
                    raise DeploymentError("Oversized ZIP payload")
                target = extraction / name
                target.parent.mkdir(parents=True, exist_ok=True)
                digest = hashlib.sha256()
                with archive.open(info) as src, target.open("xb") as dest:
                    while True:
                        chunk = src.read(1024 * 1024)
                        if not chunk:
                            break
                        digest.update(chunk)
                        dest.write(chunk)
                if digest.hexdigest() != entry["sha256"]:
                    raise DeploymentError("ZIP member checksum mismatch: " + name)
        return extraction, manifest
    except Exception:
        shutil.rmtree(extraction)
        raise
