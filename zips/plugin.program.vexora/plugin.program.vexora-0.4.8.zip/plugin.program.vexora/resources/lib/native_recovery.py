"""Kodi-native undo of setup state without modifying its live add-on database.

Full byte-for-byte offline restore remains a separate stopped-Kodi operation.
Native undo retains downloaded packages, restores their enabled states and the
previous skin selection. It never downgrades an add-on or restores a live DB.
"""
import json
import re
from pathlib import Path
from .optional_catalogue import OPTIONAL_REPOSITORIES
from .repository_preflight import REQUIRED
from .safe_paths import has_link_in_path, canonical_profile_path

MANAGED = ('skin.vexora', *REQUIRED, *OPTIONAL_REPOSITORIES)


def capture_states(lookup):
    states = {}
    for id in MANAGED:
        item = lookup(id)
        states[id] = {'installed': item is not None,
                      'enabled': bool(item and item.get('enabled')),
                      'version': item.get('version') if item else None}
    return states


def read_transaction(folder, backup_parent, home, userdata):
    folder, parent = Path(folder), Path(backup_parent)
    if canonical_profile_path(folder.parent) != canonical_profile_path(parent) or not folder.name.startswith('build-'):
        raise ValueError('Recovery backup is outside the Vexora backup directory')
    path = folder / 'transaction.json'
    if has_link_in_path(path) or path.stat().st_size > 1024 * 1024:
        raise ValueError('Unsafe recovery transaction')
    data = json.loads(path.read_text(encoding='utf-8'))
    if (data.get('format') != 1 or canonical_profile_path(data.get('home','')) != canonical_profile_path(home)
            or canonical_profile_path(data.get('userdata','')) != canonical_profile_path(userdata)):
        raise ValueError('Recovery backup belongs to another Kodi profile')
    if data.get('state') not in ('installed','recovery_required','native_undo_required','undoing_native'):
        raise ValueError('This backup cannot be undone in Kodi')
    states = data.get('addon_states')
    if not isinstance(states, dict) or set(states) != set(MANAGED):
        raise ValueError('This older backup requires offline recovery')
    for id, state in states.items():
        if (not isinstance(state,dict) or type(state.get('installed')) is not bool
                or type(state.get('enabled')) is not bool
                or (not state['installed'] and state['enabled'])):
            raise ValueError('Invalid recorded add-on state')
    skin = data.get('previous_skin')
    if not isinstance(skin,str) or not re.fullmatch(r'skin\.[A-Za-z0-9_.-]+',skin):
        raise ValueError('Invalid previous skin')
    return data


def undo_states(data, lookup, set_enabled, activate_skin):
    """Restore only verified, allowlisted state through Kodi's own APIs."""
    previous = data['previous_skin']
    skin = lookup(previous)
    if not skin or not skin.get('enabled'):
        raise RuntimeError('Previous skin is unavailable; enable it in Kodi before undoing setup')
    targets = []
    # Check every original version before changing the active skin or enabled state.
    for id in reversed(MANAGED):
        before = data['addon_states'][id]
        current = lookup(id)
        if not current:
            if before['installed']:
                raise RuntimeError('Previously installed add-on is missing: ' + id)
            continue
        if before['installed'] and current.get('version') != before.get('version'):
            raise RuntimeError('Add-on version changed since backup; use Kodi Versions: ' + id)
        targets.append((id,before['enabled'] if before['installed'] else False))
    activate_skin(previous)
    for id, desired in targets:
        current = lookup(id)
        if not current or bool(current.get('enabled')) != desired:
            set_enabled(id, desired)
            current = lookup(id)
            if not current or bool(current.get('enabled')) != desired:
                raise RuntimeError('Kodi did not confirm restored enabled state: ' + id)


def run_recovery():
    import xbmc
    import xbmcgui
    import xbmcvfs
    from .kodi_status import get_addon
    from .build_manager import save_journal
    home = xbmcvfs.translatePath('special://home/')
    userdata = xbmcvfs.translatePath('special://profile/')
    parent = Path(userdata) / 'addon_data/plugin.program.vexora/backups'
    dialog = xbmcgui.Dialog()
    candidates = []
    for folder in sorted(parent.glob('build-*'),key=lambda p:p.name):
        try:
            transaction = read_transaction(folder,parent,home,userdata)
            candidates.append((folder,transaction))
        except (OSError, ValueError, TypeError):
            continue
    if not candidates:
        dialog.ok('Vexora recovery','No compatible setup-state backup exists for this profile. '
                  'Older full backups require stopped-Kodi offline recovery. Backups: ' + str(parent))
        return
    choice = dialog.select('Undo Vexora setup', [folder.name for folder,_ in candidates])
    if choice < 0:return
    folder,data = candidates[choice]
    if not dialog.yesno('Undo Vexora setup',
        'Restore the previous skin selection and repository enabled states? Downloaded add-ons remain installed. '
        'Versions and files are not downgraded. Full offline backup is retained.',
        nolabel='Cancel',yeslabel='Undo setup'):return
    monitor = xbmc.Monitor()
    def rpc(method, params):
        result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
        if result.get('error') or result.get('result') not in (True,'OK'):
            raise RuntimeError('Kodi rejected recovery action: ' + method)
    def set_enabled(id,value):
        import time
        rpc('Addons.SetAddonEnabled',{'addonid':id,'enabled':value})
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            item=get_addon(id)
            if item and bool(item.get('enabled'))==value:return
            if monitor.waitForAbort(.25):break
        raise RuntimeError('Kodi did not confirm enabled state: '+id)
    def activate(id):
        rpc('Settings.SetSettingValue',{'setting':'lookandfeel.skin','value':id})
        # This generic wait also handles the previous non-Vexora skin.
        import time
        deadline = time.monotonic()+35
        while time.monotonic()<deadline:
            if xbmc.getSkinDir()==id and not xbmc.getCondVisibility('Window.IsActive(yesnodialog)'):return
            if monitor.waitForAbort(.25):break
        raise RuntimeError('Previous skin was not confirmed')
    data['state']='undoing_native';save_journal(folder,data)
    try:
        undo_states(data,get_addon,set_enabled,activate)
        data['state']='native_undone';save_journal(folder,data)
        dialog.notification('Vexora','Setup state restored; downloaded packages retained')
    except (OSError, ValueError, RuntimeError) as error:
        data['state']='native_undo_required';data['recovery_error']=str(error);save_journal(folder,data)
        dialog.ok('Recovery incomplete',str(error)+'. The backup is retained; retry from the Wizard.')
