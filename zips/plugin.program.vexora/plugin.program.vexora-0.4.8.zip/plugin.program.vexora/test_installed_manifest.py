"""Tests for reading installed manifests without touching a Kodi profile."""
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

xbmc = sys.modules.setdefault("xbmc", types.ModuleType("xbmc"))
xbmc.LOGWARNING = 2
xbmc.log = lambda *args: None
xbmcvfs = sys.modules.setdefault("xbmcvfs", types.ModuleType("xbmcvfs"))
xbmcvfs.translatePath = lambda path: path
from resources.lib.installed_manifest import read_installed_addon_xml, InstalledManifestError


class InstalledManifestTests(unittest.TestCase):
    def test_reads_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "addon.xml"
            path.write_text("<addon/>", encoding="utf-8")
            with patch.object(xbmcvfs, "translatePath", return_value=str(path)):
                self.assertEqual(read_installed_addon_xml("plugin.video.tmdbmovies"), "<addon/>")

    def test_rejects_unknown_plugin(self):
        with self.assertRaises(InstalledManifestError):
            read_installed_addon_xml("plugin.video.untrusted")

    def test_rejects_oversized_manifest(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "addon.xml"
            path.write_text("X" * 101, encoding="utf-8")
            with patch.object(xbmcvfs, "translatePath", return_value=str(path)):
                with self.assertRaises(InstalledManifestError):
                    read_installed_addon_xml("plugin.video.Rising.Tides", max_bytes=100)


if __name__ == "__main__":
    unittest.main()
