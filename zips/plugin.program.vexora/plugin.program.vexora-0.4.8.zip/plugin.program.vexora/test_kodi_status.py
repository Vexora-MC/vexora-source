"""Mocked Kodi JSON-RPC adapter tests (no Kodi installation required)."""
import json
import sys
import types
import unittest
import tempfile
from pathlib import Path
from unittest.mock import patch

fake_xbmc = types.ModuleType("xbmc")
fake_xbmc.executeJSONRPC = lambda _: ""
fake_xbmc = sys.modules.setdefault("xbmc", fake_xbmc)
fake_xbmc.executeJSONRPC = lambda _: ""
from resources.lib.kodi_status import get_addon, KodiStatusError


class KodiStatusTests(unittest.TestCase):
    def test_enabled_version(self):
        response = {"jsonrpc": "2.0", "id": 1, "result": {"addon": {
            "addonid": "script.module.requests", "enabled": True, "version": "2.22.0"}}}
        with patch.object(fake_xbmc, "executeJSONRPC", return_value=json.dumps(response)) as rpc:
            self.assertEqual(get_addon("script.module.requests"),
                             {"enabled": True, "version": "2.22.0"})
            request = json.loads(rpc.call_args.args[0])
            self.assertEqual(request["method"], "Addons.GetAddonDetails")

    def test_missing(self):
        with patch.object(fake_xbmc, "executeJSONRPC", return_value=json.dumps(
                {"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "Invalid params"}})):
            self.assertIsNone(get_addon("plugin.video.missing"))

    def test_core_api_manifest_identity_and_version(self):
        vfs = types.ModuleType("xbmcvfs")
        missing = json.dumps({"error": {"code": -32602}})
        with tempfile.TemporaryDirectory() as directory:
            vfs.translatePath = lambda _: directory
            manifest = Path(directory) / "kodi.binary.global.main" / "addon.xml"
            manifest.parent.mkdir()
            manifest.write_text('<addon id="kodi.binary.global.main" version="2.0.2"/>')
            with patch.dict(sys.modules, {"xbmcvfs": vfs}), patch.object(
                    fake_xbmc, "executeJSONRPC", return_value=missing):
                self.assertEqual(get_addon("kodi.binary.global.main"),
                    {"enabled": True, "version": "2.0.2", "runtime": True})
                manifest.write_text('<addon id="wrong" version="2.0.2"/>')
                self.assertIsNone(get_addon("kodi.binary.global.main"))
                manifest.unlink()
                self.assertIsNone(get_addon("kodi.binary.global.main"))

    def test_unexpected_addon_rejected(self):
        response = {"result": {"addon": {"addonid": "wrong", "enabled": True, "version": "1"}}}
        with patch.object(fake_xbmc, "executeJSONRPC", return_value=json.dumps(response)):
            with self.assertRaises(KodiStatusError):
                get_addon("plugin.video.expected")

    def test_invalid_response_rejected(self):
        with patch.object(fake_xbmc, "executeJSONRPC", return_value="not json"):
            with self.assertRaises(KodiStatusError):
                get_addon("plugin.video.expected")


if __name__ == "__main__":
    unittest.main()
