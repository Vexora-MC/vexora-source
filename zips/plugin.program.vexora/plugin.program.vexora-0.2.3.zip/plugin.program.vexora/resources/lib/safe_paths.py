"""Portable relative paths: reject Windows aliases even on Linux CI."""
import re

_RESERVED = re.compile(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", re.I)


def validate_relative_path(name):
    """Return canonical components or raise ValueError before filesystem access."""
    if not isinstance(name, str) or not name or "\\" in name:
        raise ValueError("Invalid relative path")
    parts = name.split("/")
    for part in parts:
        if (part in ("", ".", "..") or part.endswith((" ", "."))
                or any(ord(ch) < 32 or ch in '<>:"|?*' for ch in part)
                or _RESERVED.match(part)):
            raise ValueError("Unsafe portable path")
    return tuple(parts)
