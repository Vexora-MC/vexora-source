"""Kodi JSON-RPC adapter for dependency status.

Read-only: never enables, disables, downloads or installs add-ons.
"""
import json
import xbmc


class KodiStatusError(RuntimeError):
    pass


def get_addon(addon_id):
    """Return installed Kodi add-on version and enabled state, or None if absent.

    Kodi JSON-RPC's Addons.GetAddonDetails is the source of truth. Errors
    other than a missing add-on fail closed rather than implying success.
    """
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled", "version"]},
    }
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
    except (ValueError, TypeError) as exc:
        raise KodiStatusError("Invalid Kodi JSON-RPC response") from exc
    if "error" in response:
        # Kodi reports unknown add-ons as an Invalid params error (-32602).
        if response["error"].get("code") == -32602:
            return None
        raise KodiStatusError("Kodi add-on query failed")
    details = response.get("result", {}).get("addon")
    if not isinstance(details, dict) or details.get("addonid") != addon_id:
        raise KodiStatusError("Kodi returned unexpected add-on details")
    if not isinstance(details.get("enabled"), bool):
        raise KodiStatusError("Kodi did not report enabled state")
    return {"enabled": details["enabled"], "version": details.get("version")}
