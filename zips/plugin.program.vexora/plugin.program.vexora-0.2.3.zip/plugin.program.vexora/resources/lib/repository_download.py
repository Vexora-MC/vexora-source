"""HTTPS-only download of both mandatory repository packages.

Downloads are bounded and validated before any install callback can run.
Never follow redirects to HTTP or a different host. Missing verified sources
are hard blockers; do not silently skip a repository.
"""
from urllib.parse import urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

from .repository_preflight import inspect_repository_zip
from .repository_sources import SOURCES
from .required_repositories import preflight_required_repositories

MAX_PACKAGE_BYTES = 20 * 1024 * 1024


class RepositoryDownloadError(ValueError):
    pass


def _same_https_host(original, destination):
    a, b = urlsplit(original), urlsplit(destination)
    return (a.scheme == b.scheme == "https" and
            a.hostname == b.hostname and a.port == b.port and
            not b.username and not b.password)


class StrictHTTPSRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not _same_https_host(req.full_url, newurl):
            raise RepositoryDownloadError('Unapproved redirect destination')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _default_open(request, timeout):
    return build_opener(StrictHTTPSRedirect()).open(request, timeout=timeout)


def fetch_repository_zip(repo_id, *, opener=None):
    """Fetch and validate one known repository ZIP; no Kodi side effects."""
    source = SOURCES.get(repo_id)
    if not source:
        raise RepositoryDownloadError("Unknown repository")
    url = source.get("zip_url")
    if not url:
        raise RepositoryDownloadError("Verified HTTPS ZIP URL not configured: " + repo_id)
    if not _same_https_host(url, url):
        raise RepositoryDownloadError("Repository URL is not HTTPS")
    request = Request(url, headers={"User-Agent": "Vexora-Repository-Preflight/1"})
    try:
        with (opener or _default_open)(request, timeout=20) as response:
            final_url = response.geturl()
            if not _same_https_host(url, final_url):
                raise RepositoryDownloadError("Unapproved redirect destination")
            data = response.read(MAX_PACKAGE_BYTES + 1)
    except RepositoryDownloadError:
        raise
    except (OSError, ValueError) as exc:
        raise RepositoryDownloadError("Repository download failed: " + repo_id) from exc
    if len(data) > MAX_PACKAGE_BYTES:
        raise RepositoryDownloadError("Repository archive exceeds size limit")
    try:
        inspect_repository_zip(data, repo_id)
    except ValueError as exc:
        raise RepositoryDownloadError("Repository archive validation failed: " + repo_id) from exc
    return data


def fetch_both_required_repositories(*, fetch=fetch_repository_zip):
    """All-or-nothing retrieval, with preflight repeated on both archives."""
    packages = {repo_id: fetch(repo_id) for repo_id in SOURCES}
    preflight_required_repositories(packages)
    return packages
