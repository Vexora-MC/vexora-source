"""Read mandatory dependencies from Kodi addon.xml without downloading code.

The manifest may change upstream; inspect the installed version after Kodi resolves it.
"""
import xml.etree.ElementTree as ET


class DependencyError(ValueError):
    pass


def required_dependencies(addon_xml):
    """Return required dependency IDs and minimum versions, excluding optional imports."""
    try:
        root = ET.fromstring(addon_xml)
    except (ET.ParseError, TypeError) as exc:
        raise DependencyError("Invalid addon.xml") from exc
    if root.tag != "addon" or not root.get("id"):
        raise DependencyError("Missing add-on identity")
    found = []
    for item in root.findall("./requires/import"):
        addon_id = item.get("addon")
        if not addon_id:
            raise DependencyError("Dependency has no ID")
        if item.get("optional", "").lower() in ("true", "1"):
            continue
        found.append({"id": addon_id, "minimum_version": item.get("version")})
    return found



def _version_parts(value):
    """Conservative comparison for dotted numeric versions."""
    if not isinstance(value, str) or not value:
        return None
    parts = value.split(".")
    if not all(part.isdigit() for part in parts):
        return None
    return tuple(int(part) for part in parts)


def _meets_minimum(actual, minimum):
    if not minimum:
        return True
    actual_parts = _version_parts(actual)
    minimum_parts = _version_parts(minimum)
    if actual_parts is None or minimum_parts is None:
        return False
    length = max(len(actual_parts), len(minimum_parts))
    return (actual_parts + (0,) * (length - len(actual_parts)) >=
            minimum_parts + (0,) * (length - len(minimum_parts)))


def dependency_status(dependencies, get_addon):
    """Report missing, disabled, or available dependencies; do not install anything."""
    result = []
    for dependency in dependencies:
        addon_id = dependency["id"]
        if addon_id == "xbmc.python":
            # A Kodi runtime API dependency, not a downloadable module.
            result.append({"id": addon_id, "status": "runtime"})
            continue
        try:
            addon = get_addon(addon_id)
        except (RuntimeError, KeyError):
            addon = None
        if addon is None:
            status = "missing"
        elif not addon.get("enabled", False):
            status = "disabled"
        elif not _meets_minimum(addon.get("version"), dependency.get("minimum_version")):
            status = "version_mismatch"
        else:
            status = "available"
        result.append({"id": addon_id, "status": status})
    return result
