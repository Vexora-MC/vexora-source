"""Kodi-native, verified repository setup; no direct third-party extraction."""
import hashlib
from pathlib import Path
import time
import io
from zipfile import ZipFile

from .repository_download import fetch_both_required_repositories
from .repository_preflight import REQUIRED
from .required_repositories import RepositorySetupError, preflight_required_repositories

# Observed source bytes reviewed on 21 October 2026. Changes require a fresh
# review; HTTPS delivery alone must not silently approve replacement packages.
APPROVED_SHA256 = {
    'repository.angelitto': '562a6b53c4c03c7da6af67724fa5fe4de7967206f1715cae4ec353446aa76353',
    'repository.Rising.Tides': '0503d6b03d479f7d8dfd5cdec34acac2049b631e4f146867631fb2edfe202d3a',
}


def prepare_repository_cache(packages, cache):
    """Validate BOTH archives and pinned digests before writing either one."""
    preflight_required_repositories(packages)
    for addon_id, data in packages.items():
        if hashlib.sha256(data).hexdigest() != APPROVED_SHA256[addon_id]:
            raise RepositorySetupError('Repository package changed; review required: ' + addon_id)
    cache = Path(cache)
    cache.mkdir(parents=True, exist_ok=True)
    if any(p.is_symlink() for p in (cache, *cache.parents)):
        raise RepositorySetupError('Repository cache must not contain symlinks')
    paths = {}
    for addon_id, data in packages.items():
        path = cache / (addon_id + '.zip')
        if path.is_symlink():
            raise RepositorySetupError('Invalid repository cache member')
        path.write_bytes(data)
        paths[addon_id] = path
    return paths


def verify_repositories(lookup):
    """Require exact reviewed versions and enabled state for both repos."""
    blockers = []
    for addon_id, version in REQUIRED.items():
        item = lookup(addon_id)
        if not item or item.get('enabled') is not True or item.get('version') != version:
            blockers.append(addon_id)
    return blockers


def verify_repository_files(packages, installed_path):
    """Confirm Kodi installed the reviewed bytes, not only the same ID/version."""
    preflight_required_repositories(packages)
    for addon_id, data in packages.items():
        root = Path(installed_path(addon_id))
        if not root.is_dir() or any(p.is_symlink() for p in (root, *root.parents)):
            raise RepositorySetupError('Invalid installed repository location: ' + addon_id)
        with ZipFile(io.BytesIO(data)) as archive:
            expected = {}
            for member in archive.infolist():
                if not member.is_dir():
                    name = member.filename[len(addon_id) + 1:]
                    expected[name] = hashlib.sha256(archive.read(member)).hexdigest()
        actual = {}
        for path in root.rglob('*'):
            if path.is_symlink():
                raise RepositorySetupError('Installed repository contains a symlink')
            if path.is_file():
                actual[path.relative_to(root).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise RepositorySetupError('Installed repository differs from validated package: ' + addon_id)


def run_repository_setup(*, packages=None, consent=False):
    """Publisher-hosted native installation, followed by bounded verification.

    Vexora Repository indexes point at the publishers' HTTPS archives.
    Cancellation or failure of either mandatory repo fails whole setup.
    """
    import xbmc
    import xbmcgui
    import xbmcvfs
    from .kodi_status import get_addon

    dialog = xbmcgui.Dialog()
    if not consent and not dialog.yesno('Vexora repository setup',
                        'Install both required repositories: Angelitto and Rising Tides? '
                        'Kodi will install them from their publishers. Cancel stops setup.'):
        return False
    progress = xbmcgui.DialogProgress()
    progress.create('Vexora', 'Downloading and validating both repository packages')
    try:
        packages = packages if packages is not None else fetch_both_required_repositories()
        if progress.iscanceled():
            return False
        cache = xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/repositories')
        prepare_repository_cache(packages, cache)
    finally:
        progress.close()
    monitor = xbmc.Monitor()
    for addon_id, version in REQUIRED.items():
        current = get_addon(addon_id)
        if current and current.get('version') == version and current.get('enabled'):
            continue
        if current and current.get('version') != version:
            raise RepositorySetupError('Installed repository differs from reviewed version: ' + addon_id)
        if current:
            xbmc.executebuiltin('EnableAddon(' + addon_id + ')', True)
        else:
            xbmc.executebuiltin('InstallAddon(' + addon_id + ')', True)
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            current = get_addon(addon_id)
            if current and current.get('enabled') and current.get('version') == version:
                break
            if monitor.waitForAbort(0.5):
                raise RepositorySetupError('Kodi is shutting down; setup incomplete')
        else:
            raise RepositorySetupError('Installation cancelled, failed, or timed out: ' + addon_id)
    blockers = verify_repositories(get_addon)
    if blockers:
        raise RepositorySetupError('Mandatory repository setup incomplete: ' + ', '.join(blockers))
    import xbmcaddon
    verify_repository_files(packages, lambda addon_id:
        xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('path')))
    xbmc.executebuiltin('UpdateAddonRepos')
    dialog.ok('Vexora repositories ready',
              'Both mandatory repositories are installed and enabled. '
              'Kodi is refreshing their indexes. Movies and Sports tiles can now request add-ons.')
    return True
