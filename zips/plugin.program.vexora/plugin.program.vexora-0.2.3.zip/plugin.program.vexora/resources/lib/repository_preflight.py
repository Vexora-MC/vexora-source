"""Pure-Python preflight for Vexora's two mandatory repository packages.

Never installs, downloads, or trusts a ZIP based solely on its filename.
"""
from pathlib import PurePosixPath
import io
import zipfile
import xml.etree.ElementTree as ET
import zlib
from urllib.parse import urlsplit
from .safe_paths import validate_relative_path

REQUIRED = {
    "repository.angelitto": "1.0.2",
    "repository.Rising.Tides": "1.1",
}


class RepositoryPackageError(ValueError):
    pass


def inspect_repository_zip(blob, expected_id):
    """Return validated repository metadata; reject unsafe or mismatched archives."""
    if expected_id not in REQUIRED:
        raise RepositoryPackageError("Unexpected repository")
    if not isinstance(blob, bytes) or len(blob) > 20 * 1024 * 1024:
        raise RepositoryPackageError("Invalid package size")
    try:
        with zipfile.ZipFile(io.BytesIO(blob)) as archive:
            entries = archive.infolist()
            if len(entries) > 200:
                raise RepositoryPackageError("Too many files")
            if sum(x.file_size for x in entries) > 30 * 1024 * 1024:
                raise RepositoryPackageError("Uncompressed size exceeds limit")
            seen = set()
            for entry in entries:
                name = entry.filename[:-1] if entry.is_dir() else entry.filename
                try:
                    validate_relative_path(name)
                except ValueError as exc:
                    raise RepositoryPackageError("Unsafe archive path") from exc
                if name.casefold() in seen:
                    raise RepositoryPackageError("Duplicate archive destination")
                seen.add(name.casefold())
                if not entry.is_dir() and name.split('/')[-1].lower() not in {
                        'addon.xml', 'icon.png', 'fanart.jpg', 'fanart.png',
                        'changelog.txt', 'license', 'license.txt', 'license.md'}:
                    raise RepositoryPackageError('Unexpected repository package content')
                if entry.flag_bits & 1:
                    raise RepositoryPackageError("Encrypted archive member")
                path = PurePosixPath(entry.filename)
                if (path.is_absolute() or ".." in path.parts or
                        "\\" in entry.filename or not entry.filename.startswith(expected_id + "/")):
                    raise RepositoryPackageError("Unsafe archive path")
                if (entry.external_attr >> 16) & 0o170000 == 0o120000:
                    raise RepositoryPackageError("Symlinks are not allowed")
            xml_path = expected_id + "/addon.xml"
            if xml_path not in archive.namelist():
                raise RepositoryPackageError("Missing repository addon.xml")
            if archive.getinfo(xml_path).file_size > 100000:
                raise RepositoryPackageError("Oversized addon.xml")
            root = ET.fromstring(archive.read(xml_path))
            if root.tag != "addon" or root.get("id") != expected_id:
                raise RepositoryPackageError("Repository identity mismatch")
            if root.get("version") != REQUIRED[expected_id]:
                raise RepositoryPackageError("Repository version mismatch")
            extension = root.find("extension[@point='xbmc.addon.repository']")
            if any(node.get('point') not in ('xbmc.addon.repository', 'xbmc.addon.metadata')
                   for node in root.findall('extension')):
                raise RepositoryPackageError('Unexpected executable repository extension')
            if extension is None or not extension.findall("dir"):
                raise RepositoryPackageError("Missing repository configuration")
            for directory in extension.findall("dir"):
                for field in ("info", "checksum", "datadir"):
                    node = directory.find(field)
                    if node is None or not (node.text or "").startswith("https://"):
                        raise RepositoryPackageError("Repository endpoint must use HTTPS")
                    url = urlsplit(node.text)
                    if not url.hostname or url.username or url.password or url.fragment:
                        raise RepositoryPackageError("Invalid repository endpoint")
            # Verify all members, not only addon.xml: corrupt artwork also
            # means this package cannot safely be handed to Kodi.
            if archive.testzip() is not None:
                raise RepositoryPackageError("Corrupt archive member")
            return {"id": expected_id, "version": root.get("version"),
                    "files": len(entries)}
    except (zipfile.BadZipFile, ET.ParseError, KeyError, RuntimeError, NotImplementedError, zlib.error, EOFError) as exc:
        raise RepositoryPackageError("Malformed repository archive") from exc
