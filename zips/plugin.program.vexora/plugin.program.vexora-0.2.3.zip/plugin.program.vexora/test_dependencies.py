"""Offline tests for add-on dependency discovery and readiness."""
import unittest
from resources.lib.dependencies import DependencyError, dependency_status, required_dependencies


XML = """<addon id="plugin.video.example"><requires>
<import addon="xbmc.python" version="3.0.0"/>
<import addon="script.module.requests" version="2.22.0"/>
<import addon="script.module.resolveurl" optional="false"/>
<import addon="script.module.optional" optional="true"/>
</requires></addon>"""


class DependencyTests(unittest.TestCase):
    def test_required_excludes_optional(self):
        self.assertEqual([x["id"] for x in required_dependencies(XML)],
                         ["xbmc.python", "script.module.requests", "script.module.resolveurl"])

    def test_minimum_version_preserved(self):
        self.assertEqual(required_dependencies(XML)[1]["minimum_version"], "2.22.0")

    def test_bad_xml_fails(self):
        with self.assertRaises(DependencyError):
            required_dependencies("<broken")

    def test_missing_disabled_available(self):
        states = {"script.module.requests": {"enabled": True, "version": "2.22.0"},
                  "script.module.resolveurl": {"enabled": False}}
        statuses = dependency_status(required_dependencies(XML), lambda addon_id: states.get(addon_id))
        self.assertEqual([x["status"] for x in statuses], ["runtime", "available", "disabled"])

    def test_version_too_old(self):
        deps = [{"id": "script.module.requests", "minimum_version": "2.22.0"}]
        self.assertEqual(dependency_status(
            deps, lambda _: {"enabled": True, "version": "2.21.9"})[0]["status"],
            "version_mismatch")

    def test_version_meets_minimum(self):
        deps = [{"id": "script.module.requests", "minimum_version": "2.22.0"}]
        self.assertEqual(dependency_status(
            deps, lambda _: {"enabled": True, "version": "2.22"})[0]["status"],
            "available")

    def test_unreadable_version_fails_closed(self):
        deps = [{"id": "script.module.requests", "minimum_version": "2.22.0"}]
        self.assertEqual(dependency_status(
            deps, lambda _: {"enabled": True, "version": "unknown"})[0]["status"],
            "version_mismatch")

    def test_missing(self):
        self.assertEqual(dependency_status(
            [{"id": "script.module.requests"}], lambda _: None)[0]["status"], "missing")


if __name__ == "__main__":
    unittest.main()
