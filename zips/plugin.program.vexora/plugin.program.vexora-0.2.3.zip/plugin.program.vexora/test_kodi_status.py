"""Mocked Kodi JSON-RPC adapter tests (no Kodi installation required)."""
import json
import sys
import types
import unittest
from unittest.mock import patch

fake_xbmc = types.ModuleType("xbmc")
fake_xbmc.executeJSONRPC = lambda _: ""
fake_xbmc = sys.modules.setdefault("xbmc", fake_xbmc)
fake_xbmc.executeJSONRPC = lambda _: ""
from resources.lib.kodi_status import get_addon, KodiStatusError


class KodiStatusTests(unittest.TestCase):
    def test_enabled_version(self):
        response = {"jsonrpc": "2.0", "id": 1, "result": {"addon": {
            "addonid": "script.module.requests", "enabled": True, "version": "2.22.0"}}}
        with patch.object(fake_xbmc, "executeJSONRPC", return_value=json.dumps(response)) as rpc:
            self.assertEqual(get_addon("script.module.requests"),
                             {"enabled": True, "version": "2.22.0"})
            request = json.loads(rpc.call_args.args[0])
            self.assertEqual(request["method"], "Addons.GetAddonDetails")

    def test_missing(self):
        with patch.object(fake_xbmc, "executeJSONRPC", return_value=json.dumps(
                {"jsonrpc": "2.0", "id": 1, "error": {"code": -32602, "message": "Invalid params"}})):
            self.assertIsNone(get_addon("plugin.video.missing"))

    def test_unexpected_addon_rejected(self):
        response = {"result": {"addon": {"addonid": "wrong", "enabled": True, "version": "1"}}}
        with patch.object(fake_xbmc, "executeJSONRPC", return_value=json.dumps(response)):
            with self.assertRaises(KodiStatusError):
                get_addon("plugin.video.expected")

    def test_invalid_response_rejected(self):
        with patch.object(fake_xbmc, "executeJSONRPC", return_value="not json"):
            with self.assertRaises(KodiStatusError):
                get_addon("plugin.video.expected")


if __name__ == "__main__":
    unittest.main()
