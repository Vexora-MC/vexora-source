"""Delayed maintenance and bounded original-repository update checks."""
import hashlib
import json
import re
import time
from pathlib import Path
from urllib.request import Request
from xml.etree import ElementTree as ET
from .repository_download import _default_open
from .dependencies import _meets_minimum, _version_parts
from .safe_paths import has_link_in_path

SOURCE = 'https://djmlogistics.github.io/vexora-source/'
IDS = ('repository.vexora', 'skin.vexora', 'plugin.program.vexora')


def parse_update_index(data, checksum):
    if len(data)>256000 or b'<!DOCTYPE' in data.upper() or b'<!ENTITY' in data.upper():
        raise ValueError('Invalid update index')
    if hashlib.md5(data).hexdigest()!=checksum.strip().decode('ascii'):
        raise ValueError('Repository index/checksum not yet synchronised')
    nodes=list(ET.fromstring(data))
    versions={n.get('id'):n.get('version') for n in nodes}
    if len(nodes)!=3 or set(versions)!=set(IDS) or len(set(versions.values()))!=1 or any(_version_parts(v) is None for v in versions.values()):
        raise ValueError('Unexpected update index identity/version')
    return versions


def pending_updates(available, installed):
    return {id:version for id,version in available.items()
            if installed.get(id) and not _meets_minimum(installed[id],version)}


def prune_old_files(packages, scratch, installed, now=None):
    """Keep installed packages and newest two per ID; never touch artwork caches."""
    now=time.time() if now is None else now
    removed=[];packages=Path(packages);scratch=Path(scratch)
    for folder in (packages,scratch):
        if has_link_in_path(folder):raise ValueError('Unsafe maintenance path')
    groups={}
    if packages.is_dir():
        for path in packages.glob('*.zip'):
            match=re.fullmatch(r'([A-Za-z0-9_.-]+)-(\d[^/\\]*)\.zip',path.name)
            if match and path.is_file() and not has_link_in_path(path):
                groups.setdefault(match[1],[]).append((path.stat().st_mtime,path,match[2]))
    for id,items in groups.items():
        for modified,path,version in sorted(items,reverse=True)[2:]:
            if now-modified>7*86400 and version!=installed.get(id):
                path.unlink();removed.append(path.name)
    if scratch.is_dir():
        for path in scratch.glob('vexora-*.tmp'):
            if path.is_file() and not has_link_in_path(path) and now-path.stat().st_mtime>86400:
                path.unlink();removed.append(path.name)
    return removed


def run():
    import xbmc
    import xbmcgui
    import xbmcvfs
    monitor=xbmc.Monitor()
    if monitor.waitForAbort(45):return
    # Keep all I/O and prompting out of initial tab loading and playback.
    for _ in range(60):
        if (xbmcgui.getCurrentWindowId()==10000 and not xbmc.Player().isPlaying()
                and not xbmc.getCondVisibility('System.HasModalDialog')
                and xbmcgui.Window(10000).getProperty('vexora.installing')!='true'):
            break
        if monitor.waitForAbort(5):return
    else:return
    profile=Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/'))
    state_path=profile/'startup-state.json'
    try:
        if has_link_in_path(state_path):return
        state=json.loads(state_path.read_text()) if state_path.exists() and state_path.stat().st_size<32000 else {}
        if not isinstance(state,dict):state={}
        response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.GetAddons',
            'params':{'enabled':'all','properties':['version']}})))
        if response.get('error'):return
        installed={a['addonid']:a['version'] for a in response['result']['addons']}
        prune_old_files(xbmcvfs.translatePath('special://home/addons/packages/'),profile/'temp',installed)
        if time.time()-float(state.get('checked',0))<86400:return
        def fetch(name,limit):
            with _default_open(Request(SOURCE+name),timeout=8) as stream:
                data=stream.read(limit+1)
                if len(data)>limit:raise ValueError('Oversized update response')
                return data
        available=parse_update_index(fetch('addons.xml',256000),fetch('addons.xml.md5',128))
        pending=pending_updates(available,installed)
        state['checked']=time.time()
        profile.mkdir(parents=True,exist_ok=True)
        temp=state_path.with_suffix('.tmp')
        if has_link_in_path(temp):return
        temp.write_text(json.dumps(state));temp.replace(state_path)
        if not pending or monitor.abortRequested() or xbmc.Player().isPlaying() or xbmcgui.getCurrentWindowId()!=10000 or xbmc.getCondVisibility('System.HasModalDialog'):return
        target=available['plugin.program.vexora']
        if xbmcgui.Dialog().yesno('Vexora update available',
            'Vexora '+target+' is available. Open Kodi Updates to install the matching Wizard, skin and repository? Existing add-ons are retained.',
            nolabel='Later',yeslabel='Open updates'):
            xbmc.executebuiltin('UpdateAddonRepos')
            xbmc.executebuiltin('ActivateWindow(AddonBrowser,addons://updates/,return)')
    except (OSError, ValueError, TypeError, KeyError, ET.ParseError) as error:
        xbmc.log('Vexora background maintenance/update check: '+str(error),xbmc.LOGWARNING)
