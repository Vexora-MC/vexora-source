# SPDX-License-Identifier: GPL-3.0-or-later
"""Execute the publisher's existing dynamic function without writing/importing a temporary .py file.

This changes transport only; it does not fetch code, broaden inputs or alter resolver results.
"""
import functools,os,sys,threading,types
_lock=threading.RLock()

def install(namespace):
 original=namespace['doEvalFunction'];control=namespace['control'];folder=namespace['functions_dir']
 @functools.wraps(original)
 def evaluate(fun_call,page_data,Cookie_Jar,m):
  if folder not in sys.path:sys.path.append(folder)
  filename=os.path.join(folder,'LSProdynamicCode.py')
  module=types.ModuleType('LSProdynamicCode');module.__file__=filename;module.__package__=''
  code=compile(fun_call,filename,'exec')
  # Match import semantics for self-imports, without persistent files or stale bytecode.
  with _lock:
   previous=sys.modules.get('LSProdynamicCode');sys.modules['LSProdynamicCode']=module
   try:
    exec(code,module.__dict__)
    control.busy()
    try:result=module.GetLSProData(page_data,Cookie_Jar,m)
    finally:control.idle()
    try:return str(result) if result is not None else ''
    except Exception:return result if result is not None else ''
   finally:
    if previous is None:sys.modules.pop('LSProdynamicCode',None)
    else:sys.modules['LSProdynamicCode']=previous
 namespace['doEvalFunction']=evaluate
