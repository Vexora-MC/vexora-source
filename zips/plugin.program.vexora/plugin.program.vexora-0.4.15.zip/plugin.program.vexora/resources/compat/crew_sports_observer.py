"""Temporary Crew sports diagnostics: never records URLs, headers, cookies or payloads."""
import functools
import json
import re
import threading
import time
_state=threading.local()
_ALLOWED={'stage','event','exception','result_count','bytes','duration_ms'}


def _record(stage,event,**fields):
    values={'stage':stage,'event':event,**fields}
    safe={}
    for key,value in values.items():
        if key not in _ALLOWED:continue
        if isinstance(value,(int,float)) and not isinstance(value,bool):safe[key]=value
        elif isinstance(value,str) and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,79}',value):safe[key]=value
    import xbmc
    xbmc.log('VEXORA_CREW_SPORTS '+json.dumps(safe,sort_keys=True),xbmc.LOGINFO)


def record(stage,event,**fields):
    try:_record(stage,event,**fields)
    except Exception:pass  # Diagnostics must never change source resolution.


def observe(function,stage,activate=False):
    @functools.wraps(function)
    def wrapped(*args,**kwargs):
        previous=getattr(_state,'active',False)
        active=previous or activate
        if activate:_state.active=True
        started=time.monotonic()
        if active:record(stage,'start')
        try:
            result=function(*args,**kwargs)
            if active:
                fields={'duration_ms':int(1000*(time.monotonic()-started))}
                if isinstance(result,(list,tuple)):fields['result_count']=len(result)
                elif isinstance(result,(str,bytes)):fields['bytes']=len(result)
                empty=result is None or result is False or (isinstance(result,(list,tuple,str,bytes)) and len(result)==0)
                record(stage,'empty' if empty else 'returned',**fields)
            return result
        except Exception as error:
            if active:record(stage,'exception',exception=type(error).__name__)
            raise
        finally:_state.active=previous
    return wrapped


def install(namespace,kind):
    targets={'client':{'schedule':True,'request':False},
             'control':{'cdnImport':False,'load_source':False},
             'regex':{'doEvalFunction':True}}
    for name,activate in targets[kind].items():
        original=namespace[name]
        namespace[name]=observe(original,kind+'_'+name,activate)
