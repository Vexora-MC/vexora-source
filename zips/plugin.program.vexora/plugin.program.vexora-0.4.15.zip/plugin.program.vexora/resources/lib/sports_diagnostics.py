"""Bounded, sanitized Crew sports-stage summary; never displays raw Kodi logs."""
import json,re
from pathlib import Path
STAGES={'client_schedule','client_request','control_cdnImport','control_load_source','regex_doEvalFunction'}
EVENTS={'start','empty','returned','exception'}
def summarize(text):
 records=[]
 for line in text.splitlines():
  if 'VEXORA_CREW_SPORTS ' not in line:continue
  try:row=json.loads(line.split('VEXORA_CREW_SPORTS ',1)[1])
  except (ValueError,TypeError):continue
  if not isinstance(row,dict) or row.get('stage') not in STAGES or row.get('event') not in EVENTS:continue
  label=row['stage']+': '+row['event']
  for key in ('result_count','bytes','duration_ms'):
   value=row.get(key)
   if type(value) is int and 0<=value<=100000000:label+='; '+key+'='+str(value)
  error=row.get('exception')
  if isinstance(error,str) and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,79}',error):label+='; '+error
  records.append(label)
 return '\n'.join(records[-30:]) or 'No targeted sports diagnostics found. Reproduce Boxing (RS) with the reviewed diagnostic module installed, then return here. No fix has been verified from this empty report.'
def show_summary():
 import xbmcgui,xbmcvfs
 try:
  with Path(xbmcvfs.translatePath('special://logpath/kodi.log')).open('rb') as stream:
   stream.seek(0,2);size=stream.tell();stream.seek(max(0,size-256*1024));text=stream.read(256*1024).decode('utf-8',errors='replace')
  message=summarize(text)
 except OSError:message='Kodi log is unavailable; targeted diagnostics could not be read.'
 xbmcgui.Dialog().textviewer('Crew Boxing diagnostics (last30 safe stages)',message)
