"""Refresh skin tile labels from authoritative Kodi state without installing anything."""

def state_for(item):
    if item is None:return 'Ready to Install'
    return 'Installed' if item.get('enabled') is True else 'Disabled'


def run():
    import xbmc
    import xbmcgui
    from .kodi_status import get_addon
    from .optional_catalogue import OPTIONAL_ADDONS
    monitor=xbmc.Monitor();window=xbmcgui.Window(10000)
    ids=sorted({a['id'] for a in OPTIONAL_ADDONS.values()})
    while not monitor.abortRequested():
        if xbmcgui.getCurrentWindowId()==10000 and not xbmc.Player().isPlaying():
            for aid in ids:
                try:state=state_for(get_addon(aid))
                except (RuntimeError,ValueError):state='Checking status'
                window.setProperty('vexora.addon.state.'+aid,state)
        if monitor.waitForAbort(3):return
