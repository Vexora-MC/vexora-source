"""One Vexora-owned plan, existing transactional core install, then selected native installs."""
from .optional_catalogue import OPTIONAL_ADDONS


def run_coordinated_setup():
    import xbmcgui
    from .build_manager import install_full_build
    from .optional_setup import run_optional_setup
    from .setup_health import run_health
    keys = [key for key, item in OPTIONAL_ADDONS.items()
            if key != 'crew_sports' and not item.get('unavailable')]
    choices = xbmcgui.Dialog().multiselect('Vexora setup - choose add-ons',
                                           [OPTIONAL_ADDONS[key]['name'] for key in keys], preselect=list(range(len(keys))))
    if choices is None:
        return False
    chosen = [keys[index] for index in choices]
    names = ', '.join(OPTIONAL_ADDONS[key]['name'] for key in chosen) or 'No optional add-ons'
    from .setup_progress import SetupProgress
    progress=SetupProgress(xbmcgui.DialogProgress)
    try:
        if not install_full_build(selected_names=names, overall_progress=progress):
            return False
        if progress.cancelled():return False
        run_optional_setup(chosen=chosen, progress_view=progress.stage(80,98), summary=False, full_build_consented=True)
        progress.update(100,'Verifying selected add-ons and repository results')
    finally:
        progress.close()
    return run_health([OPTIONAL_ADDONS[key]['id'] for key in chosen])
