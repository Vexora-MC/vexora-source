"""Read-only first-use readiness assessment for Vexora video plug-ins."""
from xml.etree import ElementTree as ET
from .dependencies import required_dependencies, dependency_status
from .kodi_status import get_addon
from .optional_catalogue import OPTIONAL_ADDONS

APPROVED_PLUGINS = {"plugin.video.tmdbmovies", "plugin.video.Rising.Tides"} | {
    item["id"] for item in OPTIONAL_ADDONS.values()}

PLUGINS = {
    "movies": "plugin.video.tmdbmovies",
    "sports": "plugin.video.Rising.Tides",
}


def assess_plugin(plugin_id, addon_xml, lookup=get_addon):
    """Return ready=False with explicit blockers unless plugin and imports are usable.

    addon_xml MUST be read from the *installed* plug-in, not from the Xenon
    reference snapshot. The caller must not launch when ready is false.
    """
    if plugin_id not in APPROVED_PLUGINS:
        raise ValueError("Unexpected Vexora plug-in")
    from xml.etree import ElementTree as ET
    root = ET.fromstring(addon_xml)
    if root.get("id") != plugin_id:
        raise ValueError("Installed addon.xml identity mismatch")
    plugin = lookup(plugin_id)
    if plugin is None:
        return {"ready": False, "blockers": [{"id": plugin_id, "status": "missing"}]}
    if not plugin.get("enabled", False):
        return {"ready": False, "blockers": [{"id": plugin_id, "status": "disabled"}]}
    requirements = required_dependencies(addon_xml)
    statuses = dependency_status(requirements, lookup)
    blockers = [x for x in statuses if x["status"] not in ("available", "runtime")]
    return {"ready": not blockers, "blockers": blockers, "dependencies": statuses}


def assess_installed_plugin(plugin_id, lookup=get_addon, read_manifest=None):
    """Check the installed plugin and its actual manifest; fail closed on errors."""
    if plugin_id not in APPROVED_PLUGINS:
        raise ValueError("Unexpected Vexora plug-in")
    if read_manifest is None:
        from .installed_manifest import read_dependency_manifest
        read_manifest = read_dependency_manifest
    # One assessment can visit shared dependencies through many branches. Keep
    # results only for this call; every later launch starts a fresh assessment.
    source_lookup, source_manifest = lookup, read_manifest
    addons, manifests = {}, {}
    def lookup(addon_id):
        if addon_id not in addons:
            addons[addon_id] = source_lookup(addon_id)
        return addons[addon_id]
    def read_manifest(addon_id):
        if addon_id not in manifests:
            manifests[addon_id] = source_manifest(addon_id)
        return manifests[addon_id]
    try:
        plugin = lookup(plugin_id)
        if plugin is None:
            return {"ready": False, "blockers": [{"id": plugin_id, "status": "missing"}]}
        if not plugin.get("enabled", False):
            return {"ready": False, "blockers": [{"id": plugin_id, "status": "disabled"}]}
        xml = read_manifest(plugin_id)
        result = assess_plugin(plugin_id, xml, lookup)
        if not result['ready']:
            return result
        from .dependency_graph import inspect_dependency_graph
        return inspect_dependency_graph(plugin_id, lookup, read_manifest)
    except (OSError, ValueError, RuntimeError, ET.ParseError) as exc:
        return {"ready": False, "blockers": [
            {"id": plugin_id, "status": "verification_failed", "reason": str(exc)}
        ]}
