"""One reviewed publisher ZIP-path defect; original files and Kodi dependency policy retained.

This absent-add-on fallback is restricted to the exact reviewed upstream bytes.
It never rewrites a repository, cache hash, existing add-on or live database.
"""
import hashlib,io,json,stat,tempfile,time,uuid
from .managed_directories import ensure_directory,temporary_directory
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from .safe_paths import validate_relative_path,has_link_in_path
from .file_io import flush_file
from .dependencies import required_dependencies,_meets_minimum
ID='plugin.video.Rising.Tides'
VERSION='3.2.10.14'
SHA256='441799d9a892cbbf873c5b241a6831444177904e9f9be52e4bc8025ef1506a8a'
URL='https://mullafabz.xyz/Plugins/K19/Plugins/plugin.video.Rising.Tides/plugin.video.Rising.Tides-3.2.10.14.zip'

def validate(blob,expected_sha=SHA256,aid=ID,version=VERSION):
 if len(blob)>16*1024*1024 or hashlib.sha256(blob).hexdigest()!=expected_sha:raise ValueError('Publisher archive changed; review required')
 files={};names=set();total=0;changed=0
 with ZipFile(io.BytesIO(blob)) as archive:
  if len(archive.infolist())>4096:raise ValueError('Too many archive members')
  for entry in archive.infolist():
   name=entry.orig_filename.replace(chr(92),'/');changed+=int(name!=entry.orig_filename)
   parts=validate_relative_path(name.rstrip('/'))
   if parts[0]!=aid or len(parts)<2 and not name.endswith('/'):raise ValueError('Unexpected publisher archive root')
   key=name.rstrip('/').casefold()
   if key in names:raise ValueError('Duplicate portable publisher path')
   names.add(key)
   if stat.S_ISLNK(entry.external_attr>>16):raise ValueError('Publisher link is not supported')
   if name.endswith('/'):continue
   relative='/'.join(parts[1:])
   if Path(relative).suffix.lower() in ('.dll','.pyd','.exe','.so','.dylib','.bat','.cmd','.ps1','.sh'):raise ValueError('Publisher package contains a desktop or shell component')
   total+=entry.file_size
   if total>64*1024*1024:raise ValueError('Publisher archive expands beyond limit')
   files[relative]=archive.read(entry)
 if not changed:raise ValueError('No reviewed ZIP-path defect present')
 root=ET.fromstring(files.get('addon.xml',b''))
 if root.get('id')!=aid or root.get('version')!=version or root.findtext("./extension[@point='xbmc.addon.metadata']/platform")!='all':raise ValueError('Publisher manifest identity or platform differs')
 return files,required_dependencies(files['addon.xml'])

def stage(blob,addons,journals):
 files,requirements=validate(blob);addons,journals=Path(addons),Path(journals)
 if has_link_in_path(addons) or has_link_in_path(journals):raise ValueError('Unsafe publisher staging path')
 target=addons/ID
 if target.exists() or has_link_in_path(target):raise ValueError('Existing add-on retained; use native update or repair')
 ensure_directory(journals);backup=journals/('publisher-'+uuid.uuid4().hex);ensure_directory(backup,exist_ok=False)
 report={'id':ID,'version':VERSION,'source_sha256':SHA256,'reason':'Upstream ZIP uses backslash member paths','state':'prepared','files':{name:hashlib.sha256(data).hexdigest() for name,data in files.items()},'native_database_modified':False}
 def save():
  with (backup/'transaction.json').open('w',encoding='utf-8') as f:json.dump(report,f,indent=2);flush_file(f)
 with (backup/'upstream.zip').open('wb') as f:f.write(blob);flush_file(f)
 save();ensure_directory(addons)
 with temporary_directory(addons,'.vexora-publisher-') as temp:
  staging=Path(temp)/ID;ensure_directory(staging,exist_ok=False)
  for name,data in files.items():
   path=staging/name;ensure_directory(path.parent)
   with path.open('wb') as f:f.write(data);flush_file(f)
  if target.exists():raise ValueError('Publisher target appeared during staging')
  staging.rename(target)
 report['state']='staged_pending_native_verification';save()
 return backup,report

def reviewed_candidate(versions):
 if VERSION not in versions or any(v!=VERSION and _meets_minimum(v,VERSION) for v in versions):
  raise ValueError('Publisher catalogue version changed; reviewed repair not applied')

def run():
 import xbmc,xbmcgui,xbmcvfs
 from urllib.request import urlopen
 from .kodi_status import get_addon
 from .dependency_graph import inspect_dependency_graph
 from .installed_manifest import read_dependency_manifest
 from .install_confirmation import execute_consented,acknowledge_failure
 from .optional_setup import SetupCancelled
 if xbmcgui.Window(10000).getProperty('vexora.installing')!='true':raise RuntimeError('Publisher repair requires full-build consent')
 if get_addon(ID):raise RuntimeError('Existing publisher add-on retained')
 versions=[]
 for start in range(0,8192,512):
  response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.GetAddons','params':{'installed':False,'enabled':'all','properties':['version'],'limits':{'start':start,'end':start+512}}})))
  if response.get('error'):raise RuntimeError('Cannot verify current publisher version')
  items=response.get('result',{}).get('addons',[])
  versions.extend(item.get('version') for item in items if item.get('addonid')==ID and item.get('version'))
  if len(items)<512:break
 reviewed_candidate(versions)
 with urlopen(URL,timeout=15) as response:blob=response.read(16*1024*1024+1)
 files,requirements=validate(blob);allowed={item['id'] for item in requirements};monitor=xbmc.Monitor()
 for dependency in requirements:
  aid=dependency['id'];current=get_addon(aid)
  if not current or not current.get('enabled'):
   execute_consented(('EnableAddon' if current else 'InstallAddon')+'('+aid+')',allowed)
  deadline=time.monotonic()+90
  while time.monotonic()<deadline:
   current=get_addon(aid)
   if current and current.get('enabled') and _meets_minimum(current.get('version'),dependency['minimum_version']):break
   if acknowledge_failure(aid,allowed):raise RuntimeError('Kodi could not install publisher dependency: '+aid)
   if monitor.waitForAbort(.2) or xbmcgui.Window(10000).getProperty('vexora.installing')!='true':raise SetupCancelled('Publisher dependency setup cancelled')
  else:raise RuntimeError('Publisher dependency unavailable: '+aid)
 def manifest(aid):return files['addon.xml'].decode() if aid==ID else read_dependency_manifest(aid)
 def lookup(aid):return {'enabled':True,'version':VERSION} if aid==ID else get_addon(aid)
 graph=inspect_dependency_graph(ID,lookup,manifest)
 if not graph['ready']:raise RuntimeError('Publisher recursive dependencies are not ready')
 backup,report=stage(blob,xbmcvfs.translatePath('special://home/addons'),xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/publisher-repairs'))
 xbmc.executebuiltin('UpdateLocalAddons',False);deadline=time.monotonic()+30
 while not get_addon(ID) and time.monotonic()<deadline:
  if monitor.waitForAbort(.1):raise RuntimeError('Publisher registration interrupted')
 if not get_addon(ID):raise RuntimeError('Publisher staged but Kodi registration not verified; retain recovery report')
 response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':ID,'enabled':True}})))
 if response.get('error'):raise RuntimeError('Kodi refused publisher enablement; staged files retained for recovery')
 from .readiness import assess_installed_plugin
 if not assess_installed_plugin(ID)['ready']:raise RuntimeError('Publisher is not ready after native registration')
 report.update(state='native_registered_enabled',update_policy='Kodi policy; upstream repository retained; no version pin added',physical_xbox_verified=False)
 with (backup/'transaction.json').open('w',encoding='utf-8') as f:json.dump(report,f,indent=2);flush_file(f)
 return {'status':'installed','method':'reviewed_publisher_path_staging_native_registration','version':VERSION,'source_sha256':SHA256,'backup':str(backup)}
