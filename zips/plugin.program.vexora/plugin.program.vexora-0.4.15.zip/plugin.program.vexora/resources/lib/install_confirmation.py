"""Owner-consented component installation: exact native prompt, no generic approval."""
import json,re,threading,time

def normalized(text):
 text=re.sub(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]','',text,flags=re.I)
 return ' '.join(text.replace('[CR]','\n').split())

def matches_install_prompt(name,heading,body,localized):
 if not isinstance(name,str) or not name.strip():return False
 try:
  expected='\n'.join((localized(24100),name,localized(24101)))
  return bool(localized(24076).strip() and localized(24100).strip() and localized(24101).strip() and
              normalized(heading)==normalized(localized(24076)) and normalized(body)==normalized(expected))
 except (TypeError,ValueError,AttributeError):return False

def matches_failure_prompt(name,heading,body,localized):
 """Only the selected provider's native failure acknowledgement, never security."""
 if not isinstance(name,str) or not name.strip():return False
 try:
  failure=localized(114)
  return bool(failure.strip() and normalized(heading)==normalized(name) and normalized(body)==normalized(failure))
 except (TypeError,ValueError,AttributeError):return False

def acknowledge_failure(addonid,allowed_ids):
 import xbmc,xbmcgui
 if addonid not in allowed_ids or xbmcgui.Window(10000).getProperty('vexora.installing')!='true':return False
 if not xbmc.getCondVisibility('Window.IsActive(okdialog)'):return False
 def rpc(method,params):
  return json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
 name=available_name(addonid,rpc)
 if matches_failure_prompt(name,xbmc.getInfoLabel('Control.GetLabel(1)'),xbmc.getInfoLabel('Control.GetLabel(9)'),xbmc.getLocalizedString):
  xbmc.executebuiltin('SendClick(12002,11)')
  return True
 return False

def available_name(addonid,rpc):
 """Use Kodi's installable catalogue rather than a hardcoded display name."""
 for start in range(0,8192,512):
  params={'installed':False,'enabled':'all','properties':['name'],'limits':{'start':start,'end':start+512}}
  response=rpc('Addons.GetAddons',params)
  if response.get('error'):return None
  result=response.get('result',{});items=result.get('addons',[])
  if not isinstance(items,list):return None
  for row in items:
   if row.get('addonid')==addonid:
    name=row.get('name');return name if isinstance(name,str) and 0<len(name)<=512 else None
  if len(items)<512:return None
 return None

def confirm_during(execute,approve,stop,*,interval=.1,thread_factory=threading.Thread,settled=None,settle_timeout=15):
 """The watcher dies with this one command, including error/cancel paths."""
 finished=threading.Event();confirmed=threading.Event()
 def watch():
  while not finished.wait(interval):
   if stop():return
   try:
    if approve():confirmed.set();return
   except (RuntimeError,ValueError,AttributeError):pass
 worker=thread_factory(target=watch,daemon=True);worker.start()
 try:
  result=execute()
  # InstallAddon can queue its native prompt after the built-in returns.
  # Keep this exact component watcher alive until confirmation/installation.
  if settled is not None:
   deadline=time.monotonic()+settle_timeout
   while not confirmed.is_set() and not stop() and time.monotonic()<deadline:
    if settled():break
    confirmed.wait(interval)
  return result
 finally:finished.set();worker.join(timeout=1)

def execute_consented(command,allowed_ids,progress=None):
 import xbmc,xbmcgui
 def rpc(method,params):
  data=xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params}))
  if len(data)>8*1024*1024:raise ValueError('Oversized Kodi metadata response')
  return json.loads(data)
 match=re.fullmatch(r'(InstallAddon|EnableAddon)\(([A-Za-z0-9_.-]+)\)',command)
 if not match:return xbmc.executebuiltin(command,True)
 kind,aid=match.groups()
 if aid not in allowed_ids or xbmcgui.Window(10000).getProperty('vexora.installing')!='true':
  raise RuntimeError('Component is outside the active full-build consent')
 if kind=='EnableAddon':
  response=rpc('Addons.SetAddonEnabled',{'addonid':aid,'enabled':True})
  if response.get('error'):raise RuntimeError('Kodi refused enabling '+aid)
  return
 monitor=xbmc.Monitor()
 def stopped():
  return monitor.abortRequested() or xbmcgui.Window(10000).getProperty('vexora.installing')!='true' or bool(progress and progress.iscanceled())
 name=available_name(aid,rpc)
 deadline=time.monotonic()+30
 while name is None and time.monotonic()<deadline:
  if stopped() or monitor.waitForAbort(.5):raise RuntimeError('Setup cancelled while refreshing publisher metadata')
  name=available_name(aid,rpc)
 if name is None:raise RuntimeError('Kodi has no installable publisher metadata for '+aid)
 def approve():
  if stopped() or not xbmc.getCondVisibility('Window.IsActive(yesnodialog)'):return
  if matches_install_prompt(name,xbmc.getInfoLabel('Control.GetLabel(1)'),xbmc.getInfoLabel('Control.GetLabel(9)'),xbmc.getLocalizedString):
   xbmc.executebuiltin('SendClick(10100,11)')
   xbmc.log('Vexora confirmed scoped component: '+aid,xbmc.LOGINFO)
   return True
 # Suspend the overall Vexora modal so the native manager can own its dialogs.
 if progress and hasattr(progress,'owner'):progress.owner.suspend()
 result=confirm_during(lambda:xbmc.executebuiltin(command,False),approve,stopped,settled=lambda:not rpc('Addons.GetAddonDetails',{'addonid':aid,'properties':['enabled']}).get('error'))
 deadline=time.monotonic()+5
 while (xbmc.getCondVisibility('Window.IsActive(yesnodialog)') and time.monotonic()<deadline
        and matches_install_prompt(name,xbmc.getInfoLabel('Control.GetLabel(1)'),xbmc.getInfoLabel('Control.GetLabel(9)'),xbmc.getLocalizedString)):
  if stopped() or monitor.waitForAbort(.1):break
 if xbmc.getCondVisibility('Window.IsActive(yesnodialog)'):
  from .optional_setup import SetupCancelled
  raise SetupCancelled('Kodi confirmation remains open; setup stopped without approving another dialog: '+aid)
 return result
