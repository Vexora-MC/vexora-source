"""One lazy progress dialog shared by coordinated setup stages."""
class SetupProgress:
    def __init__(self, factory):
        self.factory=factory;self.dialog=None;self.percent=0;self._cancelled=False
    def stage(self, start, end):
        return ProgressStage(self,start,end)
    def update(self, percent, message):
        if self.dialog is None:
            self.dialog=self.factory();self.dialog.create('Vexora full build',message)
        self.percent=max(self.percent,min(100,int(percent)))
        self.dialog.update(self.percent,message)
    def cancelled(self):
        return self._cancelled or bool(self.dialog is not None and self.dialog.iscanceled())
    def suspend(self):
        """Release our modal before Kodi owns skin confirmation/settings saving."""
        self._cancelled=self.cancelled()
        self.close()
    def close(self):
        if self.dialog is not None:self.dialog.close();self.dialog=None

class ProgressStage:
    def __init__(self, owner, start, end):self.owner=owner;self.start=start;self.end=end
    def create(self, title, message):self.update(0,message)
    def update(self, percent, *messages):
        self.owner.update(self.start+(self.end-self.start)*percent/100,' / '.join(messages))
    def iscanceled(self):return self.owner.cancelled()
    def close(self):pass  # Only the coordinated owner closes the shared dialog.
