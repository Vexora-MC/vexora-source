"""Backed-up, fingerprint-checked Crew runtime compatibility within full-build consent.

Only reviewed publisher source files are changed; accounts and personal settings are never read.
"""
import ast,hashlib,json,re,sys,uuid,time
from pathlib import Path
from xml.etree import ElementTree as ET
from .safe_paths import has_link_in_path
from .file_io import flush_file
VERSION='3.2.26.4~vexoratest1'
BASELINES={'client.py':'f916f6882e9ac13b5c03ef2f484e47b0f20824bc6dba9d3bd53cccf27dd54192','control.py':'6769f51582371b777006ee582024fb24236e783ce3c40cc1501f66d0a34c0d76','regex.py':'99db7031b439a15d240ea163759cceec8d0b2e54fc54af0d86a46a655ef3fa66'}
SOURCES={'3.2.26':'4412fe5b096cf4fb2436d19dee1d7249375d808e532cb9c497f9ae31345f12ea','3.2.26.2':'cb99acfc6ffb2c1ed22e6455f9fd2ba709706d75898db0f5b0cfd25a0018d361'}
REL='lib/resources/lib/modules/'
def digest(data):return hashlib.sha256(data).hexdigest()
def atomic(path,data):
 path=Path(path)
 # Keep temporary leaves no longer than addon.xml/client.py on long UWP paths.
 # Exclusive creation and ownership-aware cleanup preserve a colliding file.
 for attempt in range(8):
  temp=path.with_name('.'+uuid.uuid4().hex[:8])
  try:stream=temp.open('xb')
  except FileExistsError:continue
  try:
   with stream:stream.write(data);flush_file(stream)
   temp.replace(path)
  finally:
   if temp.exists():temp.unlink()
  return
 raise OSError('Unable to allocate a unique compatibility temporary file')

def apply(module,assets,backup_parent):
 module,assets,backup_parent=map(Path,(module,assets,backup_parent))
 if any(has_link_in_path(p) for p in (module,assets,backup_parent)):raise ValueError('Unsafe Crew compatibility path')
 addon=ET.parse(module/'addon.xml').getroot();version=addon.get('version')
 if addon.get('id')!='script.module.thecrew':raise ValueError('Unexpected Crew module identity')
 if version==VERSION:
  marker=module/'VEXORA-COMPAT.json'
  if not marker.is_file() or has_link_in_path(marker) or marker.stat().st_size>32000:raise ValueError('Unverified existing compatibility module')
  journal=json.loads(marker.read_text(encoding='utf-8'))
  for relative,expected in journal['installed_hashes'].items():
   from .safe_paths import validate_relative_path
   validate_relative_path(relative)
   if has_link_in_path(module/relative) or digest((module/relative).read_bytes())!=expected:raise ValueError('Compatibility module changed since setup')
  return {'status':'already_applied','version':VERSION}
 if version not in SOURCES:raise ValueError('Crew publisher version is unreviewed; retained without replacement')
 if (module/'VEXORA-COMPAT.json').exists():raise ValueError('Unexpected existing compatibility marker; retained')
 outputs={};originals={}
 for name,expected in BASELINES.items():
  relative=REL+name;path=module/relative
  if has_link_in_path(path) or path.stat().st_size>2*1024*1024:raise ValueError('Unsafe Crew source path')
  data=path.read_bytes()
  if digest(data)!=expected:raise ValueError('Crew source fingerprint changed; retained without replacement: '+name)
  text=data.decode('utf-8-sig')
  if name=='regex.py':text+="\nfrom . import vexora_memory_functions as _vxmemory\n_vxmemory.install(globals())\n"
  text+="\nfrom . import vexora_sports_diag as _vxdiag\n_vxdiag.install(globals(), %r)\n"%name[:-3]
  ast.parse(text,feature_version=(3,8));outputs[relative]=text.encode('utf-8');originals[relative]=data
 relative=REL+'sources.py';path=module/relative
 if has_link_in_path(path) or path.stat().st_size>2*1024*1024:raise ValueError('Unsafe Crew sources path')
 data=path.read_bytes()
 if digest(data)!=SOURCES[version]:raise ValueError('Crew movie source fingerprint changed; retained')
 if version=='3.2.26':
  text=data.decode('utf-8-sig');anchor='\n                    resolved_part = None\n'
  if text.count(anchor)!=1:raise ValueError('Movie pack initialization site changed')
  text=text.replace(anchor,anchor+'                    is_pack_source = False\n',1);ast.parse(text,feature_version=(3,8));outputs[relative]=text.encode('utf-8');originals[relative]=data
 for source,target in [('crew_inmemory_functions.py','vexora_memory_functions.py'),('crew_sports_observer.py','vexora_sports_diag.py')]:
  if has_link_in_path(assets/source) or (assets/source).stat().st_size>128*1024:raise ValueError('Unsafe compatibility helper')
  data=(assets/source).read_bytes();ast.parse(data.decode('utf-8'),feature_version=(3,8));relative=REL+target
  if (module/relative).exists():raise ValueError('Unexpected existing compatibility helper; retained')
  outputs[relative]=data;originals[relative]=None
 data=(module/'addon.xml').read_bytes();text=data.decode('utf-8-sig');needle='version="'+version+'"'
 if needle not in text:raise ValueError('Unreviewed Crew manifest formatting')
 outputs['addon.xml']=text.replace(needle,'version="'+VERSION+'"',1).encode('utf-8');originals['addon.xml']=data
 backup=backup_parent/('crew-'+uuid.uuid4().hex[:12]);backup.mkdir(parents=True)
 journal={'format':2,'backup_files':{},'id':'script.module.thecrew','version':VERSION,'state':'prepared','original_hashes':{},'installed_hashes':{r:digest(data) for r,data in outputs.items()}}
 for relative,data in originals.items():
  journal['original_hashes'][relative]=digest(data) if data is not None else None
  if data is not None:
   leaf='b'+str(len(journal['backup_files']));journal['backup_files'][relative]=leaf;atomic(backup/leaf,data)
 atomic(backup/'transaction.json',json.dumps(journal,indent=2).encode())
 written=[]
 try:
  for relative,data in outputs.items():atomic(module/relative,data);written.append(relative)
  journal['state']='applied';atomic(backup/'transaction.json',json.dumps(journal,indent=2).encode());atomic(module/'VEXORA-COMPAT.json',json.dumps(journal,indent=2).encode())
 except Exception:
  for relative in reversed(written):
   data=originals[relative]
   if data is None:(module/relative).unlink()
   else:atomic(module/relative,data)
  journal['state']='restored';atomic(backup/'transaction.json',json.dumps(journal,indent=2).encode());raise
 return {'status':'applied','version':VERSION,'backup':str(backup),'physical_xbox_verified':False}

def wait_registered(lookup,wait,version,clock=time.monotonic,timeout=30):
 deadline=clock()+timeout
 while clock()<deadline:
  current=lookup('script.module.thecrew')
  if current and current.get('version')==version:return
  if wait(.1):raise RuntimeError('Crew registration interrupted by Kodi shutdown')
 raise RuntimeError('Kodi has not registered the requested Crew runtime version')

def run():
 import xbmc,xbmcaddon,xbmcgui,xbmcvfs
 from .kodi_status import get_addon
 if xbmcgui.Window(10000).getProperty('vexora.installing')!='true':raise RuntimeError('Crew compatibility requires active full-build consent')
 if xbmc.Player().isPlaying():raise RuntimeError('Stop playback before changing the Crew runtime')
 ids=('plugin.video.thecrew','script.module.thecrew');states={aid:get_addon(aid) for aid in ids}
 if not all(states.values()):raise RuntimeError('Kodi must install Crew and its dependencies before compatibility repair')
 module=Path(xbmcvfs.translatePath(xbmcaddon.Addon('script.module.thecrew').getAddonInfo('path')))
 assets=Path(__file__).parents[1]/'compat';backups=Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/crew-compat-backups'))
 def enable(aid,value):
  response=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':aid,'enabled':value}})))
  if response.get('error'):raise RuntimeError('Kodi refused Crew runtime state change: '+aid)
 disabled=[]
 try:
  for aid in ids:
   if states[aid]['enabled']:enable(aid,False);disabled.append(aid)
  result=apply(module,assets,backups);xbmc.executebuiltin('UpdateLocalAddons',False)
  wait_registered(get_addon,xbmc.Monitor().waitForAbort,VERSION)
 finally:
  for aid in reversed(disabled):enable(aid,True)
 if not get_addon('script.module.thecrew') or get_addon('script.module.thecrew')['version']!=VERSION:raise RuntimeError('Kodi has not registered the repaired Crew runtime')
 xbmc.log('Vexora Crew compatibility: '+result['status']+'; Xbox playback not verified',xbmc.LOGINFO)
 return result


def restore(module,backup,kodi_stopped=False,native_quiesced=False):
 if not kodi_stopped and not native_quiesced:raise RuntimeError('Close Kodi or disable the Crew runtime before restoring source files')
 module,backup=map(Path,(module,backup))
 if has_link_in_path(module) or has_link_in_path(backup):raise ValueError('Unsafe compatibility recovery path')
 transaction=backup/'transaction.json'
 if has_link_in_path(transaction) or transaction.stat().st_size>32000:raise ValueError('Unsafe compatibility journal')
 journal=json.loads(transaction.read_text(encoding='utf-8'))
 allowed={'addon.xml',*(REL+n for n in ('client.py','control.py','regex.py','sources.py','vexora_memory_functions.py','vexora_sports_diag.py'))}
 records=journal.get('installed_hashes',{});originals=journal.get('original_hashes',{})
 if journal.get('id')!='script.module.thecrew' or journal.get('state')!='applied' or not isinstance(records,dict) or not set(records)<=allowed or set(records)!=set(originals):raise ValueError('Invalid compatibility recovery journal')
 if not {'addon.xml',REL+'regex.py'}<=set(records):raise ValueError('Incomplete compatibility recovery journal')
 data={}
 for relative,expected in records.items():
  target=module/relative
  if has_link_in_path(target) or not target.is_file() or digest(target.read_bytes())!=expected:raise ValueError('Crew source changed since repair; retain the newer files')
  leaf=journal.get('backup_files',{}).get(relative,relative)
  if 'backup_files' in journal and originals[relative] is not None and not re.fullmatch(r'b[0-9]+',leaf):raise ValueError('Invalid compact backup member')
  source=backup/leaf;prior=originals[relative]
  if prior is not None:
   if has_link_in_path(source) or not source.is_file() or digest(source.read_bytes())!=prior:raise ValueError('Crew backup integrity failure')
   data[relative]=source.read_bytes()
  else:data[relative]=None
 marker=module/'VEXORA-COMPAT.json'
 if marker.exists() and (has_link_in_path(marker) or marker.stat().st_size>32000):raise ValueError('Unsafe compatibility marker')
 # All targets and originals are checked before restoring any file.
 for relative,blob in data.items():
  if blob is None:(module/relative).unlink()
  else:atomic(module/relative,blob)
 marker=module/'VEXORA-COMPAT.json'
 if marker.exists():
  if has_link_in_path(marker):raise ValueError('Unsafe compatibility marker')
  marker.unlink()
 journal['state']='restored';atomic(transaction,json.dumps(journal,indent=2).encode())
 return {'status':'restored'}


def run_recovery():
 import xbmc,xbmcaddon,xbmcgui,xbmcvfs
 from .kodi_status import get_addon
 dialog=xbmcgui.Dialog();parent=Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/crew-compat-backups'))
 if has_link_in_path(parent):raise ValueError('Unsafe compatibility backup directory')
 choices=[]
 for tx in sorted(parent.glob('crew-*/transaction.json'),reverse=True):
  if has_link_in_path(tx) or tx.stat().st_size>32000:continue
  try:
   if json.loads(tx.read_text(encoding='utf-8')).get('state')=='applied':choices.append(tx.parent)
  except (OSError,ValueError):continue
 if not choices:dialog.ok('Crew compatibility recovery','No active Crew compatibility backup is available.');return
 selected=dialog.select('Restore Crew compatibility backup',[p.name for p in choices])
 if selected<0:return
 if xbmc.Player().isPlaying():raise RuntimeError('Stop playback before Crew recovery')
 ids=('plugin.video.thecrew','script.module.thecrew');states={aid:get_addon(aid) for aid in ids}
 if not all(states.values()):raise RuntimeError('Crew runtime must still be registered for native recovery')
 module=Path(xbmcvfs.translatePath(xbmcaddon.Addon('script.module.thecrew').getAddonInfo('path')))
 def enable(aid,value):
  r=json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':'Addons.SetAddonEnabled','params':{'addonid':aid,'enabled':value}})))
  if r.get('error'):raise RuntimeError('Kodi refused the requested recovery state')
 disabled=[]
 try:
  for aid in ids:
   if states[aid]['enabled']:enable(aid,False);disabled.append(aid)
  if any((get_addon(aid) or {}).get('enabled') for aid in ids):raise RuntimeError('Crew could not be disabled for recovery')
  result=restore(module,choices[selected],native_quiesced=True);xbmc.executebuiltin('UpdateLocalAddons',False)
  wait_registered(get_addon,xbmc.Monitor().waitForAbort,ET.fromstring((module/'addon.xml').read_bytes()).get('version'))
 finally:
  for aid in reversed(disabled):enable(aid,True)
 dialog.ok('Crew compatibility restored','The reviewed original source files were restored. Restart Kodi before testing Crew again. Personal settings and accounts were retained.')
 return result
