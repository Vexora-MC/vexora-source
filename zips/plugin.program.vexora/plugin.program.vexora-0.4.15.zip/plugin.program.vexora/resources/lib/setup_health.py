"""Read-only post-install evidence, separate from native installation success."""
import importlib
import json
import re
import sqlite3
from contextlib import closing
from pathlib import Path


def crypto_capability(importer=importlib.import_module):
    """Test usable cipher imports; never log exception text or account settings."""
    attempts = []
    for module, symbol in [('Cryptodome.Cipher.ChaCha20_Poly1305', 'new'),
                           ('Crypto.Cipher.ChaCha20_Poly1305', 'new'),
                           ('cryptography.hazmat.primitives.ciphers.aead', 'ChaCha20Poly1305')]:
        try:
            backend = importer(module)
            if not callable(getattr(backend, symbol, None)):
                raise ImportError('Cipher entry point unavailable')
            # Import alone can hide unusable native libraries; use synthetic bytes only.
            if symbol == 'new':
                cipher = backend.new(key=bytes(32), nonce=bytes(12))
                payload, tag = cipher.encrypt_and_digest(b'Vexora capability probe')
                other = backend.new(key=bytes(32), nonce=bytes(12))
                if other.decrypt_and_verify(payload, tag) != b'Vexora capability probe':
                    raise ValueError('Cipher roundtrip failed')
            else:
                cipher = backend.ChaCha20Poly1305(bytes(32))
                payload = cipher.encrypt(bytes(12), b'Vexora capability probe', None)
                if cipher.decrypt(bytes(12), payload, None) != b'Vexora capability probe':
                    raise ValueError('Cipher roundtrip failed')
            return {'status': 'available', 'backend': module.split('.')[0]}
        except Exception:
            attempts.append(module.split('.')[0])
    return {'status': 'unavailable', 'checked_backends': attempts}


def installed_crypto_capability(lookup,location,manifest,probe=crypto_capability):
    """Probe enabled module add-ons in their real library paths, not the Wizard's import scope."""
    import sys
    from xml.etree import ElementTree as ET
    from .safe_paths import validate_relative_path,has_link_in_path
    paths=[]
    for aid in ('script.module.pycryptodome','script.module.cryptography','script.module.cffi'):
        try:
            if not (lookup(aid) or {}).get('enabled'):continue
            raw=manifest(aid)
            if len(raw)>512000:continue
            root=ET.fromstring(raw)
            if root.get('id')!=aid:continue
            for node in root.findall("./extension[@point='xbmc.python.module']"):
                relative=node.get('library','lib');validate_relative_path(relative)
                path=Path(location(aid))/relative
                if path.is_dir() and not has_link_in_path(path):paths.append(str(path))
        except (OSError,ValueError,RuntimeError,ET.ParseError):continue
    original=list(sys.path)
    try:
        sys.path[:0]=[path for path in paths if path not in sys.path]
        return probe()
    finally:sys.path[:]=original


def update_evidence(database, addon_ids):
    """Snapshot Kodi-owned update metadata; failures remain unknown, never fixed via SQL."""
    ids = sorted(set(addon_ids))
    if any(not re.fullmatch(r'[A-Za-z0-9_.-]+', aid) for aid in ids):
        raise ValueError('Unsafe add-on identity')
    result = {aid: {'status': 'unknown'} for aid in ids}
    if not Path(database).is_file():
        return result
    try:
        with closing(sqlite3.connect(Path(database).absolute().as_uri() + '?mode=ro', uri=True,
                                     timeout=1)) as connection:
            for aid in ids:
                row = connection.execute('SELECT enabled, origin FROM installed WHERE addonID=?', (aid,)).fetchone()
                rules = connection.execute('SELECT updateRule FROM update_rules WHERE addonID=?', (aid,)).fetchall()
                if row:
                    origin = row[1] or ''
                    publisher = origin if re.fullmatch(r'repository\.[A-Za-z0-9_.-]+', origin) else ''
                    result[aid] = {'status': 'held' if rules else ('publisher_recorded' if publisher else 'manual_or_system'),
                                   'origin': publisher, 'rules': sorted({int(r[0]) for r in rules})}
    except (sqlite3.Error, OSError, ValueError):
        return {aid: {'status': 'unknown'} for aid in ids}
    return result


def collect_health(addon_ids, assess, evidence, capability):
    rows = {}
    for aid in sorted(set(addon_ids)):
        try:
            ready = assess(aid)
            rows[aid] = {'dependencies_ready': ready.get('ready') is True,
                         'blockers': ready.get('blockers', []),
                         'updates': evidence.get(aid, {'status': 'unknown'})}
        except (OSError, RuntimeError, ValueError):
            rows[aid] = {'dependencies_ready': False, 'blockers': [{'status': 'verification_failed'}],
                         'updates': {'status': 'unknown'}}
    return {'format': 1, 'addons': rows, 'sports_crypto': capability,
            'external_provider_playback': 'not_verified'}


def run_health(addon_ids=None, show=True):
    import xbmcgui
    import xbmcvfs
    from .optional_catalogue import OPTIONAL_ADDONS
    from .kodi_status import get_addon
    from .readiness import assess_installed_plugin
    from .optional_setup import save_choices
    ids = addon_ids if addon_ids is not None else [a['id'] for a in OPTIONAL_ADDONS.values() if get_addon(a['id'])]
    repos = {a['repository'] for a in OPTIONAL_ADDONS.values() if a['id'] in ids}
    dbdir = Path(xbmcvfs.translatePath('special://database/'))
    databases = sorted(dbdir.glob('Addons*.db'), key=lambda p: int(re.search(r'(\d+)\.db$', p.name).group(1)))
    evidence = update_evidence(databases[-1], set(ids) | repos) if databases else {}
    import xbmcaddon
    from .installed_manifest import read_dependency_manifest
    capability=installed_crypto_capability(get_addon,lambda aid:xbmcvfs.translatePath(xbmcaddon.Addon(aid).getAddonInfo('path')),read_dependency_manifest)
    report = collect_health(ids, assess_installed_plugin, evidence, capability)
    report['repositories'] = {aid: evidence.get(aid, {'status': 'unknown'}) for aid in sorted(repos)}
    report['repositories_enabled'] = {aid: bool((get_addon(aid) or {}).get('enabled')) for aid in sorted(repos)}
    target = Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/setup-health.json'))
    compat=target.with_name('crew-compat.json')
    if compat.is_file() and compat.stat().st_size<32000:
        try:
            report['crew_compatibility']=json.loads(compat.read_text(encoding='utf-8'))
            current=get_addon('script.module.thecrew')
            if current and report['crew_compatibility'].get('version') and current.get('version')!=report['crew_compatibility']['version']:
                report['crew_compatibility']={'status':'publisher_version_changed','current_version':current.get('version')}
        except (OSError,ValueError):report['crew_compatibility']={'status':'unknown'}
    save_choices(target, report)
    if show:
        lines = [aid + ': ' + ('dependencies verified' if row['dependencies_ready'] else 'dependencies incomplete') +
                 '; updates ' + row['updates']['status'] for aid, row in report['addons'].items()]
        lines += [aid + ': updates ' + row['status'] for aid, row in report['repositories'].items()]
        if report.get('crew_compatibility'):lines+=['Crew compatibility: '+report['crew_compatibility'].get('status','unknown')+'; Xbox result not verified']
        lines += ['Sports crypto: ' + report['sports_crypto']['status'],
                  'Provider listings, playback and personal authorisation require separate tests.',
                  'Review held/manual components in Kodi My add-ons. No update settings were changed.']
        ecosystem=target.with_name('repository-setup-report.json')
        if ecosystem.is_file() and not ecosystem.is_symlink() and ecosystem.stat().st_size<2000000:
            try:
                from collections import Counter
                results=json.loads(ecosystem.read_text(encoding='utf-8')).get('results',{})
                counts=Counter(row.get('status','unknown') for row in results.values())
                lines += ['Repository ecosystem: '+', '.join(str(n)+' '+status for status,n in sorted(counts.items()))]
                lines += [aid+': '+row.get('status','unknown')+' - '+row.get('reason','') for aid,row in sorted(results.items()) if row.get('status') not in ('verified','reused')]
            except (ValueError,OSError,AttributeError):lines+=['Expanded repository report unavailable']
        xbmcgui.Dialog().textviewer('Vexora setup verification', '\n'.join(lines))
    return report


def run_repair():
    """Repair declared missing/disabled dependencies through Kodi only, never reset settings."""
    import xbmc
    import xbmcgui
    from .kodi_status import get_addon
    from .optional_catalogue import OPTIONAL_ADDONS
    from .readiness import assess_installed_plugin
    ids=sorted({a['id'] for a in OPTIONAL_ADDONS.values() if get_addon(a['id'])})
    plan={}
    for aid in ids:
        for blocker in assess_installed_plugin(aid).get('blockers',[]):
            dep=blocker.get('id','')
            if re.fullmatch(r'[A-Za-z0-9_.-]+',dep) and blocker.get('status') in ('missing','disabled'):
                plan[dep]='EnableAddon' if blocker['status']=='disabled' else 'InstallAddon'
    if not plan:
        xbmcgui.Dialog().ok('Vexora dependency repair','No missing or disabled declared dependencies detected. Provider feeds and personal settings are not reset.')
        return run_health(ids)
    if not xbmcgui.Dialog().yesno('Repair Vexora dependencies','Ask Kodi to install/enable '+str(len(plan))+' missing or disabled dependencies? Kodi security confirmations remain.'):
        return None
    for dep,command in sorted(plan.items()):
        xbmc.executebuiltin(command+'('+dep+')',True)
        xbmc.log('Vexora dependency repair requested: '+dep,xbmc.LOGINFO)
    xbmc.executebuiltin('UpdateAddonRepos')
    return run_health(ids)
