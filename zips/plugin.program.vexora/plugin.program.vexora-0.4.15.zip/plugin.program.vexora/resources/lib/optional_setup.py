"""Optional native installs, separate from mandatory build success/rollback."""
import hashlib
import json
import time
from pathlib import Path
from .optional_catalogue import OPTIONAL_ADDONS, OPTIONAL_REPOSITORIES, selected_addons
from .safe_paths import has_link_in_path
from .dependencies import _meets_minimum


def read_choices(path):
    path = Path(path)
    if has_link_in_path(path):
        raise ValueError('Unsafe optional setup state path')
    if not path.exists():
        return {'format': 1, 'status': 'new', 'results': {}}
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('format') != 1 or data.get('status') not in ('new', 'dismissed', 'completed', 'partial', 'cancelled'):
        raise ValueError('Invalid optional setup state')
    return data


def save_choices(path, state):
    path = Path(path)
    if has_link_in_path(path):
        raise ValueError('Unsafe optional setup state path')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    if has_link_in_path(temporary):
        raise ValueError('Unsafe optional setup temporary path')
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True), encoding='utf-8')
    temporary.replace(path)


def reviewed_repository_packages(fetch=None):
    """Validate all additional publishers before the build changes profile data."""
    from .repository_download import fetch_repository_zip
    from .repository_preflight import inspect_repository_zip
    packages = {}
    for repo, source in OPTIONAL_REPOSITORIES.items():
        data = (fetch or fetch_repository_zip)(repo, source=source)
        if hashlib.sha256(data).hexdigest() != source['sha256']:
            raise ValueError('Publisher repository changed; review required: ' + repo)
        inspect_repository_zip(data, repo, versions={repo: source['version']})
        packages[repo] = data
    return packages


def install_build_repositories(packages, lookup, execute, wait, installed_path,
                               clock=time.monotonic, *, refresh=True):
    """All four repositories are part of build consent; video add-ons stay optional."""
    from .runtime_setup import verify_repository_files
    if set(packages) != set(OPTIONAL_REPOSITORIES):
        raise ValueError('All additional repository packages are required')
    changed = False
    for repo, source in OPTIONAL_REPOSITORIES.items():
        data = packages[repo]
        if hashlib.sha256(data).hexdigest() != source['sha256']:
            raise ValueError('Publisher repository changed; review required: ' + repo)
        current = lookup(repo)
        if current and not _meets_minimum(current.get('version'), source['version']):
            raise ValueError('Installed repository differs from reviewed version: ' + repo)
        if not current or not current.get('enabled'):
            changed = True
            execute(('EnableAddon' if current else 'InstallAddon') + '(' + repo + ')')
        deadline = clock() + 60
        while clock() < deadline:
            current = lookup(repo)
            if current and current.get('enabled') and _meets_minimum(current.get('version'), source['version']):
                break
            if wait(0.5):
                raise RuntimeError('Kodi is shutting down')
        else:
            raise RuntimeError('Repository installation failed or timed out: ' + repo)
        verify_repository_files({repo: data}, installed_path,
                                versions={repo: source['version']}, allow_newer=True)
    if refresh and changed:
        execute('UpdateAddonRepos')


def approved_repository_source(repo):
    """Reuse mandatory repository identities/pins; never install a second copy."""
    from .repository_sources import SOURCES
    from .runtime_setup import APPROVED_SHA256
    if repo in SOURCES:
        return dict(SOURCES[repo], sha256=APPROVED_SHA256[repo])
    return OPTIONAL_REPOSITORIES[repo]


class SetupCancelled(RuntimeError):
    pass


def install_selected(keys, lookup, execute, wait, installed_path, verify_ready,
                     fetch=None, clock=time.monotonic, *, progress=None, cancelled=None):
    """Use Kodi for installation/dependencies and verify observed completion."""
    from .repository_download import fetch_repository_zip
    from .runtime_setup import verify_repository_files
    results = {}
    verified = set()
    refreshed = False
    addons = selected_addons(keys)
    stopped = False
    for index, addon in enumerate(addons):
        id = addon['id']
        if stopped or (cancelled and cancelled()):
            results[id] = {'status': 'cancelled', 'reason': 'Optional setup cancelled'}
            stopped = True
            continue
        try:
            if progress:
                progress(index, len(addons), addon['name'])
            current = lookup(id)
            # A working add-on can still be outdated. Ask Kodi to refresh the
            # publisher catalogues and process native updates before accepting
            # readiness; do not pin the video plug-in to verified_version.
            if current and current.get('enabled') and verify_ready(id).get('ready'):
                if not refreshed:
                    execute('UpdateAddonRepos')
                    refreshed = True
                execute('UpdateLocalAddons')
                # Kodi updates asynchronously. A refresh request is not
                # evidence that the latest publisher release is installed.
                if wait(0.5) or (cancelled and cancelled()):
                    raise SetupCancelled('Optional setup cancelled or Kodi is shutting down')
                if verify_ready(id).get('ready'):
                    results[id] = {'status': 'installed', 'update_status': 'requested_not_verified'}
                    continue
            repo = addon['repository']
            source = approved_repository_source(repo)
            if repo not in verified:
                data = (fetch or fetch_repository_zip)(repo, source=source)
                if hashlib.sha256(data).hexdigest() != source['sha256']:
                    raise ValueError('Publisher repository changed; review required: ' + repo)
                current = lookup(repo)
                if current and not _meets_minimum(current.get('version'), source['version']):
                    raise ValueError('Installed repository differs from reviewed version: ' + repo)
                changed = not current or not current.get('enabled')
                if changed:
                    if cancelled and cancelled():
                        raise SetupCancelled('Optional setup cancelled')
                    execute(('EnableAddon' if current else 'InstallAddon') + '(' + repo + ')')
                deadline = clock() + 60
                while clock() < deadline:
                    current = lookup(repo)
                    if current and current.get('enabled') and _meets_minimum(current.get('version'), source['version']):
                        break
                    if wait(0.5) or (cancelled and cancelled()):
                        raise SetupCancelled('Optional setup cancelled or Kodi is shutting down')
                else:raise RuntimeError('Repository install cancelled, failed or timed out: ' + repo)
                verify_repository_files({repo: data}, installed_path,
                                        versions={repo: source['version']}, allow_newer=True)
                if changed and not refreshed:
                    execute('UpdateAddonRepos')
                    refreshed = True
                verified.add(repo)
            current = lookup(id)
            if not current or not current.get('enabled'):
                if cancelled and cancelled():
                    raise SetupCancelled('Optional setup cancelled')
                execute(('EnableAddon' if current else 'InstallAddon') + '(' + id + ')')
            deadline = clock() + 90
            while clock() < deadline:
                readiness = verify_ready(id)
                observed = lookup(id)
                if observed and observed.get('enabled') and readiness.get('ready'):
                    results[id] = {'status': 'installed'}
                    break
                if wait(0.5) or (cancelled and cancelled()):
                    raise SetupCancelled('Optional setup cancelled or Kodi is shutting down')
            else:raise RuntimeError('Add-on or dependencies not ready after native installation: ' + id)
        except SetupCancelled as error:
            results[id] = {'status': 'cancelled', 'reason': str(error)}
            stopped = True
        except (OSError, ValueError, RuntimeError) as error:
            results[id] = {'status': 'failed', 'reason': str(error)}
    return results


def run_optional_setup(first_run=False, chosen=None, progress_view=None, summary=True, full_build_consented=False):
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from .kodi_status import get_addon
    from .readiness import assess_installed_plugin
    dialog = xbmcgui.Dialog()
    path = Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/optional-setup.json'))
    try:
        state = read_choices(path)
        if first_run and chosen is None and state['status'] != 'new':
            return
        keys = [key for key, item in OPTIONAL_ADDONS.items()
                if key != 'crew_sports' and not item.get('unavailable')]
        choices = ([keys.index(key) for key in chosen] if chosen is not None else
                   dialog.multiselect('Vexora add-ons - select or cancel to skip',
                                     [OPTIONAL_ADDONS[key]['name'] for key in keys]))
        state['status'] = 'dismissed'
        save_choices(path, state)  # Do not repeat the prompt after cancellation/interruption.
        if not choices:
            return
        chosen = [keys[index] for index in choices]
        monitor = xbmc.Monitor()
        progress = progress_view or xbmcgui.DialogProgressBG()
        progress.create('Vexora optional add-ons', 'Kodi may ask for installation approval')
        try:
            pending={'id':None}
            allowed={item['id'] for item in selected_addons(chosen)} | {item['repository'] for item in selected_addons(chosen)}
            def execute(command):
                if full_build_consented:
                    from .install_confirmation import execute_consented
                    if command.startswith('InstallAddon('):pending['id']=command[len('InstallAddon('):-1]
                    return execute_consented(command,allowed,progress_view)
                return xbmc.executebuiltin(command,True)
            def native_wait(seconds):
                if full_build_consented and pending['id']:
                    from .install_confirmation import acknowledge_failure
                    if acknowledge_failure(pending['id'],allowed):
                        raise RuntimeError('Kodi reported installation failed: '+pending['id'])
                return monitor.waitForAbort(seconds)
            results = install_selected(chosen, get_addon,
                execute, native_wait,
                lambda id: xbmcvfs.translatePath(xbmcaddon.Addon(id).getAddonInfo('path')),
                assess_installed_plugin, cancelled=lambda: monitor.abortRequested() or bool(progress_view and progress_view.iscanceled()),
                progress=lambda index, count, name: progress.update(
                    int(100 * index / count), 'Vexora optional add-ons', 'Installing / verifying ' + name))
        finally:
            progress.close()
        for addon in selected_addons(chosen):
            results.setdefault(addon['id'], {'status': 'failed',
                'reason': 'No verified installation result returned'})
        if full_build_consented and results.get('plugin.video.Rising.Tides',{}).get('status')=='failed':
            try:
                from .publisher_archive_repair import run as repair_publisher_archive
                results['plugin.video.Rising.Tides']=repair_publisher_archive()
            except SetupCancelled:
                raise
            except (OSError,ValueError,RuntimeError) as error:
                results['plugin.video.Rising.Tides']['reason']+='; reviewed publisher archive recovery: '+str(error)
        if full_build_consented and results.get('plugin.video.thecrew',{}).get('status')=='installed':
            try:
                from .crew_compat import run as repair_crew_runtime
                compatibility=repair_crew_runtime()
            except (OSError,ValueError,RuntimeError) as error:
                compatibility={'status':'incomplete','reason':str(error)}
                results['plugin.video.thecrew']={'status':'failed','reason':'Crew compatibility repair: '+str(error)}
            save_choices(path.with_name('crew-compat.json'),compatibility)
        success = all(item['status'] == 'installed' for item in results.values())
        status = 'completed' if success else ('cancelled' if any(
            item['status'] == 'cancelled' for item in results.values()) else 'partial')
        state.update(status=status, selected=chosen, results=results)
        save_choices(path, state)
        failed = [id + ': ' + item['reason'] for id, item in results.items() if item['status'] != 'installed']
        if failed and summary:
            dialog.ok('Optional add-on setup incomplete', '\n'.join(failed) +
                      '\nRetry any selection from Add-on management.')
        elif summary:
            dialog.notification('Vexora', 'Selected add-ons and dependencies verified', time=5000)
    except (OSError, ValueError, RuntimeError) as error:
        dialog.ok('Optional add-on setup incomplete', str(error) +
                  '. The mandatory Vexora build is unaffected. Retry from Add-on management.')


def run_selected_addon(key):
    """Called after the tile's single OK/Cancel prompt; no second selection UI."""
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from .kodi_status import get_addon
    from .readiness import assess_installed_plugin
    selected_addons([key])  # Reject an unknown key before doing any work.
    monitor = xbmc.Monitor()
    results = install_selected([key], get_addon,
        lambda command: xbmc.executebuiltin(command, True), monitor.waitForAbort,
        lambda id: xbmcvfs.translatePath(xbmcaddon.Addon(id).getAddonInfo('path')),
        assess_installed_plugin)
    result = results[OPTIONAL_ADDONS[key]['id']]
    failed = result['status'] != 'installed'
    message = result.get('reason', OPTIONAL_ADDONS[key]['name'] + ' installed and ready')
    if failed:xbmc.log('Vexora add-on installation: ' + message, xbmc.LOGERROR)
    xbmcgui.Dialog().notification('Add-on installation incomplete' if failed else 'Vexora',
                                  message, time=8000 if failed else 3500)
    xbmc.executebuiltin('Container.Refresh')
    return results
