"""Reviewed repository-only bootstrap bytes; Kodi retains upstream update policy."""
import hashlib,re
from pathlib import Path
from .safe_paths import has_link_in_path

def load(repo_id,expected_sha=None,folder=None):
 if not re.fullmatch(r'repository\.[A-Za-z0-9_.-]+',repo_id):raise ValueError('Invalid repository ID')
 root=Path(folder) if folder is not None else Path(__file__).parents[1]/'build/repository_packages'
 path=root/(repo_id+'.zip')
 if not path.exists():return None
 if has_link_in_path(path) or path.stat().st_size>20*1024*1024:raise ValueError('Unsafe bundled repository archive')
 if expected_sha is None:
  from .optional_setup import approved_repository_source
  expected_sha=approved_repository_source(repo_id)['sha256']
 data=path.read_bytes()
 if hashlib.sha256(data).hexdigest()!=expected_sha:raise ValueError('Bundled publisher repository integrity failure: '+repo_id)
 return data
