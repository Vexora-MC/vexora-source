"""Bounded native installation of individually reviewed publisher repositories."""
import hashlib
import io
import json
from pathlib import Path
import time
from xml.etree import ElementTree as ET
from zipfile import ZipFile
from .dependencies import _meets_minimum
from .safe_paths import has_link_in_path,validate_relative_path


def catalogue():
    data=json.loads((Path(__file__).parents[1]/'repository-ecosystem.json').read_text(encoding='utf-8'))
    rows=data['repositories']
    if len(rows)!=74 or len({r['id'] for r in rows})!=74:raise ValueError('Invalid repository ecosystem identities')
    return data


def approved_package(row, blob):
    if len(blob)>20*1024*1024 or hashlib.sha256(blob).hexdigest()!=row['sha256']:
        raise ValueError('Publisher package changed; review required')
    with ZipFile(io.BytesIO(blob)) as z:
        if len(z.infolist())>500 or sum(e.file_size for e in z.infolist())>30*1024*1024 or z.testzip() is not None:raise ValueError('Archive integrity/size failure')
        seen=set()
        prefix=row.get('archive_prefix',row['id']+'/')
        if not prefix.endswith('/') or len(validate_relative_path(prefix[:-1]))!=1:raise ValueError('Invalid reviewed archive root')
        ignored=set(row.get('ignored_archive_members',[]))
        for e in z.infolist():
            name=e.filename
            if '..' in name.split('/') or '\\' in name or name.casefold() in seen or (e.external_attr>>16)&0o170000==0o120000:raise ValueError('Unsafe archive path')
            validate_relative_path(name.rstrip('/'))
            if name in ignored:
                if not name.startswith('__MACOSX/') or e.file_size>128*1024:raise ValueError('Unapproved auxiliary archive data')
                if not e.is_dir() and (not name.rsplit('/',1)[-1].startswith('._') or z.read(e)[:4]!=b'\x00\x05\x16\x07'):
                    raise ValueError('Expected AppleDouble metadata only')
            elif not name.startswith(prefix):raise ValueError('Unsafe archive root')
            seen.add(name.casefold())
        root=ET.fromstring(z.read(prefix+'addon.xml'))
        if root.get('id')!=row['id'] or root.get('version')!=row['version']:raise ValueError('Publisher identity/version mismatch')
        if any(e.get('point') not in ('xbmc.addon.repository','xbmc.addon.metadata') for e in root.findall('extension')):raise ValueError('Unexpected executable repository extension')
        return root


def endpoints(root):
    def canonical(e):return (e.tag,tuple(sorted(e.attrib.items())),(e.text or '').strip(),tuple(canonical(c) for c in e))
    return [canonical(e) for e in root.findall("./extension[@point='xbmc.addon.repository']")]


def install_ecosystem(rows, lookup, execute, wait, installed_path, fetch, *, progress=None, clock=time.monotonic):
    results={};changed=False;stopped=False
    for index,row in enumerate(rows):
        aid=row['id']
        if progress:progress(index,len(rows),aid)
        if stopped:results[aid]={'status':'cancelled','reason':'Kodi is stopping'};continue
        if row['status'] in ('original_setup','kodi_managed'):
            current=lookup(aid)
            results[aid]={'status':'reused' if current and current.get('enabled') else 'unverified','reason':row['reason']}
            continue
        if row['status']!='package_verified':
            results[aid]={'status':'excluded','reason':row['reason'],'attempts':row.get('attempts',[])};continue
        try:
            if wait(.001):stopped=True;results[aid]={'status':'cancelled','reason':'Kodi is stopping'};continue
            blob=fetch(row['zip_url']);expected=approved_package(row,blob)
            current=lookup(aid)
            if current and not _meets_minimum(current.get('version'),row['version']):
                # Kodi InstallAddon cannot reliably update an already installed older version.
                results[aid]={'status':'pending_update','reason':'Existing older repository retained; use Kodi native Updates'};continue
            if not current or not current.get('enabled'):
                execute(('EnableAddon' if current else 'InstallAddon')+'('+aid+')');changed=True
            deadline=clock()+60
            while clock()<deadline:
                current=lookup(aid)
                if current and current.get('enabled') and _meets_minimum(current.get('version'),row['version']):break
                if wait(.5):stopped=True;raise RuntimeError('Kodi stopped during repository setup')
            else:raise RuntimeError('Kodi installation declined, unavailable or timed out')
            folder=Path(installed_path(aid));p=folder/'addon.xml'
            if has_link_in_path(p) or p.stat().st_size>512000:raise ValueError('Unsafe installed repository metadata')
            actual=ET.fromstring(p.read_bytes())
            if actual.get('id')!=aid or actual.get('version')!=current.get('version') or endpoints(actual)!=endpoints(expected):raise ValueError('Installed publisher metadata differs from reviewed source')
            results[aid]={'status':'verified','version':current['version']}
        except Exception as e:
            results[aid]={'status':'failed','reason':type(e).__name__+': '+str(e)[:180]}
    if changed and not stopped:execute('UpdateAddonRepos')
    return results


def run_ecosystem(progress_view=None):
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
    from .kodi_status import get_addon
    from .optional_setup import save_choices
    from .repository_download import _default_open
    from urllib.request import Request
    rows=catalogue()['repositories'];monitor=xbmc.Monitor()
    def fetch(url):
        with _default_open(Request(url,headers={'User-Agent':'Kodi/21.3 (Windows NT 10.0; Win64; x64)'}),timeout=12) as response:
            return response.read(20*1024*1024+1)
    progress=progress_view or xbmcgui.DialogProgressBG();progress.create('Vexora repository setup','Installing compatible publisher repositories')
    try:
        results=install_ecosystem(rows,get_addon,lambda command:xbmc.executebuiltin(command,True),(lambda seconds: monitor.waitForAbort(seconds) or bool(progress_view and progress_view.iscanceled())),
            lambda aid:xbmcvfs.translatePath(xbmcaddon.Addon(aid).getAddonInfo('path')),fetch,
            progress=lambda index,count,aid:progress.update(int(100*index/count),'Vexora repository setup',aid))
    finally:progress.close()
    target=Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/repository-setup-report.json'))
    save_choices(target,{'format':1,'results':results})
    return results
