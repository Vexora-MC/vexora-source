"""Kodi-managed directory operations with verified private staging ownership."""
from pathlib import Path
from contextlib import contextmanager
import hashlib
import itertools
import time
import uuid

_sequence = itertools.count()


def ensure_directory(folder, *, exist_ok=True):
    """Verify directory state, not the backend creation return value.

    Some Kodi backends report false/None after successful creation. Existing
    destinations are still rejected for exclusive callers before creation.
    Such callers create children only inside an owned staging directory.
    """
    folder = Path(folder)
    try:
        import xbmcvfs
    except ImportError:
        folder.mkdir(parents=True, exist_ok=exist_ok)
        return folder
    directory = str(folder).rstrip('/\\') + '/'
    if xbmcvfs.exists(directory):
        if not exist_ok:
            raise FileExistsError('Managed directory already exists: ' + str(folder))
        return folder
    if exist_ok:
        xbmcvfs.mkdirs(directory)
    else:
        # The private parent is already present; do not recursively recreate it.
        xbmcvfs.mkdir(directory)
    if not xbmcvfs.exists(directory):
        raise OSError('Kodi could not create managed directory: ' + str(folder))
    return folder


def _staging_token():
    # Do not truncate the leading UUID bytes: repeated/zero prefixes were
    # observed on Xbox. The per-interpreter counter is independent of UUIDs.
    serial = next(_sequence)
    seed = '{}:{}:{}'.format(uuid.uuid4().hex, time.monotonic_ns(), serial)
    return hashlib.sha256(seed.encode('ascii')).hexdigest()[:10] + format(serial, '06x')


@contextmanager
def temporary_directory(parent, prefix):
    """Reserve a name using an exclusive file, then verify an empty folder.

    Only a folder with this invocation's intact ownership claim may be removed.
    Failed/colliding allocation never deletes an existing or unowned directory.
    """
    import re
    from .file_io import flush_file
    if not re.fullmatch(r'[.A-Za-z0-9_-]{1,40}', prefix):
        raise ValueError('Unsafe staging prefix')
    parent = ensure_directory(parent)
    try:
        import xbmcvfs
    except ImportError:
        import tempfile
        with tempfile.TemporaryDirectory(prefix=prefix, dir=str(parent)) as folder:
            yield folder
        return

    def present(folder):
        directories, files = xbmcvfs.listdir(str(parent).rstrip('/\\') + '/')
        return (xbmcvfs.exists(str(folder).rstrip('/\\') + '/')
                or xbmcvfs.exists(str(folder))
                or folder.name.casefold() in {n.casefold() for n in directories + files})

    for attempt in range(16):
        folder = parent / (prefix + _staging_token())
        claim = folder.with_name(folder.name + '.claim')
        if present(folder):
            continue
        token = folder.name.encode('ascii')
        try:
            with claim.open('xb') as output:
                output.write(token)
                flush_file(output)
        except FileExistsError:
            continue
        break
    else:
        raise FileExistsError('Staging directory collision; no existing files were changed')

    owned = False
    remove_claim = True
    directory = str(folder).rstrip('/\\') + '/'
    try:
        if present(folder):
            raise FileExistsError('Staging directory appeared during allocation')
        xbmcvfs.mkdir(directory)
        if not xbmcvfs.exists(directory):
            raise OSError('Kodi could not create private staging directory')
        if any(xbmcvfs.listdir(directory)):
            raise RuntimeError('Staging directory is not empty; no existing files were changed')
        owned = True
        yield str(folder)
    finally:
        if owned:
            if claim.read_bytes() != token:
                remove_claim = False
                raise RuntimeError('Staging ownership changed; directory retained')
            if xbmcvfs.exists(directory):
                xbmcvfs.rmdir(directory, True)
                if xbmcvfs.exists(directory):
                    remove_claim = False
                    raise OSError('Kodi could not remove private staging directory; claim retained')
        if remove_claim:
            claim.unlink(missing_ok=True)
