"""Provider-owned Sports rows: navigate verified menu labels, never guess event URLs."""
import ast,base64,json,re
from urllib.parse import urlencode,urlsplit,unquote
from .ui_text import themed_text
ROUTES={
 'boxing':{'provider':'plugin.video.madtitansports','key':'mad_titan','start':'main_list','path':('Live Sports','Boxing'),'name':'Mad Titan Boxing'},
 'football':{'provider':'plugin.video.Rising.Tides','key':'rising','path':('Football Live',),'name':'Rising Tides Football Live'}}
def menu_label(text):
 return re.sub(r'[^a-z0-9]','',re.sub(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]','',str(text),flags=re.I).casefold())
def owned_url(url,provider):
 if not isinstance(url,str):return False
 try:parsed=urlsplit(url)
 except ValueError:return False
 return parsed.scheme=='plugin' and parsed.netloc==provider and not parsed.fragment

def housekeeping(item):
 """Do not present provider notices/separators as playable event cards."""
 parsed=urlsplit(item['file']);path=parsed.path
 route=path.split('/')[1] if '/' in path else ''
 if (path in ('','/') and not parsed.query) or route in ('show_message','ignore','gui_home','main_list'):return True
 if route=='play_video':
  try:
   encoded=unquote(path.split('/',2)[2])
   if len(encoded)>16384:return False
   data=json.loads(base64.urlsafe_b64decode(encoded+'='*(-len(encoded)%4)).decode('utf-8'))
   return isinstance(data,dict) and data.get('link')=='ignore'
  except (ValueError,UnicodeError,IndexError):return False
 return False

def rising_entry(edit_source,router_source):
 """Read publisher-owned menu configuration without importing/executing it."""
 if len(edit_source)>16384 or len(router_source)>512000:raise ValueError('Oversized publisher route source')
 values=[n.value.value for n in ast.parse(edit_source).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='MainBase' for t in n.targets) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str)]
 if len(values)!=1:raise ValueError('Publisher root menu is not a single literal')
 parsed=urlsplit(values[0])
 if parsed.scheme not in ('http','https') or not parsed.netloc or parsed.username or parsed.password or parsed.fragment or len(values[0])>2048:raise ValueError('Unsupported publisher root menu URL')
 verified=False
 for node in ast.walk(ast.parse(router_source)):
  if not isinstance(node,ast.If):continue
  test=node.test
  if not (isinstance(test,ast.Compare) and isinstance(test.left,ast.Name) and test.left.id=='mode' and len(test.ops)==1 and isinstance(test.ops[0],ast.Eq) and len(test.comparators)==1 and isinstance(test.comparators[0],ast.Constant) and test.comparators[0].value==1):continue
  verified=any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='getData' and n.args and isinstance(n.args[0],ast.Name) and n.args[0].id=='url' for statement in node.body for n in ast.walk(statement))
  if verified:break
 if not verified:raise ValueError('Publisher directory mode changed; review required')
 return 'plugin://plugin.video.Rising.Tides/?'+urlencode({'mode':1,'url':values[0]})

def provider_entry(category):
 if category!='football':return None
 import xbmcaddon,xbmcvfs
 from pathlib import Path
 from .safe_paths import has_link_in_path
 folder=Path(xbmcvfs.translatePath(xbmcaddon.Addon(ROUTES[category]['provider']).getAddonInfo('path')))
 sources=[]
 for name,limit in (('_Edit.py',16384),('default.py',512000)):
  path=folder/name
  if has_link_in_path(path) or path.stat().st_size>limit:raise ValueError('Unsafe publisher route source')
  sources.append(path.read_text(encoding='utf-8-sig'))
 return rising_entry(*sources)

def directory_items(category,rpc,ready,start=None):
 if category not in ROUTES:raise ValueError('Unknown Sports row')
 route=ROUTES[category];provider=route['provider'];current=start or 'plugin://'+provider+'/'+route.get('start','')
 if not owned_url(current,provider):raise ValueError('Unowned Sports entry')
 if not ready:return [],'Install or enable '+route['name']+' and its required dependencies.',current
 def listing(url):
  response=json.loads(rpc(json.dumps({'jsonrpc':'2.0','id':1,'method':'Files.GetDirectory','params':{'directory':url,'media':'video','properties':['title','plot','art','thumbnail','fanart']}})))
  if response.get('error'):raise RuntimeError('Provider directory unavailable')
  files=response.get('result',{}).get('files',[])
  if not isinstance(files,list):raise ValueError('Invalid provider directory')
  return [item for item in files if isinstance(item,dict) and owned_url(item.get('file'),provider) and not housekeeping(item)]
 for index,label in enumerate(route['path']):
  items=listing(current)
  labels={menu_label(label)}
  # Verified current publisher label for the owner's Live Football section.
  if category=='football' and index==0:labels.add('livefootball')
  matches=[item for item in items if item.get('filetype')=='directory' and menu_label(item.get('label') or item.get('title','')) in labels]
  if len(matches)!=1:return [],'Open '+route['name']+' in its add-on to check the menu or source.',current
  current=matches[0]['file']
 entries=listing(current)
 return entries,('' if entries else 'No events returned by '+route['name']+'. Open the provider or try again later.'),current

def show_sports(handle,base_url,category,row=0):
 import xbmc,xbmcgui,xbmcplugin
 from .readiness import assess_installed_plugin
 if category not in ROUTES:raise ValueError('Unknown Sports row')
 route=ROUTES[category];ready=assess_installed_plugin(route['provider'])['ready'];fallback='plugin://'+route['provider']+'/'
 xbmcplugin.setContent(handle,'videos')
 try:
  if category=='football':
   from .football_rows import row_items
   entries,reason,fallback=row_items(row,xbmc.executeJSONRPC,ready,xbmcgui.Window(10000),base_url)
  else:entries,reason,fallback=directory_items(category,xbmc.executeJSONRPC,ready,start=provider_entry(category) if ready else None)
 except (OSError,ValueError,TypeError,RuntimeError):entries,reason=[],'Unable to load '+route['name']+'. Open its add-on to check the source.'
 for entry in entries:
  item=xbmcgui.ListItem(label=themed_text(entry.get('label') or entry.get('title') or ''))
  art=dict(entry.get('art') or {});art.setdefault('thumb',entry.get('thumbnail') or art.get('poster') or '');art.setdefault('fanart',entry.get('fanart') or '')
  item.setArt(art);item.getVideoInfoTag().setTitle(themed_text(entry.get('title') or entry.get('label') or ''))
  if entry.get('plot'):item.getVideoInfoTag().setPlot(themed_text(entry['plot']))
  folder=entry.get('filetype')=='directory';item.setProperty('IsPlayable','false' if folder else 'true');xbmcplugin.addDirectoryItem(handle,entry['file'],item,folder)
 if not entries:
  item=xbmcgui.ListItem(label=reason);item.setArt({'thumb':'special://home/addons/skin.vexora/media/vexoramcsports.png'});item.setProperty('IsPlayable','false')
  target=fallback if ready else base_url+'?'+urlencode({'action':'tile','key':route['key'],'section':'sports'})
  xbmcplugin.addDirectoryItem(handle,target,item,ready)
 # Live event availability changes frequently; do not cache empty/error results or schedules on disk.
 xbmcplugin.endOfDirectory(handle,cacheToDisc=False)
