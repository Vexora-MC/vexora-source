"""Keep provider text readable in Vexora without overriding artwork or routes."""
import re
_COMPACT_COLORS = 'red|white|aqua|blue|cyan|yellow|orange|lime|green|magenta|pink|gold|coral|chartreuse|black|grey|gray|silver|orchid|turquoise|violet|purple|teal|navy|maroon|fuchsia|olive'
_COLOR = re.compile(r'\[/?COLOR(?:[ =][^\]]*|[0-9a-f]{8}|[0-9a-f]{6}|' + _COMPACT_COLORS + r')?\]', re.IGNORECASE)

def themed_text(value):
    return _COLOR.sub('', value) if isinstance(value, str) else value
