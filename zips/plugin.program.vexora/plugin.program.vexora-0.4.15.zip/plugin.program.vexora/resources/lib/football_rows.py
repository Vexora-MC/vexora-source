"""Competition rows from Kodi's current Rising Tides Football Live listing.

Keep the provider's URLs, ordering, names and artwork. No league list or event
URLs are embedded here. The home-window snapshot is memory-only and shared by
all rows so a page does not launch dozens of duplicate provider requests.
"""
import json,re,time
from urllib.parse import urlencode
from .sports_catalogue import directory_items,provider_entry,owned_url,menu_label

PROVIDER='plugin.video.Rising.Tides'
SLOTS=64
CACHE='vexora.football.snapshot'

def plain_label(label):
    return re.sub(r'\[/?(?:COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]', '',str(label),flags=re.I).strip()

def competition_rows(items):
    """Group explicit publisher competition prefixes; omit notices/separators.

    Alternative sources without a colon inherit only an identified competition,
    and only when their label describes an event/source, never arbitrary notices.
    """
    rows=[];by_key={};current=None;seen=set()
    for item in items:
        if not isinstance(item,dict) or not owned_url(item.get('file'),PROVIDER):continue
        label=plain_label(item.get('label') or item.get('title') or '')
        if not label or label.startswith(('++','--','==')):current=None;continue
        prefix,sep,tail=label.partition(':')
        if sep and 0<len(prefix)<=60 and re.fullmatch(r'[\w &()./+-]+',prefix,flags=re.UNICODE) and tail.strip():
            key=menu_label(prefix)
            if not key:continue
            if key not in by_key:
                current={'name':prefix.strip(),'entries':[]};by_key[key]=current;rows.append(current)
            else:current=by_key[key]
        else:
            heading=re.sub(r'\s+(?:\d{3,4}p\s+)?Multi\s*Sources$', '',label,flags=re.I).strip()
            if heading!=label and heading.isupper() and len(heading.split())>=2:
                key=menu_label(heading)
                if key not in by_key:
                    current={'name':heading,'entries':[]};by_key[key]=current;rows.append(current)
                else:current=by_key[key]
            # Provider alternative-source entries follow their parent match.
            if current is None or item.get('filetype')!='file':continue
            if not re.search(r'\b(?:vs\.?|multi\s*sources|1080p|720p|2160p)\b',label,re.I):continue
        if item['file'] in seen:continue
        seen.add(item['file']);current['entries'].append(item)
    return [row for row in rows if row['entries']]

def publish_rows(window,rows):
    for index in range(SLOTS):
        name=rows[index]['name'] if index<len(rows) else ''
        if index==SLOTS-1 and len(rows)>SLOTS:name='More football competitions'
        window.setProperty('vexora.football.row.'+str(index),name)
    window.setProperty('vexora.football.count',str(min(len(rows),SLOTS)))

def load_snapshot(rpc,ready,window,clock=time.time):
    if not ready:
        window.clearProperty(CACHE);publish_rows(window,[])
        return {'rows':[],'reason':'Install or enable Rising Tides and its required dependencies.','fallback':'plugin://'+PROVIDER+'/'}
    try:
        raw=window.getProperty(CACHE)
        cached=json.loads(raw) if raw and len(raw)<8*1024*1024 else {}
        if 0<=clock()-cached.get('checked',0)<60 and isinstance(cached.get('rows'),list):return cached
    except (TypeError,ValueError):pass
    entries,reason,fallback=directory_items('football',rpc,True,start=provider_entry('football'))
    snapshot={'rows':competition_rows(entries),'fallback':fallback,'reason':reason,'checked':clock()}
    if not snapshot['rows'] and not reason:snapshot['reason']='No current football matches returned by Rising Tides. Try again later.'
    # Do not retain empty/error results; a return to Sports can retry immediately.
    if snapshot['rows']:window.setProperty(CACHE,json.dumps(snapshot))
    else:window.clearProperty(CACHE)
    publish_rows(window,snapshot['rows'])
    return snapshot

def expand_row(row,rpc):
    """Enter category/source directories; preserve provider event folders.

    Only the immediate Football Live category directories are expanded, once.
    Child directory items can be native source-selection menus and are retained.
    """
    result=[];seen=set();failures=0
    for item in row['entries']:
        entries=[item]
        if item.get('filetype')=='directory':
            try:
                response=json.loads(rpc(json.dumps({'jsonrpc':'2.0','id':1,'method':'Files.GetDirectory','params':{'directory':item['file'],'media':'video','properties':['title','plot','art','thumbnail','fanart']}})))
                if response.get('error'):raise ValueError('Provider category unavailable')
                entries=response.get('result',{}).get('files',[])
                if not isinstance(entries,list):raise ValueError('Invalid provider category')
            except (ValueError,TypeError,RuntimeError):failures+=1;continue
        for entry in entries:
            if not isinstance(entry,dict) or not owned_url(entry.get('file'),PROVIDER) or entry['file'] in seen:continue
            from .sports_catalogue import housekeeping
            if housekeeping(entry):continue
            seen.add(entry['file']);result.append(entry)
    return result,failures

def row_items(index,rpc,ready,window,base_url):
    if not isinstance(index,int) or index<0:raise ValueError('Invalid football row')
    snapshot=load_snapshot(rpc,ready,window);rows=snapshot['rows'];fallback=snapshot['fallback']
    if not rows:return [],snapshot['reason'],fallback
    overflow=index==SLOTS-1 and len(rows)>SLOTS
    if index>=1000:index-=1000
    if overflow:
        return [{'label':row['name'],'file':base_url+'?'+urlencode({'action':'sports_catalogue','category':'football','row':1000+i}),'filetype':'directory'} for i,row in enumerate(rows[SLOTS-1:],SLOTS-1)],'',fallback
    if index>=len(rows):return [],'This competition is no longer listed. Return to Sports to refresh.',fallback
    entries,failures=expand_row(rows[index],rpc)
    reason='' if entries else ('Unable to load '+rows[index]['name']+' from Rising Tides.' if failures else 'No current matches for '+rows[index]['name']+'.')
    return entries,reason,fallback
