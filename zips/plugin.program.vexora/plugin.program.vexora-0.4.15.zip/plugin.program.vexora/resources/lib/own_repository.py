"""First-party repository bootstrap for a Wizard installed directly from ZIP."""
import hashlib,json,tempfile,time,uuid
from .managed_directories import ensure_directory,temporary_directory
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from .safe_paths import has_link_in_path
from .dependencies import _meets_minimum
from .startup_tasks import SOURCE
ID='repository.vexora'

def validate(payload,version):
 payload=Path(payload);metadata=payload/'repository.json';archive=payload/(ID+'.zip')
 if has_link_in_path(metadata) or has_link_in_path(archive) or metadata.stat().st_size>32000 or archive.stat().st_size>1024*1024:raise ValueError('Unsafe first-party repository payload')
 info=json.loads(metadata.read_text(encoding='utf-8'))
 if info.get('id')!=ID or info.get('version')!=version or info.get('source')!=SOURCE or hashlib.sha256(archive.read_bytes()).hexdigest()!=info.get('sha256'):raise ValueError('First-party repository payload/channel mismatch')
 with ZipFile(archive) as z:
  if z.namelist()!=[ID+'/addon.xml'] or z.testzip() is not None:raise ValueError('Unexpected first-party repository ZIP')
  data=z.read(ID+'/addon.xml')
 root=ET.fromstring(data)
 if root.get('id')!=ID or root.get('version')!=version:raise ValueError('First-party repository identity mismatch')
 channel(root)
 return data

def channel(root):
 directory=root.find("./extension[@point='xbmc.addon.repository']/dir")
 if directory is None or any(directory.findtext(tag)!=SOURCE+path for tag,path in (('info','addons.xml'),('checksum','addons.xml.md5'),('datadir','zips/'))):raise ValueError('First-party repository update channel differs')

def stage(data,addons,backup,lookup,set_enabled,on_create=None):
 addons,backup=Path(addons),Path(backup);target=addons/ID
 if has_link_in_path(target) or has_link_in_path(backup):raise ValueError('Unsafe first-party repository destination')
 root=ET.fromstring(data);channel(root);version=root.get('version');current=lookup(ID);retained=None
 if root.get('id')!=ID:raise ValueError('Unexpected first-party repository')
 if target.exists():
  installed=ET.parse(target/'addon.xml').getroot();channel(installed)
  if installed.get('id')!=ID:raise ValueError('Existing first-party repository identity differs')
  if current and current.get('version')!=installed.get('version'):raise ValueError('Repository is changing; retry after Kodi completes its update')
  if _meets_minimum(installed.get('version'),version):return {'status':'reused','version':installed.get('version')}
  if current and current.get('enabled'):set_enabled(ID,False)
  retained=backup/('superseded-repo-'+uuid.uuid4().hex[:12]);ensure_directory(backup)
 ensure_directory(addons)
 with temporary_directory(addons,'.vexora-repo-') as temp:
  staging=Path(temp)/ID;ensure_directory(staging,exist_ok=False);(staging/'addon.xml').write_bytes(data)
  if retained:target.rename(retained)
  try:staging.rename(target)
  except Exception:
   if retained:retained.rename(target)
   raise
 if retained is None and on_create:on_create(ID,{'addon.xml':hashlib.sha256(data).hexdigest()})
 return {'status':'staged','version':version,'retained':retained.name if retained else None}

def verify(lookup,set_enabled,wait,version,clock=time.monotonic):
 deadline=clock()+30
 while clock()<deadline:
  current=lookup(ID)
  if current and _meets_minimum(current.get('version'),version):break
  if wait(.1):raise RuntimeError('First-party repository registration interrupted')
 else:raise RuntimeError('Kodi did not register the first-party repository')
 if not current.get('enabled'):set_enabled(ID,True)
 current=lookup(ID)
 if not current or not current.get('enabled'):raise RuntimeError('Kodi refused first-party repository enablement')
 return current
