"""Confirm only the expected Kodi skin-change dialog inside consented build setup."""

def approve_expected_skin(expected,active_skin,visible,heading,body,localized,click):
    if active_skin()!=expected or not visible():return False
    try:
        title,text=localized(13123).strip(),localized(13111).strip()
        if not title or not text or heading().strip()!=title or body().strip()!=text:return False
    except (RuntimeError,ValueError,AttributeError):return False
    click()
    return True


def approve_skin_choice(expected):
    import xbmc
    import xbmcgui
    if xbmcgui.Window(10000).getProperty('vexora.installing')!='true':return False
    if expected not in ('skin.vexora','skin.estuary'):return False
    approved=approve_expected_skin(expected,xbmc.getSkinDir,
        lambda:xbmc.getCondVisibility('Window.IsActive(yesnodialog)'),
        lambda:xbmc.getInfoLabel('Control.GetLabel(1)'),lambda:xbmc.getInfoLabel('Control.GetLabel(9)'),
        xbmc.getLocalizedString,lambda:xbmc.executebuiltin('SendClick(10100,11)'))
    if approved:xbmc.log('Vexora confirmed scoped skin choice: '+expected,xbmc.LOGINFO)
    return approved


def approve_vexora_skin():
    return approve_skin_choice('skin.vexora')


def activate_skin(expected, monitor, release_progress=None, *, rpc=None, visible=None,
                  approve=None, clock=None, log=None):
    """Release the old GUI completely before Kodi queues a skin reload.

    Closing a dialog requests its closing animation; it is not a GUI barrier.
    Never reload while that modal is still registered. Start the narrowly
    scoped confirmation observer before dispatch, including synchronous hosts.
    """
    import json, time
    from .install_confirmation import confirm_during
    if expected not in ('skin.vexora', 'skin.estuary'):
        raise ValueError('Unexpected build skin')
    if rpc is None or visible is None or approve is None or log is None:
        import xbmc
        rpc = rpc or xbmc.executeJSONRPC
        visible = visible or (lambda: xbmc.getCondVisibility('Window.IsVisible(progressdialog)'))
        approve = approve or (lambda: approve_skin_choice(expected))
        log = log or (lambda stage: xbmc.log('Vexora skin handoff: '+stage, xbmc.LOGINFO))
    clock = clock or time.monotonic
    log('releasing_progress')
    if release_progress:
        release_progress()
    deadline = clock()+10
    while visible():
        if clock() >= deadline:
            raise RuntimeError('Kodi progress dialog did not close; skin switch was not started')
        if monitor.waitForAbort(.1):
            raise RuntimeError('Kodi stopped before skin switch')
    if monitor.abortRequested():
        raise RuntimeError('Kodi stopped before skin switch')
    log('progress_released')
    command=json.dumps({'jsonrpc':'2.0','id':1,'method':'Settings.SetSettingValue',
                        'params':{'setting':'lookandfeel.skin','value':expected}})
    response=confirm_during(lambda: rpc(command), approve, monitor.abortRequested)
    if json.loads(response).get('result') is not True:
        raise RuntimeError('Kodi declined the skin switch')
    log('switch_dispatched')
