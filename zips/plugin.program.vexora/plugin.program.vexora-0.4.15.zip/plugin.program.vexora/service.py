from threading import Thread
from resources.lib.startup_tasks import run
from resources.lib.tile_status import run as tile_status
worker=Thread(target=run, name='Vexora background updates', daemon=True)
worker.start()
tile_status()
