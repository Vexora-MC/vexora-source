# Vexora installer — Kodi 21 Omega

## Current status: not installation-ready

The entry point `default.py` currently checks Kodi 21 and shows a readiness warning. It makes **no network requests, repository installations, skin changes or add-on installations**. It is intentionally fail-closed.

## Required setup (not implemented)

A complete Vexora installation requires both Angelitto and Rising Tides repositories, with **no individual repository skip controls**. The user can cancel overall setup before it begins. After successful repository installation, the Vexora Movies and Sports buttons may offer the respective video add-ons on first selection.

Known sources:
- Angelitto: `https://angelitto2005.github.io/repository.angelitto/`, plugin `plugin.video.tmdbmovies` verified in upstream addon.xml. Repository package independently identified at `https://github.com/angelitto2005/repository.angelitto/blob/main/repository.angelitto-1.0.2.zip` (repository ID `repository.angelitto`, version `1.0.2` per `repo/repository.angelitto/addon.xml`). Upstream repository index and package URLs use HTTPS. This is package discovery, not an integrity or redistribution approval.
- Rising Tides: user-provided `http://mullafabz.xyz/Repository/K19`, ZIP `repository.Rising.Tides.zip`, plugin `plugin.video.Rising.Tides`; the HTTPS URL redirects correctly and exposes the named ZIP in its directory index (listing dated 2021-11-01, ~151 KB), but its embedded addon.xml, integrity, and permissions remain unverified. Prefer `https://mullafabz.xyz/Repository/K19/repository.Rising.Tides.zip` over HTTP. The ZIP has NOT been installed or inspected.

## Release blockers

1. Confirm both repository add-on IDs, actual archive locations, licences and Kodi 21 compatibility.
2. Establish trustworthy package integrity for both repositories, particularly Rising Tides; HTTPS availability alone is not proof of package authenticity.
3. Implement staged installation with verification and no misleading partial-success message.
4. Test in a disposable Kodi 21 Windows profile, including cancel, network failure, missing add-on, and controller navigation.
5. Only then connect first-use plugin installation prompts.

Do not distribute this prototype as a working build installer. Existing `resources/lib/installer.py` is legacy library code and is not called by the current entry point.

## Rising Tides ZIP inspection checkpoint
An attempted direct ZIP inspection could not retrieve the binary archive in the current environment. **Do not infer the internal addon ID, version, checksums, license, or compatibility from the filename or directory listing.** Installer activation remains blocked until a trustworthy archive is retrieved and inspected. The secure URL is a candidate source, not a validated install package.

## Xenon reference XML inspection (user-owned reference, no copying)
Read `djmlogistics/kodi-xenon-reference` at `addons/addons/`:
- `repository.Rising.Tides/addon.xml`: repository ID `repository.Rising.Tides`, version `1.1`, provider `@mullafabz`. Its configured index is `https://mullafabz.xyz/Plugins/K19/Plugins/addons.xml` and package base is `https://mullafabz.xyz/Plugins/K19/Plugins/`; also references `Gujal00/smrzips` over HTTPS.
- `plugin.video.Rising.Tides/addon.xml`: plugin ID `plugin.video.Rising.Tides`, version `3.2.10.9`, Python 3 requirement.
- `repository.angelitto/addon.xml`: repository ID `repository.angelitto`, version `1.0.2`, HTTPS index URLs.
- `plugin.video.tmdbmovies/addon.xml`: plugin ID `plugin.video.tmdbmovies`, version `1.1.313` in the reference (upstream Angelitto currently shows `1.1.320`).

These XMLs establish IDs and repository configurations in the user's saved Xenon snapshot, **not** current ZIP authenticity, redistribution rights, availability, or Kodi 21 runtime compatibility. Vexora must not copy Xenon assets or bundled add-on binaries. Mandatory repository installer remains blocked pending trusted package verification and implementation.

## Automated preflight verification
Windows GitHub Actions run [39510196736](https://github.com/djmlogistics/vexora-kodi-build/actions/runs/39510196736) completed successfully for the six synthetic repository ZIP tests. These tests validate rejection/acceptance logic only; they do not download or verify either real repository package and are not a Kodi runtime test.

## Add-on dependency installation and verification (required)

After both mandatory repositories have been installed and verified, TMDB Movies and Rising Tides remain optional first-use installations. Kodi's native add-on manager must resolve and install the chosen plugin's required dependencies from trusted, enabled repositories. Do not copy installed Xenon add-on folders or assume a plugin is usable merely because its addon ID is present.

The user's Xenon reference `addon.xml` files list:
- `plugin.video.tmdbmovies`: `xbmc.python >= 3.0.0` (Kodi-provided), `script.module.requests >= 2.22.0`, `script.module.resolveurl >= 5.0.0`, `inputstream.adaptive >= 19.0.0`.
- `plugin.video.Rising.Tides`: `xbmc.python >= 3.0.0` (Kodi-provided), `script.module.beautifulsoup4`, `script.module.requests`, `script.module.httplib2`, `inputstream.adaptive`, and `script.module.resolveurl` (explicitly non-optional).

Implementation acceptance criteria:
1. Install repositories first, then refresh/resolve their indexes and use Kodi's native install process for each requested plugin.
2. Let Kodi install the full transitive dependency graph and handle version constraints; never bypass the dependency resolver or silently downgrade shared modules.
3. Verify the plugin and mandatory dependencies are installed and enabled, and check for reported broken/unavailable dependencies before showing success or launching.
4. On unavailable dependencies, failed downloads, version conflicts, disabled components, or installation cancellation, explain the blocker and do not claim a working plugin.
5. Re-read current upstream `addon.xml` metadata at installation time: the Xenon reference is a snapshot, and upstream dependency lists may change.
6. Test fresh-profile installs of each plugin on Kodi 21 Windows, including missing dependency and failed dependency installation scenarios.

No bundled third-party dependency ZIPs or copies of Xenon files are authorized by this requirement.
