"""Vexora native repository setup and first-use optional add-on catalogue."""
import xbmc
import xbmcgui
import sys
from urllib.parse import parse_qs
from resources.lib.readiness import PLUGINS, assess_installed_plugin
from resources.lib.addon_browser import show_installed_tiles


REQUIRED_REPOSITORIES = (
    ("Angelitto", "https://angelitto2005.github.io/repository.angelitto/"),
    ("Rising Tides", "https://mullafabz.xyz/Repository/K19/"),
)


def open_section(section):
    """Verify installed add-on and mandatory dependencies before launching."""
    addon_id = PLUGINS.get(section)
    if addon_id is None:
        xbmcgui.Dialog().ok("Vexora", "Unknown section.")
        return
    result = assess_installed_plugin(addon_id)
    if not result["ready"]:
        blockers = ", ".join(
            item["id"] + " (" + item["status"] + ")"
            for item in result["blockers"]
        )
        xbmcgui.Dialog().ok(
            "Vexora add-on not ready",
            "Kodi has not verified the add-on and all its required dependencies: "
            + blockers + ". Use Kodi's Add-on Browser to install or repair it."
        )
        return
    xbmc.executebuiltin("ActivateWindow(Videos,plugin://" + addon_id + "/,return)")


def main():
    dialog = xbmcgui.Dialog()
    if xbmc.getInfoLabel("System.BuildVersion").split(".")[0] != "21":
        dialog.ok("Vexora", "This installer preview supports Kodi 21 Omega only.")
        return

    params = parse_qs(sys.argv[2].lstrip("?")) if len(sys.argv) > 2 else {}
    section = params.get("section", [None])[0]
    action = params.get("action", [None])[0]
    if action == "browse":
        xbmc.executebuiltin("ActivateWindow(AddonBrowser)")
        return
    if action == "install":
        addon_id = params.get("addon", [""])[0]
        if addon_id not in PLUGINS.values():
            dialog.ok("Vexora", "This add-on is not approved in the Vexora catalogue.")
            return
        from resources.lib.runtime_setup import verify_repositories
        from resources.lib.kodi_status import get_addon
        blockers = verify_repositories(get_addon)
        if blockers:
            dialog.ok("Vexora setup required", "Both mandatory repositories must be ready first: " + ", ".join(blockers))
            return
        if dialog.yesno("Install add-on", "Install " + addon_id +
                        " using Kodi's enabled repositories? Kodi will resolve required dependencies."):
            # Kodi's native InstallAddon built-in delegates repository and
            # dependency handling to Kodi. It is not an installation success
            # signal; never launch or claim success here.
            installed = get_addon(addon_id)
            command = 'EnableAddon' if installed and not installed['enabled'] else 'InstallAddon'
            xbmc.executebuiltin(command + "(" + addon_id + ")", True)
            result = assess_installed_plugin(addon_id)
            if result['ready']:
                dialog.ok('Vexora add-on ready', 'Kodi has installed and enabled the add-on and its required dependencies.')
            else:
                dialog.ok('Vexora add-on incomplete', ', '.join(
                    entry['id'] + ' (' + entry['status'] + ')' for entry in result['blockers'])
                    + '. Installation may have been cancelled or a dependency needs repair in Kodi My add-ons.')
            xbmc.executebuiltin('Container.Refresh')
        return
    if action == "open":
        addon_id = params.get("addon", [""])[0]
        if addon_id not in PLUGINS.values():
            dialog.ok("Vexora", "This add-on is not yet supported by Vexora.")
            return
        open_section(next(k for k, v in PLUGINS.items() if v == addon_id))
        return
    if section in PLUGINS:
        try:
            show_installed_tiles(int(sys.argv[1]), sys.argv[0], section)
        except (RuntimeError, ValueError, KeyError) as exc:
            dialog.ok("Vexora add-on browser", "Unable to read installed add-ons from Kodi.")
        return
    if section is not None:
        dialog.ok("Vexora", "Unknown section.")
        return

    from resources.lib.build_manager import install_full_build
    try:
        install_full_build()
    except (OSError, ValueError, RuntimeError) as exc:
        dialog.ok("Vexora setup incomplete", str(exc) +
                  ". Setup has not succeeded. Any repositories Kodi already installed remain visible in My add-ons.")


if __name__ == "__main__":
    main()
