"""Artwork-first installed video add-on browser for Kodi 21.

Kodi owns installed add-on metadata and artwork. This module does not install
third-party add-ons or pretend repository catalog entries are verified.
"""
import json
from urllib.parse import urlencode
import xbmc
import xbmcgui
import xbmcplugin


def installed_video_addons():
    query = {"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddons",
             "params": {"type": "xbmc.addon.video", "enabled": "all",
                        "properties": ["name", "thumbnail", "fanart", "enabled", "version"]}}
    response = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
    if "error" in response:
        raise RuntimeError("Kodi could not enumerate installed video add-ons")
    addons = response.get("result", {}).get("addons", [])
    if not isinstance(addons, list):
        raise RuntimeError("Kodi returned invalid add-on catalog")
    return [a for a in addons if isinstance(a, dict) and a.get("addonid")
            and isinstance(a.get("enabled"), bool)]


SECTION_ADDONS = {"movies": ("plugin.video.tmdbmovies",),
                  "sports": ("plugin.video.Rising.Tides",)}


def show_installed_tiles(handle, base_url, section):
    """Render clickable native Kodi tiles using add-ons' own artwork."""
    if section not in SECTION_ADDONS:
        raise ValueError("Unknown Vexora section")
    xbmcplugin.setContent(handle, "addons")
    xbmcplugin.setPluginCategory(handle, "Movies" if section == "movies" else "Sports")
    supported = set(SECTION_ADDONS[section])
    installed = {addon["addonid"]: addon for addon in installed_video_addons()
                 if addon["addonid"] in supported}
    for addon_id in SECTION_ADDONS[section]:
        addon = installed.get(addon_id)
        name = (addon or {}).get("name") or {
            "plugin.video.tmdbmovies": "TMDB Movies",
            "plugin.video.Rising.Tides": "Rising Tides",
        }[addon_id]
        # Only installed add-ons have artwork confirmed by Kodi. Do not
        # misrepresent a stock icon as the original add-on's own artwork.
        art = (addon or {}).get("thumbnail") or (
            "special://home/addons/skin.vexora/media/vexoramc" + section + ".png")
        state = 'Disabled — select to enable' if addon and not addon['enabled'] else (
            'Installed' if addon else 'Available to install')
        item = xbmcgui.ListItem(label=name + '  [' + state + ']')
        item.setArt({"icon": art, "thumb": art,
                     "fanart": (addon or {}).get("fanart") or ""})
        item.setProperty("IsPlayable", "false")
        action = "open" if addon and addon['enabled'] else "install"
        url = base_url + "?" + urlencode({"action": action, "addon": addon_id})
        xbmcplugin.addDirectoryItem(handle, url, item, False)
    xbmcplugin.endOfDirectory(handle)
