"""Reviewed Crew Kids directories; provider metadata, no separate catalogue.

Routes verified in publisher script.module.thecrew 3.2.26. Certification is a
conservative display gate, not a child-safety guarantee or parental control.
"""
import json
from urllib.parse import urlencode, urlsplit, parse_qs
PROVIDER = 'plugin.video.thecrew'
ROUTES = {
    'animated': ('movies', 'kids_movies_animation'),
    'family': ('movies', 'kids_movies_family'),
    'children_tv': ('tvshows', 'kids_tv_kids'),
    'animated_tv': ('tvshows', 'kids_tv_animation'),
    'family_tv': ('tvshows', 'kids_tv_family'),
}
RATINGS = {'movies': {'G', 'PG'}, 'tvshows': {'TV-Y', 'TV-Y7', 'TV-G'}}


def provider_url(category):
    action, url = ROUTES[category]
    return 'plugin://' + PROVIDER + '/?' + urlencode({'action': action, 'url': url})


def directory_items(category, rpc, ready):
    content = ROUTES[category][0]
    if not ready:
        return [], 'Install or repair The Crew using Vexora Add-on management.'
    response = json.loads(rpc(json.dumps({'jsonrpc': '2.0', 'id': 1,
        'method': 'Files.GetDirectory', 'params': {'directory': provider_url(category),
        'media': 'video', 'properties': ['title', 'plot', 'year', 'rating', 'genre',
        'premiered', 'art', 'thumbnail', 'fanart', 'mpaa']}})))
    entries = response.get('result', {}).get('files', [])
    if response.get('error') or not isinstance(entries, list):
        return [], 'The Crew Kids catalogue is unavailable. Try again later.'
    approved = []
    for entry in entries:
        if not isinstance(entry, dict):continue
        path = urlsplit(entry.get('file', ''))
        action = parse_qs(path.query).get('action', [''])[0]
        rating = str(entry.get('mpaa', '')).strip().upper()
        # Kodi providers can prefix the authority name to the actual rating.
        for prefix in ('RATED ', 'US:'):
            if rating.startswith(prefix):rating = rating[len(prefix):].strip()
        if (path.scheme == 'plugin' and path.netloc == PROVIDER
                and action in ({'play'} if content == 'movies' else {'seasons', 'episodes'})
                and rating in RATINGS[content]):
            approved.append(entry)
    return approved, '' if approved else 'No rated Kids results available. Unrated entries are hidden.'


def show_kids(handle, base_url, category):
    import xbmc
    import xbmcgui
    import xbmcplugin
    from .readiness import assess_installed_plugin
    content = ROUTES[category][0]
    xbmcplugin.setContent(handle, content)
    try:
        entries, reason = directory_items(category, xbmc.executeJSONRPC,
                                         assess_installed_plugin(PROVIDER)['ready'])
    except (ValueError, TypeError, RuntimeError):
        entries, reason = [], 'The Crew Kids catalogue is unavailable.'
    for entry in entries:
        item = xbmcgui.ListItem(label=entry.get('label') or entry.get('title') or '')
        art = dict(entry.get('art') or {})
        art.setdefault('poster', entry.get('thumbnail') or '')
        art.setdefault('fanart', entry.get('fanart') or '')
        item.setArt(art)
        info = item.getVideoInfoTag()
        for key, setter in [('title','setTitle'), ('plot','setPlot'), ('year','setYear'),
                            ('rating','setRating'), ('genre','setGenres'), ('mpaa','setMpaa')]:
            if key in entry:getattr(info, setter)(entry[key])
        info.setMediaType('movie' if content == 'movies' else 'tvshow')
        item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle, entry['file'], item, entry.get('filetype') == 'directory')
    if not entries:
        item = xbmcgui.ListItem(label=reason)
        xbmcplugin.addDirectoryItem(handle, base_url + '?action=tile&section=kids&key=crew', item, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
