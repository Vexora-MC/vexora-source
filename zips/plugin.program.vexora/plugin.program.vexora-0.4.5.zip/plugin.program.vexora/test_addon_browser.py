"""Offline tests for Vexora's artwork catalogue (mock Kodi APIs)."""
import importlib.util
import json
from pathlib import Path
import sys
import types
import unittest
from unittest.mock import Mock, patch

PATH = Path(__file__).parent / "resources" / "lib" / "addon_browser.py"


class BrowserTests(unittest.TestCase):
    def setUp(self):
        self.xbmc = types.ModuleType("xbmc")
        self.xbmc.executeJSONRPC = Mock()
        self.gui = types.ModuleType("xbmcgui")
        self.gui.ListItem = Mock(side_effect=lambda **kw: Mock(**kw))
        self.plugin = types.ModuleType("xbmcplugin")
        self.plugin.setContent = Mock()
        self.plugin.setPluginCategory = Mock()
        self.plugin.addDirectoryItem = Mock()
        self.plugin.endOfDirectory = Mock()
        self.patcher = patch.dict(sys.modules, {"xbmc": self.xbmc, "xbmcgui": self.gui, "xbmcplugin": self.plugin})
        self.patcher.start()
        spec = importlib.util.spec_from_file_location("vexora_browser_test", PATH)
        self.browser = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.browser)

    def tearDown(self):
        self.patcher.stop()

    def test_wizard_root_is_navigation_only(self):
        self.browser.show_wizard_menu(1, 'plugin://plugin.program.vexora/')
        self.assertEqual(self.plugin.addDirectoryItem.call_count, 5)
        urls = [call.args[1] for call in self.plugin.addDirectoryItem.call_args_list]
        self.assertTrue(any('action=build' in url for url in urls))
        self.plugin.endOfDirectory.assert_called_once_with(1)
        self.xbmc.executeJSONRPC.assert_not_called()

    def test_sections_only_show_their_own_addon(self):
        self.xbmc.executeJSONRPC.return_value = json.dumps({"result": {"addons": [
            {"addonid": "plugin.video.tmdbmovies", "enabled": True, "name": "TMDB", "thumbnail": "tmdb.png"},
            {"addonid": "plugin.video.Rising.Tides", "enabled": True, "name": "Rising Tides", "thumbnail": "rising.png"}
        ]}})
        self.browser.show_installed_tiles(1, "plugin://plugin.program.vexora/", "movies")
        self.assertEqual(self.plugin.addDirectoryItem.call_count, 1)
        self.assertIn("action=open", self.plugin.addDirectoryItem.call_args.args[1])
        self.assertIn("tmdbmovies", self.plugin.addDirectoryItem.call_args.args[1])

    def test_missing_addon_is_installable_tile(self):
        self.xbmc.executeJSONRPC.return_value = '{"result":{"addons":[]}}'
        self.browser.show_installed_tiles(1, "plugin://plugin.program.vexora/", "sports")
        self.assertIn("action=install", self.plugin.addDirectoryItem.call_args.args[1])
        self.assertIn("Rising.Tides", self.plugin.addDirectoryItem.call_args.args[1])

    def test_jsonrpc_failure_does_not_fake_empty_catalog(self):
        self.xbmc.executeJSONRPC.return_value = '{"error":{"code":-1}}'
        with self.assertRaises(RuntimeError):
            self.browser.show_installed_tiles(1, "plugin://plugin.program.vexora/", "movies")


if __name__ == "__main__":
    unittest.main()
