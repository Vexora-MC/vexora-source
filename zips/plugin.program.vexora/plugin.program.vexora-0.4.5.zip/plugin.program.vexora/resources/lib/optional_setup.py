"""Optional native installs, separate from mandatory build success/rollback."""
import hashlib
import json
import time
from pathlib import Path
from .optional_catalogue import OPTIONAL_ADDONS, OPTIONAL_REPOSITORIES, selected_addons
from .safe_paths import has_link_in_path


def read_choices(path):
    path = Path(path)
    if has_link_in_path(path):
        raise ValueError('Unsafe optional setup state path')
    if not path.exists():
        return {'format': 1, 'status': 'new', 'results': {}}
    data = json.loads(path.read_text(encoding='utf-8'))
    if data.get('format') != 1 or data.get('status') not in ('new', 'dismissed', 'completed'):
        raise ValueError('Invalid optional setup state')
    return data


def save_choices(path, state):
    path = Path(path)
    if has_link_in_path(path):
        raise ValueError('Unsafe optional setup state path')
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix('.tmp')
    if has_link_in_path(temporary):
        raise ValueError('Unsafe optional setup temporary path')
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True), encoding='utf-8')
    temporary.replace(path)


def reviewed_repository_packages(fetch=None):
    """Validate all additional publishers before the build changes profile data."""
    from .repository_download import fetch_repository_zip
    from .repository_preflight import inspect_repository_zip
    packages = {}
    for repo, source in OPTIONAL_REPOSITORIES.items():
        data = (fetch or fetch_repository_zip)(repo, source=source)
        if hashlib.sha256(data).hexdigest() != source['sha256']:
            raise ValueError('Publisher repository changed; review required: ' + repo)
        inspect_repository_zip(data, repo, versions={repo: source['version']})
        packages[repo] = data
    return packages


def install_build_repositories(packages, lookup, execute, wait, installed_path,
                               clock=time.monotonic):
    """All four repositories are part of build consent; video add-ons stay optional."""
    from .runtime_setup import verify_repository_files
    if set(packages) != set(OPTIONAL_REPOSITORIES):
        raise ValueError('All additional repository packages are required')
    for repo, source in OPTIONAL_REPOSITORIES.items():
        data = packages[repo]
        if hashlib.sha256(data).hexdigest() != source['sha256']:
            raise ValueError('Publisher repository changed; review required: ' + repo)
        current = lookup(repo)
        if current and current.get('version') != source['version']:
            raise ValueError('Installed repository differs from reviewed version: ' + repo)
        if not current or not current.get('enabled'):
            execute(('EnableAddon' if current else 'InstallAddon') + '(' + repo + ')')
        deadline = clock() + 60
        while clock() < deadline:
            current = lookup(repo)
            if current and current.get('enabled') and current.get('version') == source['version']:
                break
            if wait(0.5):
                raise RuntimeError('Kodi is shutting down')
        else:
            raise RuntimeError('Repository installation failed or timed out: ' + repo)
        verify_repository_files({repo: data}, installed_path,
                                versions={repo: source['version']})
    execute('UpdateAddonRepos')


def install_selected(keys, lookup, execute, wait, installed_path, verify_ready,
                     fetch=None, clock=time.monotonic):
    """Use Kodi for installation/dependencies and verify observed completion."""
    from .repository_download import fetch_repository_zip
    from .runtime_setup import verify_repository_files
    results = {}
    verified = set()
    for addon in selected_addons(keys):
        id = addon['id']
        try:
            repo = addon['repository']
            source = OPTIONAL_REPOSITORIES[repo]
            if repo not in verified:
                data = (fetch or fetch_repository_zip)(repo, source=source)
                if hashlib.sha256(data).hexdigest() != source['sha256']:
                    raise ValueError('Publisher repository changed; review required: ' + repo)
                current = lookup(repo)
                if current and current.get('version') != source['version']:
                    raise ValueError('Installed repository differs from reviewed version: ' + repo)
                if not current or not current.get('enabled'):
                    execute(('EnableAddon' if current else 'InstallAddon') + '(' + repo + ')')
                deadline = clock() + 60
                while clock() < deadline:
                    current = lookup(repo)
                    if current and current.get('enabled') and current.get('version') == source['version']:
                        break
                    if wait(0.5):raise RuntimeError('Kodi is shutting down')
                else:raise RuntimeError('Repository install cancelled, failed or timed out: ' + repo)
                verify_repository_files({repo: data}, installed_path,
                                        versions={repo: source['version']})
                execute('UpdateAddonRepos')
                verified.add(repo)
            current = lookup(id)
            if not current or not current.get('enabled'):
                execute(('EnableAddon' if current else 'InstallAddon') + '(' + id + ')')
            deadline = clock() + 90
            while clock() < deadline:
                readiness = verify_ready(id)
                if readiness.get('ready'):
                    results[id] = {'status': 'installed'}
                    break
                if wait(0.5):raise RuntimeError('Kodi is shutting down')
            else:raise RuntimeError('Add-on or dependencies not ready after native installation: ' + id)
        except (OSError, ValueError, RuntimeError) as error:
            results[id] = {'status': 'failed', 'reason': str(error)}
    return results


def run_optional_setup(first_run=False):
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from .kodi_status import get_addon
    from .readiness import assess_installed_plugin
    dialog = xbmcgui.Dialog()
    path = Path(xbmcvfs.translatePath('special://profile/addon_data/plugin.program.vexora/optional-setup.json'))
    try:
        state = read_choices(path)
        if first_run and state['status'] != 'new':
            return
        keys = [key for key, item in OPTIONAL_ADDONS.items()
                if key != 'crew_sports' and not item.get('unavailable')]
        choices = dialog.multiselect('Optional Vexora add-ons - select or cancel to skip',
                                     [OPTIONAL_ADDONS[key]['name'] for key in keys])
        state['status'] = 'dismissed'
        save_choices(path, state)  # Do not repeat the prompt after cancellation/interruption.
        if not choices:
            return
        chosen = [keys[index] for index in choices]
        monitor = xbmc.Monitor()
        results = install_selected(chosen, get_addon,
            lambda command: xbmc.executebuiltin(command, True), monitor.waitForAbort,
            lambda id: xbmcvfs.translatePath(xbmcaddon.Addon(id).getAddonInfo('path')),
            assess_installed_plugin)
        state.update(status='completed', selected=chosen, results=results)
        save_choices(path, state)
        failed = [id + ': ' + item['reason'] for id, item in results.items() if item['status'] == 'failed']
        dialog.ok('Optional add-on results', '\n'.join(failed) if failed else
                  'Selected add-ons and their required dependencies are installed and enabled.')
    except (OSError, ValueError, RuntimeError) as error:
        dialog.ok('Optional add-on setup incomplete', str(error) +
                  '. The mandatory Vexora build is unaffected. Retry from Add-on management.')


def run_selected_addon(key):
    """Called after the tile's single OK/Cancel prompt; no second selection UI."""
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from .kodi_status import get_addon
    from .readiness import assess_installed_plugin
    selected_addons([key])  # Reject an unknown key before doing any work.
    monitor = xbmc.Monitor()
    results = install_selected([key], get_addon,
        lambda command: xbmc.executebuiltin(command, True), monitor.waitForAbort,
        lambda id: xbmcvfs.translatePath(xbmcaddon.Addon(id).getAddonInfo('path')),
        assess_installed_plugin)
    result = results[OPTIONAL_ADDONS[key]['id']]
    failed = result['status'] != 'installed'
    message = result.get('reason', OPTIONAL_ADDONS[key]['name'] + ' installed and ready')
    if failed:xbmc.log('Vexora add-on installation: ' + message, xbmc.LOGERROR)
    xbmcgui.Dialog().notification('Add-on installation incomplete' if failed else 'Vexora',
                                  message, time=8000 if failed else 3500)
    xbmc.executebuiltin('Container.Refresh')
    return results
