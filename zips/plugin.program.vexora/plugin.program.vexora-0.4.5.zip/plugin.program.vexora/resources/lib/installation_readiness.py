"""Repository installation state transitions for the two mandatory sources.

This module does not mutate Kodi. It provides a deterministic plan and
fail-closed verification to the future Kodi runtime adapter.
"""
from .required_repositories import TEST_APPS
from .repository_preflight import REQUIRED

REPOSITORY_IDS = tuple(REQUIRED)


def repository_setup_state(installed, enabled):
    """Return blockers and readiness for both required repositories."""
    blockers = []
    for repo_id in REPOSITORY_IDS:
        if not installed(repo_id):
            blockers.append({"id": repo_id, "reason": "not-installed"})
        elif not enabled(repo_id):
            blockers.append({"id": repo_id, "reason": "disabled"})
    return {"ready": not blockers, "blockers": blockers}


def addon_setup_state(installed, enabled, dependencies_ready):
    """Require repositories and both optional test add-ons for end-to-end QA."""
    blockers = []
    for section, item in TEST_APPS.items():
        addon_id = item["addon"]
        if not installed(addon_id):
            blockers.append({"section": section, "id": addon_id, "reason": "not-installed"})
        elif not enabled(addon_id):
            blockers.append({"section": section, "id": addon_id, "reason": "disabled"})
        elif not dependencies_ready(addon_id):
            blockers.append({"section": section, "id": addon_id, "reason": "dependencies"})
    return {"ready": not blockers, "blockers": blockers}


def complete_test_build_state(repo_installed, repo_enabled,
                              addon_installed, addon_enabled, dependencies_ready):
    repositories = repository_setup_state(repo_installed, repo_enabled)
    addons = addon_setup_state(addon_installed, addon_enabled, dependencies_ready)
    return {"ready": repositories["ready"] and addons["ready"],
            "repositories": repositories, "addons": addons}
