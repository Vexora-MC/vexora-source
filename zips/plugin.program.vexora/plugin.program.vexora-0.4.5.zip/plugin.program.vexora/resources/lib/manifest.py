"""Pure-Python validation and planning for Vexora's opt-in add-on manifest."""
import re

ID = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]*$")
GROUP = re.compile(r"^[a-z][a-z0-9_-]*$")


class ManifestError(ValueError):
    pass


def validate(data):
    if not isinstance(data, dict) or set(data) != {"schema_version", "kodi_major", "groups"}:
        raise ManifestError("Expected schema_version, kodi_major and groups only")
    if type(data["schema_version"]) is not int or data["schema_version"] != 1:
        raise ManifestError("Unsupported manifest schema")
    if type(data["kodi_major"]) is not int or data["kodi_major"] != 21:
        raise ManifestError("Only Kodi 21 is supported")
    groups = data["groups"]
    if not isinstance(groups, list):
        raise ManifestError("groups must be a list")
    group_names, addon_ids = set(), set()
    for group in groups:
        if not isinstance(group, dict) or set(group) != {"id", "label", "addons"}:
            raise ManifestError("Each group needs id, label and addons")
        name, label, addons = group["id"], group["label"], group["addons"]
        if not isinstance(name, str) or not GROUP.fullmatch(name) or name in group_names:
            raise ManifestError("Invalid or duplicate group ID")
        group_names.add(name)
        if not isinstance(label, str) or not label.strip() or len(label) > 80:
            raise ManifestError("Invalid group label")
        if not isinstance(addons, list):
            raise ManifestError("addons must be a list")
        for addon in addons:
            if not isinstance(addon, dict) or set(addon) != {"id", "repository"}:
                raise ManifestError("Each add-on needs id and repository")
            addon_id, repository = addon["id"], addon["repository"]
            if not isinstance(addon_id, str) or not ID.fullmatch(addon_id):
                raise ManifestError("Invalid add-on ID")
            if not isinstance(repository, str) or not repository.startswith("repository.") or not ID.fullmatch(repository):
                raise ManifestError("Invalid repository ID")
            if addon_id in addon_ids:
                raise ManifestError("Duplicate add-on across groups")
            addon_ids.add(addon_id)
    return data


def plan(data, selected_groups):
    """Return a read-only installation plan. Never downloads or installs."""
    validate(data)
    if not isinstance(selected_groups, (list, tuple, set)):
        raise ManifestError("Selection must be a collection")
    names = {group["id"] for group in data["groups"]}
    if not all(isinstance(x, str) and x in names for x in selected_groups):
        raise ManifestError("Unknown installation group")
    selected = set(selected_groups)
    return [dict(addon) for group in data["groups"] if group["id"] in selected for addon in group["addons"]]
