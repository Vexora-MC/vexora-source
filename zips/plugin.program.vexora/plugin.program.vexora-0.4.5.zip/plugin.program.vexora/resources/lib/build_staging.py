"""Offline Vexora build staging. No live Kodi profile writes.

Prepare a fully verified staging tree for later, explicitly confirmed
installation. The source directory must be a trusted extracted build payload.
"""
import hashlib
import os
from pathlib import Path
import shutil
import tempfile

from .deployment_plan import DeploymentError, plan_deployment


def _regular_file(path, root):
    """Reject symlinks, including symlinked parent directories."""
    root = Path(root).absolute()
    path = Path(path).absolute()
    if not path.is_relative_to(root):
        raise DeploymentError("File escapes payload root")
    current = path
    while current != root:
        if current.is_symlink():
            raise DeploymentError("Symlinks are forbidden")
        current = current.parent
    if root.is_symlink() or not path.is_file():
        raise DeploymentError("Missing or invalid payload file")


def stage_build(manifest, payload_root, staging_parent):
    """Stage validated files and return path; caller owns staged directory.

    Never points at Kodi userdata and never promotes files to a live profile.
    A failed stage is deleted. staging_parent must be an explicit empty or
    existing workspace selected by the caller, not the live Kodi profile.
    """
    plan = plan_deployment(manifest)
    payload_root = Path(payload_root).absolute()
    staging_parent = Path(staging_parent).absolute()
    if not payload_root.is_dir() or payload_root.is_symlink():
        raise DeploymentError("Invalid payload directory")
    if not staging_parent.is_dir() or staging_parent.is_symlink():
        raise DeploymentError("Invalid staging directory")
    if staging_parent == payload_root or staging_parent.is_relative_to(payload_root):
        raise DeploymentError("Staging must be separate from payload")
    if payload_root.is_relative_to(staging_parent):
        raise DeploymentError("Staging must be separate from payload")
    stage = Path(tempfile.mkdtemp(prefix="vexora-stage-", dir=staging_parent))
    try:
        for entry in manifest["files"]:
            relative = entry["path"]
            source = payload_root / relative
            _regular_file(source, payload_root)
            target = stage / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            with source.open("rb") as src, target.open("xb") as dst:
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk:
                        break
                    digest.update(chunk)
                    dst.write(chunk)
            if digest.hexdigest() != entry["sha256"]:
                raise DeploymentError("Payload checksum mismatch: " + relative)
        return stage
    except Exception:
        shutil.rmtree(stage)
        raise
