"""Thin Kodi directory adapter; TMDB Movies owns metadata, routes and playback.

Routes verified against installed TMDB Movies 1.1.320 menus.py, entry.py,
tmdb_api.py and router.py. No HTTP scraping, duplicate database or API key.
"""
import json
from .ui_text import themed_text
from urllib.parse import urlencode

PROVIDER = 'plugin.video.tmdbmovies'
ROUTES = {
    'movies_latest': ('movies', 'build_movie_list', 'tmdb_movies_latest_releases'),
    'movies_popular': ('movies', 'build_movie_list', 'tmdb_movies_popular'),
    'movies_trending': ('movies', 'build_movie_list', 'tmdb_movies_trending_day'),
    'tv_latest': ('tvshows', 'build_tvshow_list', 'tmdb_tv_latest_releases'),
    'tv_popular': ('tvshows', 'build_tvshow_list', 'tmdb_tv_popular'),
}


def provider_url(category):
    content, mode, action = ROUTES[category]
    return 'plugin://' + PROVIDER + '/?' + urlencode({'mode': mode, 'action': action})


def directory_items(category, rpc, ready):
    """Return provider-owned entries including its original next-page link."""
    if category not in ROUTES:
        raise ValueError('Unknown catalogue row')
    if not ready:
        return [], 'TMDB Movies is missing, disabled or needs dependency repair.'
    response = json.loads(rpc(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
        'params': {'directory': provider_url(category), 'media': 'video',
                   'properties': ['title', 'plot', 'year', 'rating', 'genre',
                                  'premiered', 'art', 'thumbnail', 'fanart']}})))
    if response.get('error'):
        return [], 'TMDB Movies could not load this catalogue. Open the provider to check its settings.'
    entries = response.get('result', {}).get('files', [])
    if not isinstance(entries, list):
        return [], 'TMDB Movies returned an invalid catalogue.'
    # Never turn an unexpected external URL into an executable widget action.
    entries = [item for item in entries if isinstance(item, dict)
               and isinstance(item.get('file'), str)
               and item['file'].startswith('plugin://' + PROVIDER + '/')]
    return entries, '' if entries else 'No results from TMDB Movies. Open the provider or try again later.'


def show_catalogue(handle, base_url, category):
    import xbmc
    import xbmcgui
    import xbmcplugin
    from .readiness import assess_installed_plugin
    if category not in ROUTES:
        raise ValueError('Unknown catalogue row')
    xbmcplugin.setContent(handle, ROUTES[category][0])
    ready = assess_installed_plugin(PROVIDER)['ready']
    try:
        entries, reason = directory_items(category, xbmc.executeJSONRPC, ready)
    except (ValueError, TypeError, RuntimeError):
        entries, reason = [], 'Unable to load TMDB Movies. Open the provider to check its settings.'
    for entry in entries:
        item = xbmcgui.ListItem(label=themed_text(entry.get('label') or entry.get('title') or ''))
        art = dict(entry.get('art') or {})
        art.setdefault('poster', entry.get('thumbnail') or '')
        art.setdefault('thumb', entry.get('thumbnail') or '')
        art.setdefault('fanart', entry.get('fanart') or '')
        item.setArt(art)
        info = item.getVideoInfoTag()
        for key, setter in [('title', 'setTitle'), ('plot', 'setPlot'), ('year', 'setYear'),
                            ('rating', 'setRating'), ('genre', 'setGenres'),
                            ('premiered', 'setPremiered')]:
            if key in entry:
                getattr(info, setter)(themed_text(entry[key]))
        if entry.get('title'):
            info.setMediaType('movie' if ROUTES[category][0] == 'movies' else 'tvshow')
        item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle, entry['file'], item,
                                    entry.get('filetype') == 'directory')
    if not entries:
        item = xbmcgui.ListItem(label=reason)
        item.setArt({'thumb': 'special://home/addons/skin.vexora/media/vexoramcmovies.png'})
        item.setProperty('IsPlayable', 'false')
        url = base_url + '?' + urlencode({'action': 'install' if not ready else 'open', 'addon': PROVIDER})
        xbmcplugin.addDirectoryItem(handle, url, item, False)
    # Reuse successful directory results; never cache failures or install fallbacks.
    xbmcplugin.endOfDirectory(handle, cacheToDisc=bool(entries))
