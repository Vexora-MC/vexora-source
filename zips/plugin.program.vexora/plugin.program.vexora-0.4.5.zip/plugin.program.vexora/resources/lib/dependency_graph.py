"""Read-only verification of the installed mandatory dependency graph."""
from xml.etree import ElementTree as ET
from .dependencies import required_dependencies, dependency_status


def inspect_dependency_graph(addon_id, lookup, read_manifest, max_addons=256):
    """Check every installed manifest, minimum version and enabled state.

    Kodi owns installation and version resolution. This is a final launch
    gate, including transitive imports; it never installs or enables modules.
    """
    visited, visiting, blockers = set(), set(), []

    def visit(current):
        if current in visiting:
            blockers.append({'id': current, 'status': 'dependency_cycle'})
            return
        if current in visited:
            return
        if len(visited) + len(visiting) >= max_addons:
            raise ValueError('Dependency graph exceeds verification limit')
        visiting.add(current)
        xml = read_manifest(current)
        root = ET.fromstring(xml)
        if root.tag != 'addon' or root.get('id') != current:
            raise ValueError('Installed dependency identity mismatch: ' + current)
        requirements = required_dependencies(xml)
        statuses = dependency_status(requirements, lookup)
        for requirement, status in zip(requirements, statuses):
            if status['status'] not in ('available', 'runtime'):
                blockers.append(status)
            elif status['status'] != 'runtime':
                visit(requirement['id'])
        visiting.remove(current)
        visited.add(current)

    visit(addon_id)
    return {'ready': not blockers, 'blockers': blockers}
