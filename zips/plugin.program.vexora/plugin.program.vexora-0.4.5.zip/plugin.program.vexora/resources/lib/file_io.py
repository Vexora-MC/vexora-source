"""File flushing for Kodi runtimes with optional OS durability support."""
import os


def flush_file(output):
    """Always flush Python buffers; sync to disk only when the runtime offers it.

    Xbox Python omits os.fsync. Do not hide errors when fsync is available.
    Callers still close the file before atomic rename/readback verification.
    """
    output.flush()
    sync = getattr(os, 'fsync', None)
    if sync is not None:
        sync(output.fileno())
