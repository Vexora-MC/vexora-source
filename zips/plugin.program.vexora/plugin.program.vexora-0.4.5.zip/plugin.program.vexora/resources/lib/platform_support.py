"""One runtime plan for desktop Kodi and UWP; never select a platform ZIP."""
from pathlib import Path
from .safe_paths import has_link_in_path
from .file_io import flush_file


def capabilities(version, windows, uwp):
    major = str(version).split('.')[0]
    return {'kodi_major':major,'target_runtime':major=='21' and bool(windows or uwp),
            'platform':'UWP / Xbox' if uwp else 'Windows desktop' if windows else 'Other',
            'desktop_force_close':bool(windows) and not bool(uwp),
            'native_state_undo':True,'full_restore_requires_stopped_kodi':True,
            'physical_xbox_validation':False}


def probe_write_directory(folder):
    """After installation consent, test only the translated managed data root."""
    import os
    import uuid
    folder=Path(folder)
    if has_link_in_path(folder):raise ValueError('Install directory contains a link/reparse point')
    folder.mkdir(parents=True,exist_ok=True)
    source=folder/('.vexora-probe-'+uuid.uuid4().hex)
    target=source.with_suffix('.renamed')
    try:
        with source.open('xb') as output:
            output.write(b'Vexora install preflight');flush_file(output)
        source.replace(target)
        if target.read_bytes()!=b'Vexora install preflight':raise OSError('Write verification failed')
    finally:
        source.unlink(missing_ok=True);target.unlink(missing_ok=True)


def runtime_report():
    import xbmc
    import xbmcvfs
    report=capabilities(xbmc.getInfoLabel('System.BuildVersion'),
        xbmc.getCondVisibility('System.Platform.Windows'),xbmc.getCondVisibility('System.Platform.UWP'))
    report['home']=xbmcvfs.translatePath('special://home/')
    report['profile']=xbmcvfs.translatePath('special://profile/')
    return report
