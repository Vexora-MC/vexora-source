"""Vexora Kids poster rows backed by TMDB Movies' own genre directories.

Animation (16) and Family (10751) are TMDB movie genres, not age ratings.
Playback and source selection remain owned by TMDB Movies and its providers.
"""
import json
from urllib.parse import urlencode, urlsplit

from .ui_text import themed_text

PROVIDER = 'plugin.video.tmdbmovies'
GENRES = {'animated': '16', 'family': '10751'}
ROUTES = dict((key, ('movie', genre)) for key, genre in GENRES.items())


def provider_url(category):
    return 'plugin://' + PROVIDER + '/?' + urlencode({
        'mode': 'list_by_genre', 'media_type': 'movie',
        'genre_id': GENRES[category]})


def directory_items(category, rpc, ready):
    if category not in GENRES:
        return [], 'Unknown Kids category.'
    if not ready:
        return [], 'Install or repair TMDB Movies using Vexora Add-on management.'
    response = json.loads(rpc(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
        'params': {'directory': provider_url(category), 'media': 'video',
                   'properties': ['title', 'plot', 'year', 'rating', 'genre',
                                  'art', 'thumbnail', 'fanart', 'mpaa']}})))
    entries = response.get('result', {}).get('files', [])
    if response.get('error') or not isinstance(entries, list):
        return [], 'TMDB Movies genre is unavailable. Try again later.'
    approved = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        path = urlsplit(entry.get('file', ''))
        if path.scheme == 'plugin' and path.netloc == PROVIDER:
            approved.append(entry)
    return approved, '' if approved else 'No movies returned by TMDB Movies. Try again later.'


def show_kids(handle, base_url, category):
    import xbmc
    import xbmcgui
    import xbmcplugin
    from .readiness import assess_installed_plugin

    xbmcplugin.setContent(handle, 'movies')
    try:
        entries, reason = directory_items(
            category, xbmc.executeJSONRPC,
            assess_installed_plugin(PROVIDER)['ready'])
    except (ValueError, TypeError, RuntimeError, KeyError):
        entries, reason = [], 'TMDB Movies genre is unavailable.'
    for entry in entries:
        item = xbmcgui.ListItem(label=themed_text(entry.get('label') or entry.get('title') or ''))
        art = dict(entry.get('art') or {})
        art.setdefault('poster', entry.get('thumbnail') or '')
        art.setdefault('fanart', entry.get('fanart') or '')
        item.setArt(art)
        item.setProperty('IsPlayable', 'true' if entry.get('filetype') == 'file' else 'false')
        xbmcplugin.addDirectoryItem(
            handle, entry['file'], item, entry.get('filetype') == 'directory')
    if not entries:
        item = xbmcgui.ListItem(label=reason)
        xbmcplugin.addDirectoryItem(
            handle, base_url + '?action=tile&section=kids&key=tmdb_kids', item, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=bool(entries))
