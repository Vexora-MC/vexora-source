"""Keep provider text readable in Vexora without overriding artwork or routes."""
import re
_COLOR = re.compile(r'\[/?COLOR(?:[ =][^\]]*)?\]', re.IGNORECASE)

def themed_text(value):
    return _COLOR.sub('', value) if isinstance(value, str) else value
