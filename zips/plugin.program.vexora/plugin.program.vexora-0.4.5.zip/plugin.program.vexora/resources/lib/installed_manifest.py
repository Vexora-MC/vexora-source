"""Read an installed add-on manifest through Kodi's own path resolution.

Read-only. Does not copy Xenon files or modify the user's Kodi profile.
"""
from pathlib import Path
import xbmc
import xbmcvfs
import re


class InstalledManifestError(RuntimeError):
    pass


def read_dependency_manifest(addon_id, max_bytes=512000):
    """Resolve installed dependency locations through Kodi, including system add-ons."""
    import xbmcaddon
    if not isinstance(addon_id, str) or not re.fullmatch(r'[A-Za-z0-9_.-]+', addon_id):
        raise InstalledManifestError('Invalid dependency ID')
    path = Path(xbmcvfs.translatePath(xbmcaddon.Addon(addon_id).getAddonInfo('path'))) / 'addon.xml'
    if not path.is_file() or path.stat().st_size > max_bytes:
        raise InstalledManifestError('Installed dependency manifest unavailable: ' + addon_id)
    return path.read_text(encoding='utf-8')


def read_installed_addon_xml(addon_id, max_bytes=512000):
    """Read the actual installed addon.xml; reject missing or oversized manifests."""
    if addon_id not in ("plugin.video.tmdbmovies", "plugin.video.Rising.Tides"):
        raise InstalledManifestError("Unexpected plugin")
    addon_path = xbmcvfs.translatePath("special://home/addons/" + addon_id + "/addon.xml")
    path = Path(addon_path)
    try:
        if path.stat().st_size > max_bytes:
            raise InstalledManifestError("Installed addon.xml is too large")
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        xbmc.log("Vexora could not read installed manifest for " + addon_id, xbmc.LOGWARNING)
        raise InstalledManifestError("Installed addon.xml is unavailable") from exc
