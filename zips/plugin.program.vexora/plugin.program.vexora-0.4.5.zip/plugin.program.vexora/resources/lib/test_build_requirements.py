"""Repository setup contract for the Vexora Windows preview.

No repository archives are embedded or downloaded by this preview.
Approved HTTPS sources and actual Kodi installation must be validated before
the build is marked ready. Never use the legacy HTTP Rising Tides endpoint.
"""
from .required_repositories import TEST_APPS

REPOSITORY_SETUP = (
    {"id": "repository.angelitto", "required": True,
     "expected_version": "1.0.2", "verified_download_url": None},
    {"id": "repository.Rising.Tides", "required": True,
     "expected_version": "1.1", "verified_download_url": None},
)


def installation_blockers():
    """Explicitly disclose why a preview cannot perform repository installs."""
    return [
        "Verified HTTPS repository ZIP sources are not configured for both mandatory repositories.",
        "Kodi runtime repository installation and dependency-resolution adapter is not yet integrated.",
        "The two test add-ons have not been installed and launched in a disposable Kodi 21 profile.",
    ]
