"""Safe, testable deployment planner for a complete Vexora Kodi profile.

This module deliberately does not write into a live Kodi profile. A future
runtime adapter must perform backup, staging, atomic promotion and rollback.
"""
from dataclasses import dataclass
from pathlib import PurePosixPath
from .safe_paths import validate_relative_path

MANDATORY_REPOSITORIES = ("repository.angelitto", "repository.Rising.Tides")
ALLOWED_ROOTS = ("addons", "userdata", "media")


class DeploymentError(ValueError):
    pass


@dataclass(frozen=True)
class DeploymentPlan:
    files: tuple
    repositories: tuple
    backup_required: bool
    restart_required: bool


def plan_deployment(manifest):
    """Validate a complete-build file manifest without modifying Kodi.

    Paths are relative to Kodi's profile root, never absolute. The manifest
    cannot overwrite unrelated Kodi files or smuggle traversal components.
    """
    if not isinstance(manifest, dict) or manifest.get("format") != 1:
        raise DeploymentError("Unsupported build manifest")
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        raise DeploymentError("Build must contain files")
    normalized = []
    for item in files:
        if not isinstance(item, dict):
            raise DeploymentError("Invalid file entry")
        name, digest = item.get("path"), item.get("sha256")
        if not isinstance(name, str) or not name or "\\" in name:
            raise DeploymentError("Unsafe path")
        path = PurePosixPath(name)
        try:
            validate_relative_path(name)
        except ValueError as exc:
            raise DeploymentError("Unsafe destination path") from exc
        if (path.is_absolute() or any(part in ("", ".", "..") for part in name.split("/"))
                or path.parts[0] not in ALLOWED_ROOTS or name.endswith("/")):
            raise DeploymentError("Unsafe path")
        if not isinstance(digest, str) or len(digest) != 64 or any(
                ch not in "0123456789abcdef" for ch in digest):
            raise DeploymentError("Invalid SHA-256")
        normalized.append(name)
    if len(normalized) != len({name.casefold() for name in normalized}):
        raise DeploymentError("Duplicate destination")
    destinations = {name.casefold() for name in normalized}
    if any('/'.join(name.split('/')[:i]) in destinations
           for name in destinations for i in range(1, len(name.split('/')))):
        raise DeploymentError("File and directory destinations overlap")
    if "addons/skin.vexora/addon.xml" not in normalized:
        raise DeploymentError("Missing Vexora skin")
    if "addons/plugin.program.vexora/addon.xml" not in normalized:
        raise DeploymentError("Missing Vexora installer")
    repositories = manifest.get("mandatory_repositories")
    if repositories != list(MANDATORY_REPOSITORIES):
        raise DeploymentError("Both mandatory repositories are required")
    return DeploymentPlan(tuple(normalized), MANDATORY_REPOSITORIES, True, True)
