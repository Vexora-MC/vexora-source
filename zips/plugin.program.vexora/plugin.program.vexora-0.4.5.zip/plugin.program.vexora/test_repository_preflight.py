"""Offline unit tests for mandatory repository ZIP preflight."""
import io
import unittest
import zipfile
from resources.lib.repository_preflight import inspect_repository_zip, RepositoryPackageError


def make_zip(addon_id="repository.angelitto", version="1.0.2",
             endpoint="https://example.org/index.xml", extra=None):
    xml = ('<addon id="%s" version="%s"><extension point="xbmc.addon.repository">'
           '<dir><info>%s</info><checksum>https://example.org/checksum</checksum>'
           '<datadir>https://example.org/zips/</datadir></dir>'
           '</extension></addon>') % (addon_id, version, endpoint)
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w") as archive:
        archive.writestr(addon_id + "/addon.xml", xml)
        if extra:
            archive.writestr(extra, "bad")
    return output.getvalue()


class PreflightTests(unittest.TestCase):
    def test_valid_package(self):
        self.assertEqual(inspect_repository_zip(make_zip(), "repository.angelitto")["version"], "1.0.2")

    def test_wrong_identity(self):
        with self.assertRaises(RepositoryPackageError):
            inspect_repository_zip(make_zip(), "repository.Rising.Tides")

    def test_wrong_version(self):
        with self.assertRaises(RepositoryPackageError):
            inspect_repository_zip(make_zip(version="0.0.1"), "repository.angelitto")

    def test_http_endpoint(self):
        with self.assertRaises(RepositoryPackageError):
            inspect_repository_zip(make_zip(endpoint="http://example.org/index.xml"), "repository.angelitto")

    def test_path_traversal(self):
        with self.assertRaises(RepositoryPackageError):
            inspect_repository_zip(make_zip(extra="repository.angelitto/../evil.txt"), "repository.angelitto")

    def test_invalid_zip(self):
        with self.assertRaises(RepositoryPackageError):
            inspect_repository_zip(b"not a zip", "repository.angelitto")


if __name__ == "__main__":
    unittest.main()
