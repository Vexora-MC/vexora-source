"""Vexora native repository setup and first-use optional add-on catalogue."""
import xbmc
import xbmcgui
import sys
from urllib.parse import parse_qs
from resources.lib.readiness import PLUGINS, assess_installed_plugin
from resources.lib.addon_browser import show_installed_tiles, show_wizard_menu


REQUIRED_REPOSITORIES = (
    ("Angelitto", "https://angelitto2005.github.io/repository.angelitto/"),
    ("Rising Tides", "https://mullafabz.xyz/Repository/K19/"),
)


def open_section(section):
    """Verify installed add-on and mandatory dependencies before launching."""
    addon_id = PLUGINS.get(section)
    if addon_id is None:
        xbmcgui.Dialog().ok("Vexora", "Unknown section.")
        return
    result = assess_installed_plugin(addon_id)
    if not result["ready"]:
        blockers = ", ".join(
            item["id"] + " (" + item["status"] + ")"
            for item in result["blockers"]
        )
        xbmcgui.Dialog().ok(
            "Vexora add-on not ready",
            "Kodi has not verified the add-on and all its required dependencies: "
            + blockers + ". Use Kodi's Add-on Browser to install or repair it."
        )
        return
    xbmc.executebuiltin("ActivateWindow(Videos,plugin://" + addon_id + "/,return)")


def main():
    dialog = xbmcgui.Dialog()
    if xbmc.getInfoLabel("System.BuildVersion").split(".")[0] != "21":
        dialog.ok("Vexora", "Vexora supports Kodi 21 Omega only.")
        return

    params = parse_qs(sys.argv[2].lstrip("?")) if len(sys.argv) > 2 else {}
    section = params.get("section", [None])[0]
    action = params.get("action", [None])[0]
    if action == 'compatibility':
        from resources.lib.platform_support import runtime_report
        report = runtime_report()
        dialog.ok('Vexora device compatibility',
                  'Detected: ' + report['platform'] + ' / Kodi ' + report['kodi_major'] +
                  '. One shared package is used. Native setup undo is available for new backups. '
                  'Full file/database restore requires Kodi stopped. '
                  'Xbox controller, playback and installation still require console validation.\nProfile: ' + report['profile'])
        return
    if action == 'force_close':
        from resources.lib.power import force_close_kodi
        force_close_kodi()
        return
    if action == 'manage':
        from resources.lib.optional_setup import run_optional_setup
        run_optional_setup()
        xbmc.executebuiltin('Container.Refresh')
        return
    if action == 'tiles':
        from resources.lib.addon_browser import show_home_tiles
        show_home_tiles(int(sys.argv[1]), sys.argv[0], section)
        return
    if action == 'tile':
        from resources.lib.addon_browser import home_catalogue
        from resources.lib.optional_setup import run_selected_addon
        entry = next((item for item in home_catalogue(section)
                      if item['key'] == params.get('key', [''])[0]), None)
        if entry is None:
            dialog.ok('Vexora', 'Unknown add-on tile.')
            return
        result = assess_installed_plugin(entry['id'])
        if result['ready']:
            xbmc.executebuiltin('ActivateWindow(Videos,plugin://' + entry['id'] + '/' + entry['route'] + ',return)')
        elif entry.get('unavailable'):
            dialog.ok('Vexora source unavailable', entry['unavailable'])
        elif entry['id'] in PLUGINS.values():
            xbmc.executebuiltin('RunPlugin(' + sys.argv[0] + '?action=install&addon=' + entry['id'] + ')')
        elif result.get('blockers') and any(b.get('status') != 'missing' for b in result['blockers']):
            blockers = ', '.join(b.get('id', 'unknown') + ' (' + b.get('status', 'unknown') + ')' for b in result['blockers'])
            xbmc.log('Vexora tile readiness failed: ' + entry['id'] + ': ' + blockers, xbmc.LOGERROR)
            dialog.ok('Vexora add-on not ready', entry['name'] + ': ' + blockers + '. Check Kodi My add-ons for dependency repairs.')
        elif dialog.yesno('Install add-on', 'Install ' + entry['name'] + '?',
                          nolabel='Cancel', yeslabel='OK'):
            run_selected_addon(entry['key'])
        return
    if action == 'kids_catalogue':
        from resources.lib.kids_catalogue import show_kids
        show_kids(int(sys.argv[1]), sys.argv[0], params.get('category', [''])[0])
        return
    if action == "catalogue":
        from resources.lib.catalogue import show_catalogue
        show_catalogue(int(sys.argv[1]), sys.argv[0], params.get("category", [""])[0])
        return
    if action == "browse":
        xbmc.executebuiltin("ActivateWindow(AddonBrowser)")
        return
    if action == "install":
        addon_id = params.get("addon", [""])[0]
        if addon_id not in PLUGINS.values():
            dialog.ok("Vexora", "This add-on is not approved in the Vexora catalogue.")
            return
        from resources.lib.runtime_setup import verify_repositories
        from resources.lib.kodi_status import get_addon
        blockers = verify_repositories(get_addon)
        if blockers:
            dialog.ok("Vexora setup required", "Both mandatory repositories must be ready first: " + ", ".join(blockers))
            return
        if dialog.yesno("Install add-on", "Install " + addon_id +
                        "?", nolabel="Cancel", yeslabel="OK"):
            # Kodi's native InstallAddon built-in delegates repository and
            # dependency handling to Kodi. It is not an installation success
            # signal; never launch or claim success here.
            installed = get_addon(addon_id)
            command = 'EnableAddon' if installed and not installed['enabled'] else 'InstallAddon'
            xbmc.executebuiltin(command + "(" + addon_id + ")", True)
            result = assess_installed_plugin(addon_id)
            if result['ready']:
                dialog.notification('Vexora', 'Add-on installed and ready')
            else:
                dialog.notification('Vexora add-on incomplete', ', '.join(
                    entry['id'] + ' (' + entry['status'] + ')' for entry in result['blockers'])
                    + '. Installation may have been cancelled or a dependency needs repair in Kodi My add-ons.')
            xbmc.executebuiltin('Container.Refresh')
        return
    if action == "open":
        addon_id = params.get("addon", [""])[0]
        if addon_id not in PLUGINS.values():
            dialog.ok("Vexora", "This add-on is not yet supported by Vexora.")
            return
        open_section(next(k for k, v in PLUGINS.items() if v == addon_id))
        return
    if section in PLUGINS:
        try:
            show_installed_tiles(int(sys.argv[1]), sys.argv[0], section)
        except (RuntimeError, ValueError, KeyError) as exc:
            dialog.ok("Vexora add-on browser", "Unable to read installed add-ons from Kodi.")
        return
    if section is not None:
        dialog.ok("Vexora", "Unknown section.")
        return

    if action is None:
        show_wizard_menu(int(sys.argv[1]), sys.argv[0])
        return
    if action == 'recovery':
        from resources.lib.native_recovery import run_recovery
        run_recovery()
        return
    if action != 'build':
        dialog.ok('Vexora', 'Unknown wizard action.')
        return
    home_window = xbmcgui.Window(10000)
    if home_window.getProperty('vexora.installing') == 'true':
        return
    home_window.setProperty('vexora.installing', 'true')
    try:
        from resources.lib.build_manager import install_full_build
        if install_full_build():
            from resources.lib.optional_setup import run_optional_setup
            run_optional_setup(first_run=True)
    except Exception as exc:
        from resources.lib.error_reporting import report_setup_error
        report_setup_error(dialog, xbmc.log, xbmc.LOGERROR, exc)
    finally:
        home_window.clearProperty('vexora.installing')


if __name__ == "__main__":
    main()
