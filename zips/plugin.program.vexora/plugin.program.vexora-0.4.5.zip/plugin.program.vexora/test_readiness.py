"""Offline first-use readiness tests."""
import unittest
from resources.lib.readiness import assess_plugin, assess_installed_plugin

XML = """<addon id="plugin.video.tmdbmovies"><requires>
<import addon="xbmc.python" version="3.0.0"/>
<import addon="script.module.requests" version="2.22.0"/>
</requires></addon>"""


class ReadinessTests(unittest.TestCase):
    def test_ready(self):
        def lookup(addon_id):
            return {"enabled": True, "version": "3.0.1" if addon_id == "xbmc.python" else "2.22.0"}
        self.assertTrue(assess_plugin("plugin.video.tmdbmovies", XML, lookup)["ready"])

    def test_dependency_version_blocker(self):
        def lookup(addon_id):
            return {"enabled": True, "version": "2.21.0"}
        result = assess_plugin("plugin.video.tmdbmovies", XML, lookup)
        self.assertFalse(result["ready"])
        self.assertEqual(result["blockers"][0]["status"], "version_mismatch")

    def test_missing_plugin(self):
        result = assess_plugin("plugin.video.tmdbmovies", XML, lambda _: None)
        self.assertEqual(result["blockers"][0]["status"], "missing")

    def test_installed_plugin_uses_live_manifest(self):
        seen = []
        def read_manifest(addon_id):
            seen.append(addon_id)
            return XML if addon_id == 'plugin.video.tmdbmovies' else '<addon id="' + addon_id + '"/>'
        result = assess_installed_plugin(
            "plugin.video.tmdbmovies",
            lookup=lambda key: {"enabled": True, "version": "3.0.1" if key == "xbmc.python" else "2.22.0"},
            read_manifest=read_manifest)
        self.assertTrue(result["ready"])
        self.assertIn("script.module.requests", seen)

    def test_installed_manifest_failure_blocks_launch(self):
        result = assess_installed_plugin(
            "plugin.video.tmdbmovies",
            lookup=lambda key: {"enabled": True, "version": "3.0.1" if key == "xbmc.python" else "2.22.0"},
            read_manifest=lambda _: (_ for _ in ()).throw(OSError("missing")))
        self.assertFalse(result["ready"])
        self.assertEqual(result["blockers"][0]["status"], "verification_failed")

    def test_wrong_identity(self):
        with self.assertRaises(ValueError):
            assess_plugin("plugin.video.Rising.Tides", XML, lambda _: {"enabled": True})


if __name__ == "__main__":
    unittest.main()
