"""Use Kodi's directory backend without walking outside an app sandbox."""
from pathlib import Path


def ensure_directory(folder, *, exist_ok=True):
    """Create a checked managed directory; never hide a failed Kodi operation.

    Kodi UWP can access its managed path while Python mkdir/stat rejects the
    package ancestors. Kodi VFS owns directory checks/creation in Kodi. Native
    Python remains the backend for offline recovery/tests without Kodi loaded.
    Callers retain their destination/link/containment checks and verify writes.
    """
    folder = Path(folder)
    try:
        import xbmcvfs
    except ImportError:
        folder.mkdir(parents=True, exist_ok=exist_ok)
        return folder
    directory = str(folder).rstrip('/\\') + '/'
    if xbmcvfs.exists(directory):
        if not exist_ok:
            raise FileExistsError('Managed directory already exists: ' + str(folder))
        return folder
    # mkdirs may report false if another process created it; require a fresh
    # directory-existence check in either case, rather than treating it as OK.
    created = xbmcvfs.mkdirs(directory)
    if not exist_ok and not created:
        raise FileExistsError('Managed directory creation was not exclusive: ' + str(folder))
    if not xbmcvfs.exists(directory):
        raise OSError('Kodi could not create managed directory: ' + str(folder))
    return folder


from contextlib import contextmanager

@contextmanager
def temporary_directory(parent, prefix):
    """Own a unique staging folder using the same Kodi directory backend."""
    import uuid
    import re
    if not re.fullmatch(r'[.A-Za-z0-9_-]{1,40}', prefix):
        raise ValueError('Unsafe staging prefix')
    parent = ensure_directory(parent)
    try:
        import xbmcvfs
    except ImportError:
        import tempfile
        with tempfile.TemporaryDirectory(prefix=prefix, dir=str(parent)) as folder:
            yield folder
        return
    folder = parent / (prefix + uuid.uuid4().hex[:12])
    directory = str(folder).rstrip('/\\') + '/'
    if xbmcvfs.exists(directory) or xbmcvfs.exists(str(folder)):
        raise FileExistsError('Staging directory collision')
    if not xbmcvfs.mkdir(directory):
        raise OSError('Kodi could not create private staging directory')
    try:
        if not xbmcvfs.exists(directory):
            raise OSError('Kodi did not verify private staging directory')
        yield str(folder)
    finally:
        # Only the exact unique directory this invocation successfully created
        # is eligible for cleanup; no parent or reused folder can be deleted.
        if xbmcvfs.exists(directory):
            xbmcvfs.rmdir(directory, True)
            if xbmcvfs.exists(directory):
                raise OSError('Kodi could not remove private staging directory')
